name: _RINvNtNtCsfyJ81pLjVxE_10webpc_core6interp5block3hotNtNtB6_3mmu3MmuNCINvNtB6_3jit9interpretBN_E0EB6_
index: 99
kind: wasm function
compiler: TurboFan
Body (size = 15680 = 15656 + 24 padding)
Instructions (size = 14492)
0x1659a0bbf5e0     0  d2800610       movz x16, #0x30
0x1659a0bbf5e4     4  a9be43e7       stp x7, x16, [sp, #-32]!
0x1659a0bbf5e8     8  a9017bfd       stp fp, lr, [sp, #16]
0x1659a0bbf5ec     c  910043fd       add fp, sp, #0x10 (16)
0x1659a0bbf5f0    10  d10303ff       sub sp, sp, #0xc0 (192)
0x1659a0bbf5f4    14  f841f0e1       ldur x1, [x7, #31]
0x1659a0bbf5f8    18  f94073e7       ldr x7, [sp, #224]
0x1659a0bbf5fc    1c  2a0703e7       mov w7, w7
0x1659a0bbf600    20  8b070028       add x8, x1, x7
0x1659a0bbf604    24  f9400d09       ldr x9, [x8, #24]
0x1659a0bbf608    28  f940110a       ldr x10, [x8, #32]
0x1659a0bbf60c    2c  f9002fe2       str x2, [sp, #88]
0x1659a0bbf610    30  f9002be3       str x3, [sp, #80]
0x1659a0bbf614    34  f90037e4       str x4, [sp, #104]
0x1659a0bbf618    38  f9003be5       str x5, [sp, #112]
0x1659a0bbf61c    3c  f90033e6       str x6, [sp, #96]
0x1659a0bbf620    40  f9004fe7       str x7, [sp, #152]
0x1659a0bbf624    44  f9005fe8       str x8, [sp, #184]
0x1659a0bbf628    48  35000063       cbnz w3, #+0xc (addr 0x1659a0bbf634)
0x1659a0bbf62c    4c  d280000b       movz x11, #0x0
0x1659a0bbf630    50  1400000f       b #+0x3c (addr 0x1659a0bbf66c)
0x1659a0bbf634    54  2a0003eb       mov w11, w0
0x1659a0bbf638    58  8b0b002b       add x11, x1, x11
0x1659a0bbf63c    5c  f941bd6c       ldr x12, [x11, #888]
0x1659a0bbf640    60  9240058c       and x12, x12, #0x3
0x1659a0bbf644    64  f100059f       cmp x12, #0x1 (1)
0x1659a0bbf648    68  54000060       b.eq #+0xc (addr 0x1659a0bbf654)
0x1659a0bbf64c    6c  d280000b       movz x11, #0x0
0x1659a0bbf650    70  14000007       b #+0x1c (addr 0x1659a0bbf66c)
0x1659a0bbf654    74  394d016b       ldrb w11, [x11, #832]
0x1659a0bbf658    78  5303096b       lsl w11, w11, #29
0x1659a0bbf65c    7c  131f7d6b       asr w11, w11, #31
0x1659a0bbf660    80  121c056b       and w11, w11, #0x30
0x1659a0bbf664    84  0b0b006b       add w11, w3, w11
0x1659a0bbf668    88  1102016b       add w11, w11, #0x80 (128)
0x1659a0bbf66c    8c  cb090149       sub x9, x10, x9
0x1659a0bbf670    90  f940090a       ldr x10, [x8, #16]
0x1659a0bbf674    94  f940050c       ldr x12, [x8, #8]
0x1659a0bbf678    98  f867682d       ldr x13, [x1, x7]
0x1659a0bbf67c    9c  b9402d0e       ldr w14, [x8, #44]
0x1659a0bbf680    a0  b940290f       ldr w15, [x8, #40]
0x1659a0bbf684    a4  1104c013       add w19, w0, #0x130 (304)
0x1659a0bbf688    a8  d28003f5       movz x21, #0x1f
0x1659a0bbf68c    ac  d2800014       movz x20, #0x0
0x1659a0bbf690    b0  1400000d       b #+0x34 (addr 0x1659a0bbf6c4)
0x1659a0bbf694    b4  11000508       add w8, w8, #0x1 (1)
0x1659a0bbf698    b8  79001888       strh w8, [x4, #12]
0x1659a0bbf69c    bc  b9400888       ldr w8, [x4, #8]
0x1659a0bbf6a0    c0  f9403bea       ldr x10, [sp, #112]
0x1659a0bbf6a4    c4  0b080d4f       add w15, w10, w8, lsl #3
0x1659a0bbf6a8    c8  39403884       ldrb w4, [x4, #14]
0x1659a0bbf6ac    cc  eb09009f       cmp x4, x9
0x1659a0bbf6b0    d0  9a893084       csel x4, x4, x9, lo
0x1659a0bbf6b4    d4  0b040dee       add w14, w15, w4, lsl #3
0x1659a0bbf6b8    d8  cb040129       sub x9, x9, x4
0x1659a0bbf6bc    dc  aa0d03ea       mov x10, x13
0x1659a0bbf6c0    e0  aa0203ec       mov x12, x2
0x1659a0bbf6c4    e4  38531356       ldurb w22, [x26, #-207]
0x1659a0bbf6c8    e8  35018e56       cbnz w22, #+0x31c8 (addr 0x1659a0bc2890)
0x1659a0bbf6cc    ec  6b0e01ff       cmp w15, w14
0x1659a0bbf6d0    f0  54018140       b.eq #+0x3028 (addr 0x1659a0bc26f8)
0x1659a0bbf6d4    f4  38531356       ldurb w22, [x26, #-207]
0x1659a0bbf6d8    f8  350190d6       cbnz w22, #+0x3218 (addr 0x1659a0bc28f0)
0x1659a0bbf6dc    fc  b86f6836       ldr w22, [x1, x15]
0x1659a0bbf6e0   100  8b0f0037       add x23, x1, x15
0x1659a0bbf6e4   104  394016f8       ldrb w24, [x23, #5]
0x1659a0bbf6e8   108  394012f9       ldrb w25, [x23, #4]
0x1659a0bbf6ec   10c  39401efb       ldrb w27, [x23, #7]
0x1659a0bbf6f0   110  f100cb7f       cmp cp, #0x32 (50)
0x1659a0bbf6f4   114  54018842       b.hs #+0x3108 (addr 0x1659a0bc27fc)
0x1659a0bbf6f8   118  1001b5f0       adr x16, #+0x36bc (addr 0x1659a0bc2db4)
0x1659a0bbf6fc   11c  aa0203e2       mov x2, x2
0x1659a0bbf700   120  aa0203e2       mov x2, x2
0x1659a0bbf704   124  d2800011       movz x17, #0x0
0x1659a0bbf708   128  b8bb7a11       ldrsw x17, [x16, x27, lsl #2]
0x1659a0bbf70c   12c  8b110210       add x16, x16, x17
0x1659a0bbf710   130  d61f0200       br x16
0x1659a0bbf714   134  39401af6       ldrb w22, [x23, #6]
0x1659a0bbf718   138  53185ed6       lsl w22, w22, #8
0x1659a0bbf71c   13c  12001337       and w23, w25, #0x1f
0x1659a0bbf720   140  71007eff       cmp w23, #0x1f (31)
0x1659a0bbf724   144  54000080       b.eq #+0x10 (addr 0x1659a0bbf734)
0x1659a0bbf728   148  0b170c17       add w23, w0, w23, lsl #3
0x1659a0bbf72c   14c  f8776837       ldr x23, [x1, x23]
0x1659a0bbf730   150  14000002       b #+0x8 (addr 0x1659a0bbf738)
0x1659a0bbf734   154  aa1403f7       mov x23, x20
0x1659a0bbf738   158  2a1802d6       orr w22, w22, w24
0x1659a0bbf73c   15c  53057f38       lsr w24, w25, #5
0x1659a0bbf740   160  34000398       cbz w24, #+0x70 (addr 0x1659a0bbf7b0)
0x1659a0bbf744   164  7100071f       cmp w24, #0x1 (1)
0x1659a0bbf748   168  54000280       b.eq #+0x50 (addr 0x1659a0bbf798)
0x1659a0bbf74c   16c  71000b1f       cmp w24, #0x2 (2)
0x1659a0bbf750   170  54000100       b.eq #+0x20 (addr 0x1659a0bbf770)
0x1659a0bbf754   174  14000001       b #+0x4 (addr 0x1659a0bbf758)
0x1659a0bbf758   178  2a0003f7       mov w23, w0
0x1659a0bbf75c   17c  8b170037       add x23, x1, x23
0x1659a0bbf760   180  f941a2f8       ldr x24, [x23, #832]
0x1659a0bbf764   184  aa160316       orr x22, x24, x22
0x1659a0bbf768   188  f901a2f6       str x22, [x23, #832]
0x1659a0bbf76c   18c  14000b6a       b #+0x2da8 (addr 0x1659a0bc2514)
0x1659a0bbf770   190  2a0003f6       mov w22, w0
0x1659a0bbf774   194  8b160036       add x22, x1, x22
0x1659a0bbf778   198  f941a2d8       ldr x24, [x22, #832]
0x1659a0bbf77c   19c  8a370319       bic x25, x24, x23
0x1659a0bbf780   1a0  373983f9       tbnz w25, #7, #+0x307c (addr 0x1659a0bc27fc)
0x1659a0bbf784   1a4  9276ef18       and x24, x24, #0xfffffffffffffc3f
0x1659a0bbf788   1a8  927a0ef7       and x23, x23, #0x3c0
0x1659a0bbf78c   1ac  aa170317       orr x23, x24, x23
0x1659a0bbf790   1b0  f901a2d7       str x23, [x22, #832]
0x1659a0bbf794   1b4  14000b60       b #+0x2d80 (addr 0x1659a0bc2514)
0x1659a0bbf798   1b8  2a0003f6       mov w22, w0
0x1659a0bbf79c   1bc  8b160036       add x22, x1, x22
0x1659a0bbf7a0   1c0  394d02d8       ldrb w24, [x22, #832]
0x1659a0bbf7a4   1c4  360182d8       tbz w24, #0, #+0x3058 (addr 0x1659a0bc27fc)
0x1659a0bbf7a8   1c8  f901a6d7       str x23, [x22, #840]
0x1659a0bbf7ac   1cc  14000b5a       b #+0x2d68 (addr 0x1659a0bc2514)
0x1659a0bbf7b0   1d0  928b8c58       movn x24, #0x5c62
0x1659a0bbf7b4   1d4  f2bc3958       movk x24, #0xe1ca, lsl #16
0x1659a0bbf7b8   1d8  9bb87ed8       umull x24, w22, w24
0x1659a0bbf7bc   1dc  d36aff18       lsr x24, x24, #42
0x1659a0bbf7c0   1e0  d2809139       movz x25, #0x489
0x1659a0bbf7c4   1e4  1b19db16       msub w22, w24, w25, w22
0x1659a0bbf7c8   1e8  0b160016       add w22, w0, w22
0x1659a0bbf7cc   1ec  f8366837       str x23, [x1, x22]
0x1659a0bbf7d0   1f0  14000b51       b #+0x2d44 (addr 0x1659a0bc2514)
0x1659a0bbf7d4   1f4  7100131f       cmp w24, #0x4 (4)
0x1659a0bbf7d8   1f8  540000e8       b.hi #+0x1c (addr 0x1659a0bbf7f4)
0x1659a0bbf7dc   1fc  12001317       and w23, w24, #0x1f
0x1659a0bbf7e0   200  d280003b       movz cp, #0x1
0x1659a0bbf7e4   204  1ad72377       lsl w23, w27, w23
0x1659a0bbf7e8   208  d280033b       movz cp, #0x19
0x1659a0bbf7ec   20c  6a1b02ff       tst w23, w27
0x1659a0bbf7f0   210  54000061       b.ne #+0xc (addr 0x1659a0bbf7fc)
0x1659a0bbf7f4   214  0b160df6       add w22, w15, w22, lsl #3
0x1659a0bbf7f8   218  f8766836       ldr x22, [x1, x22]
0x1659a0bbf7fc   21c  f100171f       cmp x24, #0x5 (5)
0x1659a0bbf800   220  54000182       b.hs #+0x30 (addr 0x1659a0bbf830)
0x1659a0bbf804   224  1001acf0       adr x16, #+0x359c (addr 0x1659a0bc2da0)
0x1659a0bbf808   228  aa0203e2       mov x2, x2
0x1659a0bbf80c   22c  aa0203e2       mov x2, x2
0x1659a0bbf810   230  d2800011       movz x17, #0x0
0x1659a0bbf814   234  b8b87a11       ldrsw x17, [x16, x24, lsl #2]
0x1659a0bbf818   238  8b110210       add x16, x16, x17
0x1659a0bbf81c   23c  d61f0200       br x16
0x1659a0bbf820   240  2a0003f6       mov w22, w0
0x1659a0bbf824   244  8b160036       add x22, x1, x22
0x1659a0bbf828   248  394d02d6       ldrb w22, [x22, #832]
0x1659a0bbf82c   24c  36017e96       tbz w22, #0, #+0x2fd0 (addr 0x1659a0bc27fc)
0x1659a0bbf830   250  2a0003f6       mov w22, w0
0x1659a0bbf834   254  8b160036       add x22, x1, x22
0x1659a0bbf838   258  f941a6d6       ldr x22, [x22, #840]
0x1659a0bbf83c   25c  14000012       b #+0x48 (addr 0x1659a0bbf884)
0x1659a0bbf840   260  2a0003f6       mov w22, w0
0x1659a0bbf844   264  8b160036       add x22, x1, x22
0x1659a0bbf848   268  f94086d6       ldr x22, [x22, #264]
0x1659a0bbf84c   26c  1400000e       b #+0x38 (addr 0x1659a0bbf884)
0x1659a0bbf850   270  2a0003f7       mov w23, w0
0x1659a0bbf854   274  8b170037       add x23, x1, x23
0x1659a0bbf858   278  f941a2f7       ldr x23, [x23, #832]
0x1659a0bbf85c   27c  8a1602f6       and x22, x23, x22
0x1659a0bbf860   280  14000009       b #+0x24 (addr 0x1659a0bbf884)
0x1659a0bbf864   284  928b8c57       movn x23, #0x5c62
0x1659a0bbf868   288  f2bc3957       movk x23, #0xe1ca, lsl #16
0x1659a0bbf86c   28c  9bb77ed7       umull x23, w22, w23
0x1659a0bbf870   290  d36afef7       lsr x23, x23, #42
0x1659a0bbf874   294  d2809138       movz x24, #0x489
0x1659a0bbf878   298  1b18daf6       msub w22, w23, w24, w22
0x1659a0bbf87c   29c  0b160016       add w22, w0, w22
0x1659a0bbf880   2a0  f8766836       ldr x22, [x1, x22]
0x1659a0bbf884   2a4  71007f3f       cmp w25, #0x1f (31)
0x1659a0bbf888   2a8  54016460       b.eq #+0x2c8c (addr 0x1659a0bc2514)
0x1659a0bbf88c   2ac  0b190c17       add w23, w0, w25, lsl #3
0x1659a0bbf890   2b0  f8376836       str x22, [x1, x23]
0x1659a0bbf894   2b4  14000b20       b #+0x2c80 (addr 0x1659a0bc2514)
0x1659a0bbf898   2b8  71007f3f       cmp w25, #0x1f (31)
0x1659a0bbf89c   2bc  540163c0       b.eq #+0x2c78 (addr 0x1659a0bc2514)
0x1659a0bbf8a0   2c0  39401af7       ldrb w23, [x23, #6]
0x1659a0bbf8a4   2c4  120016db       and w27, w22, #0x3f
0x1659a0bbf8a8   2c8  1100077c       add w28, w27, #0x1 (1)
0x1659a0bbf8ac   2cc  1200179c       and w28, w28, #0x3f
0x1659a0bbf8b0   2d0  92800007       movn x7, #0x0
0x1659a0bbf8b4   2d4  9adc20fc       lsl x28, x7, x28
0x1659a0bbf8b8   2d8  aa3c03fc       mvn x28, x28
0x1659a0bbf8bc   2dc  7100ff7f       cmp w27, #0x3f (63)
0x1659a0bbf8c0   2e0  9a9c00fb       csel cp, x7, x28, eq
0x1659a0bbf8c4   2e4  0b180c18       add w24, w0, w24, lsl #3
0x1659a0bbf8c8   2e8  0b190c19       add w25, w0, w25, lsl #3
0x1659a0bbf8cc   2ec  374000b6       tbnz w22, #8, #+0x14 (addr 0x1659a0bbf8e0)
0x1659a0bbf8d0   2f0  120012fc       and w28, w23, #0x1f
0x1659a0bbf8d4   2f4  1adc2f7b       ror w27, w27, w28
0x1659a0bbf8d8   2f8  d28003fc       movz x28, #0x1f
0x1659a0bbf8dc   2fc  14000004       b #+0x10 (addr 0x1659a0bbf8ec)
0x1659a0bbf8e0   300  120016fc       and w28, w23, #0x3f
0x1659a0bbf8e4   304  9adc2f7b       ror cp, cp, x28
0x1659a0bbf8e8   308  d28007fc       movz x28, #0x3f
0x1659a0bbf8ec   30c  f8786838       ldr x24, [x1, x24]
0x1659a0bbf8f0   310  f8796828       ldr x8, [x1, x25]
0x1659a0bbf8f4   314  4b1702c5       sub w5, w22, w23
0x1659a0bbf8f8   318  0a050385       and w5, w28, w5
0x1659a0bbf8fc   31c  110004bc       add w28, w5, #0x1 (1)
0x1659a0bbf900   320  1200179c       and w28, w28, #0x3f
0x1659a0bbf904   324  9adc20fc       lsl x28, x7, x28
0x1659a0bbf908   328  aa3c03fc       mvn x28, x28
0x1659a0bbf90c   32c  7100fcbf       cmp w5, #0x3f (63)
0x1659a0bbf910   330  9a9c00e5       csel x5, x7, x28, eq
0x1659a0bbf914   334  37400156       tbnz w22, #8, #+0x28 (addr 0x1659a0bbf93c)
0x1659a0bbf918   338  120012e7       and w7, w23, #0x1f
0x1659a0bbf91c   33c  1ac72f07       ror w7, w24, w7
0x1659a0bbf920   340  ca0800e7       eor x7, x7, x8
0x1659a0bbf924   344  8a1b00e7       and x7, x7, cp
0x1659a0bbf928   348  8a0500e5       and x5, x7, x5
0x1659a0bbf92c   34c  ca0800a5       eor x5, x5, x8
0x1659a0bbf930   350  92407ca5       and x5, x5, #0xffffffff
0x1659a0bbf934   354  f8396825       str x5, [x1, x25]
0x1659a0bbf938   358  14000af7       b #+0x2bdc (addr 0x1659a0bc2514)
0x1659a0bbf93c   35c  120016e7       and w7, w23, #0x3f
0x1659a0bbf940   360  9ac72f07       ror x7, x24, x7
0x1659a0bbf944   364  ca0800e7       eor x7, x7, x8
0x1659a0bbf948   368  8a1b00e7       and x7, x7, cp
0x1659a0bbf94c   36c  8a0500e5       and x5, x7, x5
0x1659a0bbf950   370  ca0800a5       eor x5, x5, x8
0x1659a0bbf954   374  f8396825       str x5, [x1, x25]
0x1659a0bbf958   378  14000aef       b #+0x2bbc (addr 0x1659a0bc2514)
0x1659a0bbf95c   37c  0b180c05       add w5, w0, w24, lsl #3
0x1659a0bbf960   380  f8656825       ldr x5, [x1, x5]
0x1659a0bbf964   384  d29df487       movz x7, #0xefa4
0x1659a0bbf968   388  f2a00207       movk x7, #0x10, lsl #16
0x1659a0bbf96c   38c  b8676827       ldr w7, [x1, x7]
0x1659a0bbf970   390  120014e7       and w7, w7, #0x3f
0x1659a0bbf974   394  92800008       movn x8, #0x0
0x1659a0bbf978   398  9ac72108       lsl x8, x8, x7
0x1659a0bbf97c   39c  aa2803e8       mvn x8, x8
0x1659a0bbf980   3a0  8a0800b8       and x24, x5, x8
0x1659a0bbf984   3a4  39401af7       ldrb w23, [x23, #6]
0x1659a0bbf988   3a8  0b170c17       add w23, w0, w23, lsl #3
0x1659a0bbf98c   3ac  f8776837       ldr x23, [x1, x23]
0x1659a0bbf990   3b0  9ac726fb       lsr cp, x23, x7
0x1659a0bbf994   3b4  9b1b7f1c       mul x28, x24, cp
0x1659a0bbf998   3b8  9ac72784       lsr x4, x28, x7
0x1659a0bbf99c   3bc  9ac724a6       lsr x6, x5, x7
0x1659a0bbf9a0   3c0  9b1b10c4       madd x4, x6, cp, x4
0x1659a0bbf9a4   3c4  8a0802fb       and cp, x23, x8
0x1659a0bbf9a8   3c8  9b067f66       mul x6, cp, x6
0x1659a0bbf9ac   3cc  9ac724c2       lsr x2, x6, x7
0x1659a0bbf9b0   3d0  8b020082       add x2, x4, x2
0x1659a0bbf9b4   3d4  9b1b7f04       mul x4, x24, cp
0x1659a0bbf9b8   3d8  9ac72484       lsr x4, x4, x7
0x1659a0bbf9bc   3dc  8a080398       and x24, x28, x8
0x1659a0bbf9c0   3e0  8b180084       add x4, x4, x24
0x1659a0bbf9c4   3e4  8a0800c6       and x6, x6, x8
0x1659a0bbf9c8   3e8  8b060084       add x4, x4, x6
0x1659a0bbf9cc   3ec  9ac72484       lsr x4, x4, x7
0x1659a0bbf9d0   3f0  8b040042       add x2, x2, x4
0x1659a0bbf9d4   3f4  360000b6       tbz w22, #0, #+0x14 (addr 0x1659a0bbf9e8)
0x1659a0bbf9d8   3f8  8a97fca4       and x4, x5, x23, asr #63
0x1659a0bbf9dc   3fc  8a85fee5       and x5, x23, x5, asr #63
0x1659a0bbf9e0   400  8b050084       add x4, x4, x5
0x1659a0bbf9e4   404  cb040042       sub x2, x2, x4
0x1659a0bbf9e8   408  71007f3f       cmp w25, #0x1f (31)
0x1659a0bbf9ec   40c  54015940       b.eq #+0x2b28 (addr 0x1659a0bc2514)
0x1659a0bbf9f0   410  0b190c04       add w4, w0, w25, lsl #3
0x1659a0bbf9f4   414  f8246822       str x2, [x1, x4]
0x1659a0bbf9f8   418  14000ac7       b #+0x2b1c (addr 0x1659a0bc2514)
0x1659a0bbf9fc   41c  0b180c02       add w2, w0, w24, lsl #3
0x1659a0bbfa00   420  f8626822       ldr x2, [x1, x2]
0x1659a0bbfa04   424  39401ae4       ldrb w4, [x23, #6]
0x1659a0bbfa08   428  0b040c04       add w4, w0, w4, lsl #3
0x1659a0bbfa0c   42c  f8646824       ldr x4, [x1, x4]
0x1659a0bbfa10   430  37080156       tbnz w22, #1, #+0x28 (addr 0x1659a0bbfa38)
0x1659a0bbfa14   434  370000d6       tbnz w22, #0, #+0x18 (addr 0x1659a0bbfa2c)
0x1659a0bbfa18   438  35000064       cbnz w4, #+0xc (addr 0x1659a0bbfa24)
0x1659a0bbfa1c   43c  aa1403e2       mov x2, x20
0x1659a0bbfa20   440  14000028       b #+0xa0 (addr 0x1659a0bbfac0)
0x1659a0bbfa24   444  1ac40842       udiv w2, w2, w4
0x1659a0bbfa28   448  14000026       b #+0x98 (addr 0x1659a0bbfac0)
0x1659a0bbfa2c   44c  b4ffff84       cbz x4, #-0x10 (addr 0x1659a0bbfa1c)
0x1659a0bbfa30   450  9ac40842       udiv x2, x2, x4
0x1659a0bbfa34   454  14000023       b #+0x8c (addr 0x1659a0bbfac0)
0x1659a0bbfa38   458  37000256       tbnz w22, #0, #+0x48 (addr 0x1659a0bbfa80)
0x1659a0bbfa3c   45c  34ffff04       cbz w4, #-0x20 (addr 0x1659a0bbfa1c)
0x1659a0bbfa40   460  b26183e5       mov x5, #0xffffffff80000000
0x1659a0bbfa44   464  6b05005f       cmp w2, w5
0x1659a0bbfa48   468  9a9f17e5       cset x5, eq
0x1659a0bbfa4c   46c  34000085       cbz w5, #+0x10 (addr 0x1659a0bbfa5c)
0x1659a0bbfa50   470  92800006       movn x6, #0x0
0x1659a0bbfa54   474  6b06009f       cmp w4, w6
0x1659a0bbfa58   478  54000100       b.eq #+0x20 (addr 0x1659a0bbfa78)
0x1659a0bbfa5c   47c  92800006       movn x6, #0x0
0x1659a0bbfa60   480  6b06009f       cmp w4, w6
0x1659a0bbfa64   484  9a9f17e6       cset x6, eq
0x1659a0bbfa68   488  6a0500df       tst w6, w5
0x1659a0bbfa6c   48c  54018e61       b.ne #+0x31cc (addr 0x1659a0bc2c38)
0x1659a0bbfa70   490  1ac40c42       sdiv w2, w2, w4
0x1659a0bbfa74   494  14000013       b #+0x4c (addr 0x1659a0bbfac0)
0x1659a0bbfa78   498  d2b00002       movz x2, #0x80000000
0x1659a0bbfa7c   49c  14000011       b #+0x44 (addr 0x1659a0bbfac0)
0x1659a0bbfa80   4a0  b4fffce4       cbz x4, #-0x64 (addr 0x1659a0bbfa1c)
0x1659a0bbfa84   4a4  d2f00005       movz x5, #0x8000000000000000
0x1659a0bbfa88   4a8  eb05005f       cmp x2, x5
0x1659a0bbfa8c   4ac  9a9f17e6       cset x6, eq
0x1659a0bbfa90   4b0  34000086       cbz w6, #+0x10 (addr 0x1659a0bbfaa0)
0x1659a0bbfa94   4b4  92800007       movn x7, #0x0
0x1659a0bbfa98   4b8  eb07009f       cmp x4, x7
0x1659a0bbfa9c   4bc  54000100       b.eq #+0x20 (addr 0x1659a0bbfabc)
0x1659a0bbfaa0   4c0  92800005       movn x5, #0x0
0x1659a0bbfaa4   4c4  eb05009f       cmp x4, x5
0x1659a0bbfaa8   4c8  9a9f17e5       cset x5, eq
0x1659a0bbfaac   4cc  6a0600bf       tst w5, w6
0x1659a0bbfab0   4d0  54018c21       b.ne #+0x3184 (addr 0x1659a0bc2c34)
0x1659a0bbfab4   4d4  9ac40c42       sdiv x2, x2, x4
0x1659a0bbfab8   4d8  14000002       b #+0x8 (addr 0x1659a0bbfac0)
0x1659a0bbfabc   4dc  aa0503e2       mov x2, x5
0x1659a0bbfac0   4e0  71007f3f       cmp w25, #0x1f (31)
0x1659a0bbfac4   4e4  54015280       b.eq #+0x2a50 (addr 0x1659a0bc2514)
0x1659a0bbfac8   4e8  0b190c04       add w4, w0, w25, lsl #3
0x1659a0bbfacc   4ec  f8246822       str x2, [x1, x4]
0x1659a0bbfad0   4f0  14000a91       b #+0x2a44 (addr 0x1659a0bc2514)
0x1659a0bbfad4   4f4  39401ae2       ldrb w2, [x23, #6]
0x1659a0bbfad8   4f8  0b020c02       add w2, w0, w2, lsl #3
0x1659a0bbfadc   4fc  f8626822       ldr x2, [x1, x2]
0x1659a0bbfae0   500  53030ac4       lsl w4, w22, #29
0x1659a0bbfae4   504  935f7c84       sbfx x4, x4, #31, #1
0x1659a0bbfae8   508  ca040042       eor x2, x2, x4
0x1659a0bbfaec   50c  2a0003e4       mov w4, w0
0x1659a0bbfaf0   510  8b040024       add x4, x1, x4
0x1659a0bbfaf4   514  f9408485       ldr x5, [x4, #264]
0x1659a0bbfaf8   518  0b180c06       add w6, w0, w24, lsl #3
0x1659a0bbfafc   51c  f8666826       ldr x6, [x1, x6]
0x1659a0bbfb00   520  370002d6       tbnz w22, #0, #+0x58 (addr 0x1659a0bbfb58)
0x1659a0bbfb04   524  0b060047       add w7, w2, w6
0x1659a0bbfb08   528  d35d74a5       ubfx x5, x5, #29, #1
0x1659a0bbfb0c   52c  0b0500e5       add w5, w7, w5
0x1659a0bbfb10   530  d2a80008       movz x8, #0x40000000
0x1659a0bbfb14   534  6a0500bf       tst w5, w5
0x1659a0bbfb18   538  9a8813e8       csel x8, xzr, x8, ne
0x1659a0bbfb1c   53c  120100b7       and w23, w5, #0x80000000
0x1659a0bbfb20   540  aa170108       orr x8, x8, x23
0x1659a0bbfb24   544  d2a40017       movz x23, #0x20000000
0x1659a0bbfb28   548  6b0700bf       cmp w5, w7
0x1659a0bbfb2c   54c  9a9432f8       csel x24, x23, x20, lo
0x1659a0bbfb30   550  6b0200ff       cmp w7, w2
0x1659a0bbfb34   554  9a9832e7       csel x7, x23, x24, lo
0x1659a0bbfb38   558  aa070107       orr x7, x8, x7
0x1659a0bbfb3c   55c  4a0600a6       eor w6, w5, w6
0x1659a0bbfb40   560  4a0200a2       eor w2, w5, w2
0x1659a0bbfb44   564  0a0200c2       and w2, w6, w2
0x1659a0bbfb48   568  53037c42       lsr w2, w2, #3
0x1659a0bbfb4c   56c  12040042       and w2, w2, #0x10000000
0x1659a0bbfb50   570  aa0200e2       orr x2, x7, x2
0x1659a0bbfb54   574  14000017       b #+0x5c (addr 0x1659a0bbfbb0)
0x1659a0bbfb58   578  d35d74a5       ubfx x5, x5, #29, #1
0x1659a0bbfb5c   57c  8b060047       add x7, x2, x6
0x1659a0bbfb60   580  8b0700a8       add x8, x5, x7
0x1659a0bbfb64   584  d360fd17       lsr x23, x8, #32
0x1659a0bbfb68   588  926102f7       and x23, x23, #0x80000000
0x1659a0bbfb6c   58c  d2a80018       movz x24, #0x40000000
0x1659a0bbfb70   590  f100011f       cmp x8, #0x0 (0)
0x1659a0bbfb74   594  9a9f0318       csel x24, x24, xzr, eq
0x1659a0bbfb78   598  aa1802f7       orr x23, x23, x24
0x1659a0bbfb7c   59c  d2a4001b       movz cp, #0x20000000
0x1659a0bbfb80   5a0  eb05011f       cmp x8, x5
0x1659a0bbfb84   5a4  9a9f3365       csel x5, cp, xzr, lo
0x1659a0bbfb88   5a8  eb0200ff       cmp x7, x2
0x1659a0bbfb8c   5ac  9a853365       csel x5, cp, x5, lo
0x1659a0bbfb90   5b0  aa0502e5       orr x5, x23, x5
0x1659a0bbfb94   5b4  ca060106       eor x6, x8, x6
0x1659a0bbfb98   5b8  ca020102       eor x2, x8, x2
0x1659a0bbfb9c   5bc  8a0200c2       and x2, x6, x2
0x1659a0bbfba0   5c0  d363fc42       lsr x2, x2, #35
0x1659a0bbfba4   5c4  92640042       and x2, x2, #0x10000000
0x1659a0bbfba8   5c8  aa0200a2       orr x2, x5, x2
0x1659a0bbfbac   5cc  aa0803e5       mov x5, x8
0x1659a0bbfbb0   5d0  36080056       tbz w22, #1, #+0x8 (addr 0x1659a0bbfbb8)
0x1659a0bbfbb4   5d4  f9008482       str x2, [x4, #264]
0x1659a0bbfbb8   5d8  71007f3f       cmp w25, #0x1f (31)
0x1659a0bbfbbc   5dc  54014ac0       b.eq #+0x2958 (addr 0x1659a0bc2514)
0x1659a0bbfbc0   5e0  0b190c02       add w2, w0, w25, lsl #3
0x1659a0bbfbc4   5e4  f8226825       str x5, [x1, x2]
0x1659a0bbfbc8   5e8  14000a53       b #+0x294c (addr 0x1659a0bc2514)
0x1659a0bbfbcc   5ec  0b180c02       add w2, w0, w24, lsl #3
0x1659a0bbfbd0   5f0  f8626822       ldr x2, [x1, x2]
0x1659a0bbfbd4   5f4  71007f1f       cmp w24, #0x1f (31)
0x1659a0bbfbd8   5f8  54000061       b.ne #+0xc (addr 0x1659a0bbfbe4)
0x1659a0bbfbdc   5fc  f2400c5f       tst x2, #0xf
0x1659a0bbfbe0   600  540160e1       b.ne #+0x2c1c (addr 0x1659a0bc27fc)
0x1659a0bbfbe4   604  531e7ec4       lsr w4, w22, #30
0x1659a0bbfbe8   608  d2800025       movz x5, #0x1
0x1659a0bbfbec   60c  1ac420a5       lsl w5, w5, w4
0x1659a0bbfbf0   610  d10004a6       sub x6, x5, #0x1 (1)
0x1659a0bbfbf4   614  ea06005f       tst x2, x6
0x1659a0bbfbf8   618  54016021       b.ne #+0x2c04 (addr 0x1659a0bc27fc)
0x1659a0bbfbfc   61c  3401600b       cbz w11, #+0x2c00 (addr 0x1659a0bc27fc)
0x1659a0bbfc00   620  53057c47       lsr w7, w2, #5
0x1659a0bbfc04   624  121934e7       and w7, w7, #0x1fff80
0x1659a0bbfc08   628  0b070167       add w7, w11, w7
0x1659a0bbfc0c   62c  8b070027       add x7, x1, x7
0x1659a0bbfc10   630  f94008e8       ldr x8, [x7, #16]
0x1659a0bbfc14   634  8b060046       add x6, x2, x6
0x1659a0bbfc18   638  b2402cc6       orr x6, x6, #0xfff
0x1659a0bbfc1c   63c  eb06011f       cmp x8, x6
0x1659a0bbfc20   640  54015ee1       b.ne #+0x2bdc (addr 0x1659a0bc27fc)
0x1659a0bbfc24   644  510004a5       sub w5, w5, #0x1 (1)
0x1659a0bbfc28   648  f9400ce6       ldr x6, [x7, #24]
0x1659a0bbfc2c   64c  8b0200c2       add x2, x6, x2
0x1659a0bbfc30   650  6a0200bf       tst w5, w2
0x1659a0bbfc34   654  54015e41       b.ne #+0x2bc8 (addr 0x1659a0bc27fc)
0x1659a0bbfc38   658  928000e6       movn x6, #0x7
0x1659a0bbfc3c   65c  1ac420c4       lsl w4, w6, w4
0x1659a0bbfc40   660  11010084       add w4, w4, #0x40 (64)
0x1659a0bbfc44   664  12001484       and w4, w4, #0x3f
0x1659a0bbfc48   668  92800006       movn x6, #0x0
0x1659a0bbfc4c   66c  9ac424c4       lsr x4, x6, x4
0x1659a0bbfc50   670  39401ae6       ldrb w6, [x23, #6]
0x1659a0bbfc54   674  71007cdf       cmp w6, #0x1f (31)
0x1659a0bbfc58   678  540000a0       b.eq #+0x14 (addr 0x1659a0bbfc6c)
0x1659a0bbfc5c   67c  0b060c07       add w7, w0, w6, lsl #3
0x1659a0bbfc60   680  f8676827       ldr x7, [x1, x7]
0x1659a0bbfc64   684  8a0400e7       and x7, x7, x4
0x1659a0bbfc68   688  14000002       b #+0x8 (addr 0x1659a0bbfc70)
0x1659a0bbfc6c   68c  aa1403e7       mov x7, x20
0x1659a0bbfc70   690  71007f3f       cmp w25, #0x1f (31)
0x1659a0bbfc74   694  540000a0       b.eq #+0x14 (addr 0x1659a0bbfc88)
0x1659a0bbfc78   698  0b190c08       add w8, w0, w25, lsl #3
0x1659a0bbfc7c   69c  f8686828       ldr x8, [x1, x8]
0x1659a0bbfc80   6a0  8a040104       and x4, x8, x4
0x1659a0bbfc84   6a4  14000002       b #+0x8 (addr 0x1659a0bbfc8c)
0x1659a0bbfc88   6a8  aa1403e4       mov x4, x20
0x1659a0bbfc8c   6ac  710008bf       cmp w5, #0x2 (2)
0x1659a0bbfc90   6b0  540000cb       b.lt #+0x18 (addr 0x1659a0bbfca8)
0x1659a0bbfc94   6b4  710008bf       cmp w5, #0x2 (2)
0x1659a0bbfc98   6b8  540001e0       b.eq #+0x3c (addr 0x1659a0bbfcd4)
0x1659a0bbfc9c   6bc  71000cbf       cmp w5, #0x3 (3)
0x1659a0bbfca0   6c0  540000c0       b.eq #+0x18 (addr 0x1659a0bbfcb8)
0x1659a0bbfca4   6c4  1400000c       b #+0x30 (addr 0x1659a0bbfcd4)
0x1659a0bbfca8   6c8  34000325       cbz w5, #+0x64 (addr 0x1659a0bbfd0c)
0x1659a0bbfcac   6cc  710004bf       cmp w5, #0x1 (1)
0x1659a0bbfcb0   6d0  54000200       b.eq #+0x40 (addr 0x1659a0bbfcf0)
0x1659a0bbfcb4   6d4  14000008       b #+0x20 (addr 0x1659a0bbfcd4)
0x1659a0bbfcb8   6d8  2a0203e2       mov w2, w2
0x1659a0bbfcbc   6dc  8b020025       add x5, x1, x2
0x1659a0bbfcc0   6e0  f24004bf       tst x5, #0x3
0x1659a0bbfcc4   6e4  54017b61       b.ne #+0x2f6c (addr 0x1659a0bc2c30)
0x1659a0bbfcc8   6e8  8b020022       add x2, x1, x2
0x1659a0bbfccc   6ec  88e7fc44       casal w7, w4, [x2]
0x1659a0bbfcd0   6f0  14000012       b #+0x48 (addr 0x1659a0bbfd18)
0x1659a0bbfcd4   6f4  2a0203e2       mov w2, w2
0x1659a0bbfcd8   6f8  8b020025       add x5, x1, x2
0x1659a0bbfcdc   6fc  f24008bf       tst x5, #0x7
0x1659a0bbfce0   700  54017a61       b.ne #+0x2f4c (addr 0x1659a0bc2c2c)
0x1659a0bbfce4   704  8b020022       add x2, x1, x2
0x1659a0bbfce8   708  c8e7fc44       casal x7, x4, [x2]
0x1659a0bbfcec   70c  1400000b       b #+0x2c (addr 0x1659a0bbfd18)
0x1659a0bbfcf0   710  2a0203e2       mov w2, w2
0x1659a0bbfcf4   714  8b020025       add x5, x1, x2
0x1659a0bbfcf8   718  f24000bf       tst x5, #0x1
0x1659a0bbfcfc   71c  54017961       b.ne #+0x2f2c (addr 0x1659a0bc2c28)
0x1659a0bbfd00   720  8b020022       add x2, x1, x2
0x1659a0bbfd04   724  48e7fc44       casalh w7, w4, [x2]
0x1659a0bbfd08   728  14000004       b #+0x10 (addr 0x1659a0bbfd18)
0x1659a0bbfd0c   72c  2a0203e2       mov w2, w2
0x1659a0bbfd10   730  8b020022       add x2, x1, x2
0x1659a0bbfd14   734  08e7fc44       casalb w7, w4, [x2]
0x1659a0bbfd18   738  71007cdf       cmp w6, #0x1f (31)
0x1659a0bbfd1c   73c  54013fc0       b.eq #+0x27f8 (addr 0x1659a0bc2514)
0x1659a0bbfd20   740  0b060c02       add w2, w0, w6, lsl #3
0x1659a0bbfd24   744  f8226827       str x7, [x1, x2]
0x1659a0bbfd28   748  140009fb       b #+0x27ec (addr 0x1659a0bc2514)
0x1659a0bbfd2c   74c  2a0003e2       mov w2, w0
0x1659a0bbfd30   750  8b020022       add x2, x1, x2
0x1659a0bbfd34   754  394d0044       ldrb w4, [x2, #832]
0x1659a0bbfd38   758  721e049f       tst w4, #0xc
0x1659a0bbfd3c   75c  54000061       b.ne #+0xc (addr 0x1659a0bbfd48)
0x1659a0bbfd40   760  394de442       ldrb w2, [x2, #889]
0x1659a0bbfd44   764  363155c2       tbz w2, #6, #+0x2ab8 (addr 0x1659a0bc27fc)
0x1659a0bbfd48   768  340155ab       cbz w11, #+0x2ab4 (addr 0x1659a0bc27fc)
0x1659a0bbfd4c   76c  0b190c02       add w2, w0, w25, lsl #3
0x1659a0bbfd50   770  f8626822       ldr x2, [x1, x2]
0x1659a0bbfd54   774  53057c44       lsr w4, w2, #5
0x1659a0bbfd58   778  12193484       and w4, w4, #0x1fff80
0x1659a0bbfd5c   77c  0b040164       add w4, w11, w4
0x1659a0bbfd60   780  8b040024       add x4, x1, x4
0x1659a0bbfd64   784  f9400885       ldr x5, [x4, #16]
0x1659a0bbfd68   788  b2402c46       orr x6, x2, #0xfff
0x1659a0bbfd6c   78c  eb0600bf       cmp x5, x6
0x1659a0bbfd70   790  54015461       b.ne #+0x2a8c (addr 0x1659a0bc27fc)
0x1659a0bbfd74   794  f9400c84       ldr x4, [x4, #24]
0x1659a0bbfd78   798  927a6442       and x2, x2, #0xffffffc0
0x1659a0bbfd7c   79c  8b020082       add x2, x4, x2
0x1659a0bbfd80   7a0  7200085f       tst w2, #0x7
0x1659a0bbfd84   7a4  540153c1       b.ne #+0x2a78 (addr 0x1659a0bc27fc)
0x1659a0bbfd88   7a8  2a0203e2       mov w2, w2
0x1659a0bbfd8c   7ac  8b020024       add x4, x1, x2
0x1659a0bbfd90   7b0  f240089f       tst x4, #0x7
0x1659a0bbfd94   7b4  54017481       b.ne #+0x2e90 (addr 0x1659a0bc2c24)
0x1659a0bbfd98   7b8  8b020024       add x4, x1, x2
0x1659a0bbfd9c   7bc  c89ffc94       stlr x20, [x4]
0x1659a0bbfda0   7c0  91002024       add x4, x1, #0x8 (8)
0x1659a0bbfda4   7c4  8b020085       add x5, x4, x2
0x1659a0bbfda8   7c8  f24008bf       tst x5, #0x7
0x1659a0bbfdac   7cc  540173a1       b.ne #+0x2e74 (addr 0x1659a0bc2c20)
0x1659a0bbfdb0   7d0  8b020085       add x5, x4, x2
0x1659a0bbfdb4   7d4  c89ffcb4       stlr x20, [x5]
0x1659a0bbfdb8   7d8  91004024       add x4, x1, #0x10 (16)
0x1659a0bbfdbc   7dc  8b020085       add x5, x4, x2
0x1659a0bbfdc0   7e0  f24008bf       tst x5, #0x7
0x1659a0bbfdc4   7e4  540172c1       b.ne #+0x2e58 (addr 0x1659a0bc2c1c)
0x1659a0bbfdc8   7e8  8b020085       add x5, x4, x2
0x1659a0bbfdcc   7ec  c89ffcb4       stlr x20, [x5]
0x1659a0bbfdd0   7f0  91006024       add x4, x1, #0x18 (24)
0x1659a0bbfdd4   7f4  8b020085       add x5, x4, x2
0x1659a0bbfdd8   7f8  f24008bf       tst x5, #0x7
0x1659a0bbfddc   7fc  540171e1       b.ne #+0x2e3c (addr 0x1659a0bc2c18)
0x1659a0bbfde0   800  8b020085       add x5, x4, x2
0x1659a0bbfde4   804  c89ffcb4       stlr x20, [x5]
0x1659a0bbfde8   808  91008024       add x4, x1, #0x20 (32)
0x1659a0bbfdec   80c  8b020085       add x5, x4, x2
0x1659a0bbfdf0   810  f24008bf       tst x5, #0x7
0x1659a0bbfdf4   814  54017101       b.ne #+0x2e20 (addr 0x1659a0bc2c14)
0x1659a0bbfdf8   818  8b020085       add x5, x4, x2
0x1659a0bbfdfc   81c  c89ffcb4       stlr x20, [x5]
0x1659a0bbfe00   820  9100a024       add x4, x1, #0x28 (40)
0x1659a0bbfe04   824  8b020085       add x5, x4, x2
0x1659a0bbfe08   828  f24008bf       tst x5, #0x7
0x1659a0bbfe0c   82c  54017021       b.ne #+0x2e04 (addr 0x1659a0bc2c10)
0x1659a0bbfe10   830  8b020085       add x5, x4, x2
0x1659a0bbfe14   834  c89ffcb4       stlr x20, [x5]
0x1659a0bbfe18   838  9100c024       add x4, x1, #0x30 (48)
0x1659a0bbfe1c   83c  8b020085       add x5, x4, x2
0x1659a0bbfe20   840  f24008bf       tst x5, #0x7
0x1659a0bbfe24   844  54016f41       b.ne #+0x2de8 (addr 0x1659a0bc2c0c)
0x1659a0bbfe28   848  8b020085       add x5, x4, x2
0x1659a0bbfe2c   84c  c89ffcb4       stlr x20, [x5]
0x1659a0bbfe30   850  9100e024       add x4, x1, #0x38 (56)
0x1659a0bbfe34   854  8b020085       add x5, x4, x2
0x1659a0bbfe38   858  f24008bf       tst x5, #0x7
0x1659a0bbfe3c   85c  54016e61       b.ne #+0x2dcc (addr 0x1659a0bc2c08)
0x1659a0bbfe40   860  8b020085       add x5, x4, x2
0x1659a0bbfe44   864  c89ffcb4       stlr x20, [x5]
0x1659a0bbfe48   868  140009b3       b #+0x26cc (addr 0x1659a0bc2514)
0x1659a0bbfe4c   86c  d5033bbf       dmb ish
0x1659a0bbfe50   870  140009b1       b #+0x26c4 (addr 0x1659a0bc2514)
0x1659a0bbfe54   874  0b180c02       add w2, w0, w24, lsl #3
0x1659a0bbfe58   878  f8626822       ldr x2, [x1, x2]
0x1659a0bbfe5c   87c  71007f1f       cmp w24, #0x1f (31)
0x1659a0bbfe60   880  54000061       b.ne #+0xc (addr 0x1659a0bbfe6c)
0x1659a0bbfe64   884  f2400c5f       tst x2, #0xf
0x1659a0bbfe68   888  54014ca1       b.ne #+0x2994 (addr 0x1659a0bc27fc)
0x1659a0bbfe6c   88c  531e7ec4       lsr w4, w22, #30
0x1659a0bbfe70   890  d2800025       movz x5, #0x1
0x1659a0bbfe74   894  1ac420a4       lsl w4, w5, w4
0x1659a0bbfe78   898  d1000485       sub x5, x4, #0x1 (1)
0x1659a0bbfe7c   89c  ea05005f       tst x2, x5
0x1659a0bbfe80   8a0  54014be1       b.ne #+0x297c (addr 0x1659a0bc27fc)
0x1659a0bbfe84   8a4  2a0003e6       mov w6, w0
0x1659a0bbfe88   8a8  8b060026       add x6, x1, x6
0x1659a0bbfe8c   8ac  f94090c7       ldr x7, [x6, #288]
0x1659a0bbfe90   8b0  f94088c8       ldr x8, [x6, #272]
0x1659a0bbfe94   8b4  eb02011f       cmp x8, x2
0x1659a0bbfe98   8b8  54000060       b.eq #+0xc (addr 0x1659a0bbfea4)
0x1659a0bbfe9c   8bc  37b801d6       tbnz w22, #23, #+0x38 (addr 0x1659a0bbfed4)
0x1659a0bbfea0   8c0  14000005       b #+0x14 (addr 0x1659a0bbfeb4)
0x1659a0bbfea4   8c4  37b80196       tbnz w22, #23, #+0x30 (addr 0x1659a0bbfed4)
0x1659a0bbfea8   8c8  f9408cc8       ldr x8, [x6, #280]
0x1659a0bbfeac   8cc  eb04011f       cmp x8, x4
0x1659a0bbfeb0   8d0  54000120       b.eq #+0x24 (addr 0x1659a0bbfed4)
0x1659a0bbfeb4   8d4  f9008cdf       str xzr, [x6, #280]
0x1659a0bbfeb8   8d8  39401ae2       ldrb w2, [x23, #6]
0x1659a0bbfebc   8dc  71007c5f       cmp w2, #0x1f (31)
0x1659a0bbfec0   8e0  540132a0       b.eq #+0x2654 (addr 0x1659a0bc2514)
0x1659a0bbfec4   8e4  0b020c02       add w2, w0, w2, lsl #3
0x1659a0bbfec8   8e8  d2800024       movz x4, #0x1
0x1659a0bbfecc   8ec  f8226824       str x4, [x1, x2]
0x1659a0bbfed0   8f0  14000991       b #+0x2644 (addr 0x1659a0bc2514)
0x1659a0bbfed4   8f4  3401494b       cbz w11, #+0x2928 (addr 0x1659a0bc27fc)
0x1659a0bbfed8   8f8  53057c48       lsr w8, w2, #5
0x1659a0bbfedc   8fc  12193508       and w8, w8, #0x1fff80
0x1659a0bbfee0   900  0b080168       add w8, w11, w8
0x1659a0bbfee4   904  8b080028       add x8, x1, x8
0x1659a0bbfee8   908  f9400918       ldr x24, [x8, #16]
0x1659a0bbfeec   90c  8b050045       add x5, x2, x5
0x1659a0bbfef0   910  b2402ca5       orr x5, x5, #0xfff
0x1659a0bbfef4   914  eb05031f       cmp x24, x5
0x1659a0bbfef8   918  54014821       b.ne #+0x2904 (addr 0x1659a0bc27fc)
0x1659a0bbfefc   91c  51000484       sub w4, w4, #0x1 (1)
0x1659a0bbff00   920  f9400d05       ldr x5, [x8, #24]
0x1659a0bbff04   924  8b0200a2       add x2, x5, x2
0x1659a0bbff08   928  6a02009f       tst w4, w2
0x1659a0bbff0c   92c  54014781       b.ne #+0x28f0 (addr 0x1659a0bc27fc)
0x1659a0bbff10   930  0b190c05       add w5, w0, w25, lsl #3
0x1659a0bbff14   934  f8656825       ldr x5, [x1, x5]
0x1659a0bbff18   938  37b80716       tbnz w22, #23, #+0xe0 (addr 0x1659a0bbfff8)
0x1659a0bbff1c   93c  7100089f       cmp w4, #0x2 (2)
0x1659a0bbff20   940  540000cb       b.lt #+0x18 (addr 0x1659a0bbff38)
0x1659a0bbff24   944  7100089f       cmp w4, #0x2 (2)
0x1659a0bbff28   948  54000240       b.eq #+0x48 (addr 0x1659a0bbff70)
0x1659a0bbff2c   94c  71000c9f       cmp w4, #0x3 (3)
0x1659a0bbff30   950  540000c0       b.eq #+0x18 (addr 0x1659a0bbff48)
0x1659a0bbff34   954  1400000f       b #+0x3c (addr 0x1659a0bbff70)
0x1659a0bbff38   958  34000444       cbz w4, #+0x88 (addr 0x1659a0bbffc0)
0x1659a0bbff3c   95c  7100049f       cmp w4, #0x1 (1)
0x1659a0bbff40   960  540002c0       b.eq #+0x58 (addr 0x1659a0bbff98)
0x1659a0bbff44   964  1400000b       b #+0x2c (addr 0x1659a0bbff70)
0x1659a0bbff48   968  2a0203e2       mov w2, w2
0x1659a0bbff4c   96c  8b020024       add x4, x1, x2
0x1659a0bbff50   970  f240049f       tst x4, #0x3
0x1659a0bbff54   974  54016581       b.ne #+0x2cb0 (addr 0x1659a0bc2c04)
0x1659a0bbff58   978  aa0703e4       mov x4, x7
0x1659a0bbff5c   97c  8b020022       add x2, x1, x2
0x1659a0bbff60   980  88e4fc45       casal w4, w5, [x2]
0x1659a0bbff64   984  6b07009f       cmp w4, w7
0x1659a0bbff68   988  9a9f17e2       cset x2, eq
0x1659a0bbff6c   98c  1400001b       b #+0x6c (addr 0x1659a0bbffd8)
0x1659a0bbff70   990  2a0203e2       mov w2, w2
0x1659a0bbff74   994  8b020024       add x4, x1, x2
0x1659a0bbff78   998  f240089f       tst x4, #0x7
0x1659a0bbff7c   99c  54016421       b.ne #+0x2c84 (addr 0x1659a0bc2c00)
0x1659a0bbff80   9a0  aa0703e4       mov x4, x7
0x1659a0bbff84   9a4  8b020022       add x2, x1, x2
0x1659a0bbff88   9a8  c8e4fc45       casal x4, x5, [x2]
0x1659a0bbff8c   9ac  eb07009f       cmp x4, x7
0x1659a0bbff90   9b0  9a9f17e2       cset x2, eq
0x1659a0bbff94   9b4  14000011       b #+0x44 (addr 0x1659a0bbffd8)
0x1659a0bbff98   9b8  2a0203e2       mov w2, w2
0x1659a0bbff9c   9bc  8b020024       add x4, x1, x2
0x1659a0bbffa0   9c0  f240009f       tst x4, #0x1
0x1659a0bbffa4   9c4  540162c1       b.ne #+0x2c58 (addr 0x1659a0bc2bfc)
0x1659a0bbffa8   9c8  aa0703e4       mov x4, x7
0x1659a0bbffac   9cc  8b020022       add x2, x1, x2
0x1659a0bbffb0   9d0  48e4fc45       casalh w4, w5, [x2]
0x1659a0bbffb4   9d4  6b27209f       cmp w4, w7, uxth
0x1659a0bbffb8   9d8  9a9f17e2       cset x2, eq
0x1659a0bbffbc   9dc  14000007       b #+0x1c (addr 0x1659a0bbffd8)
0x1659a0bbffc0   9e0  2a0203e2       mov w2, w2
0x1659a0bbffc4   9e4  aa0703e4       mov x4, x7
0x1659a0bbffc8   9e8  8b020022       add x2, x1, x2
0x1659a0bbffcc   9ec  08e4fc45       casalb w4, w5, [x2]
0x1659a0bbffd0   9f0  6b27009f       cmp w4, w7, uxtb
0x1659a0bbffd4   9f4  9a9f17e2       cset x2, eq
0x1659a0bbffd8   9f8  f9008cdf       str xzr, [x6, #280]
0x1659a0bbffdc   9fc  39401ae4       ldrb w4, [x23, #6]
0x1659a0bbffe0   a00  71007c9f       cmp w4, #0x1f (31)
0x1659a0bbffe4   a04  54012980       b.eq #+0x2530 (addr 0x1659a0bc2514)
0x1659a0bbffe8   a08  0b040c04       add w4, w0, w4, lsl #3
0x1659a0bbffec   a0c  52000042       eor w2, w2, #0x1
0x1659a0bbfff0   a10  f8246822       str x2, [x1, x4]
0x1659a0bbfff4   a14  14000948       b #+0x2520 (addr 0x1659a0bc2514)
0x1659a0bbfff8   a18  7100089f       cmp w4, #0x2 (2)
0x1659a0bbfffc   a1c  540000cb       b.lt #+0x18 (addr 0x1659a0bc0014)
0x1659a0bc0000   a20  7100089f       cmp w4, #0x2 (2)
0x1659a0bc0004   a24  540001e0       b.eq #+0x3c (addr 0x1659a0bc0040)
0x1659a0bc0008   a28  71000c9f       cmp w4, #0x3 (3)
0x1659a0bc000c   a2c  540000c0       b.eq #+0x18 (addr 0x1659a0bc0024)
0x1659a0bc0010   a30  1400000c       b #+0x30 (addr 0x1659a0bc0040)
0x1659a0bc0014   a34  34000324       cbz w4, #+0x64 (addr 0x1659a0bc0078)
0x1659a0bc0018   a38  7100049f       cmp w4, #0x1 (1)
0x1659a0bc001c   a3c  54000200       b.eq #+0x40 (addr 0x1659a0bc005c)
0x1659a0bc0020   a40  14000008       b #+0x20 (addr 0x1659a0bc0040)
0x1659a0bc0024   a44  2a0203e2       mov w2, w2
0x1659a0bc0028   a48  8b020024       add x4, x1, x2
0x1659a0bc002c   a4c  f240049f       tst x4, #0x3
0x1659a0bc0030   a50  54015e41       b.ne #+0x2bc8 (addr 0x1659a0bc2bf8)
0x1659a0bc0034   a54  8b020024       add x4, x1, x2
0x1659a0bc0038   a58  889ffc85       stlr w5, [x4]
0x1659a0bc003c   a5c  14000936       b #+0x24d8 (addr 0x1659a0bc2514)
0x1659a0bc0040   a60  2a0203e2       mov w2, w2
0x1659a0bc0044   a64  8b020024       add x4, x1, x2
0x1659a0bc0048   a68  f240089f       tst x4, #0x7
0x1659a0bc004c   a6c  54015d41       b.ne #+0x2ba8 (addr 0x1659a0bc2bf4)
0x1659a0bc0050   a70  8b020024       add x4, x1, x2
0x1659a0bc0054   a74  c89ffc85       stlr x5, [x4]
0x1659a0bc0058   a78  1400092f       b #+0x24bc (addr 0x1659a0bc2514)
0x1659a0bc005c   a7c  2a0203e2       mov w2, w2
0x1659a0bc0060   a80  8b020024       add x4, x1, x2
0x1659a0bc0064   a84  f240009f       tst x4, #0x1
0x1659a0bc0068   a88  54015c41       b.ne #+0x2b88 (addr 0x1659a0bc2bf0)
0x1659a0bc006c   a8c  8b020024       add x4, x1, x2
0x1659a0bc0070   a90  489ffc85       stlrh w5, [x4]
0x1659a0bc0074   a94  14000928       b #+0x24a0 (addr 0x1659a0bc2514)
0x1659a0bc0078   a98  2a0203e2       mov w2, w2
0x1659a0bc007c   a9c  8b020024       add x4, x1, x2
0x1659a0bc0080   aa0  089ffc85       stlrb w5, [x4]
0x1659a0bc0084   aa4  14000924       b #+0x2490 (addr 0x1659a0bc2514)
0x1659a0bc0088   aa8  0b180c02       add w2, w0, w24, lsl #3
0x1659a0bc008c   aac  f8626822       ldr x2, [x1, x2]
0x1659a0bc0090   ab0  71007f1f       cmp w24, #0x1f (31)
0x1659a0bc0094   ab4  54000061       b.ne #+0xc (addr 0x1659a0bc00a0)
0x1659a0bc0098   ab8  f2400c5f       tst x2, #0xf
0x1659a0bc009c   abc  54013b01       b.ne #+0x2760 (addr 0x1659a0bc27fc)
0x1659a0bc00a0   ac0  531e7ec4       lsr w4, w22, #30
0x1659a0bc00a4   ac4  d2800025       movz x5, #0x1
0x1659a0bc00a8   ac8  1ac420a4       lsl w4, w5, w4
0x1659a0bc00ac   acc  d1000485       sub x5, x4, #0x1 (1)
0x1659a0bc00b0   ad0  ea05005f       tst x2, x5
0x1659a0bc00b4   ad4  54013a41       b.ne #+0x2748 (addr 0x1659a0bc27fc)
0x1659a0bc00b8   ad8  34013a2b       cbz w11, #+0x2744 (addr 0x1659a0bc27fc)
0x1659a0bc00bc   adc  53057c46       lsr w6, w2, #5
0x1659a0bc00c0   ae0  121934c6       and w6, w6, #0x1fff80
0x1659a0bc00c4   ae4  0b060166       add w6, w11, w6
0x1659a0bc00c8   ae8  f8666827       ldr x7, [x1, x6]
0x1659a0bc00cc   aec  8b050045       add x5, x2, x5
0x1659a0bc00d0   af0  b2402ca5       orr x5, x5, #0xfff
0x1659a0bc00d4   af4  eb0500ff       cmp x7, x5
0x1659a0bc00d8   af8  54013921       b.ne #+0x2724 (addr 0x1659a0bc27fc)
0x1659a0bc00dc   afc  51000485       sub w5, w4, #0x1 (1)
0x1659a0bc00e0   b00  8b060026       add x6, x1, x6
0x1659a0bc00e4   b04  f94004c6       ldr x6, [x6, #8]
0x1659a0bc00e8   b08  8b0200c6       add x6, x6, x2
0x1659a0bc00ec   b0c  6a0600bf       tst w5, w6
0x1659a0bc00f0   b10  54013861       b.ne #+0x270c (addr 0x1659a0bc27fc)
0x1659a0bc00f4   b14  710008bf       cmp w5, #0x2 (2)
0x1659a0bc00f8   b18  540000cb       b.lt #+0x18 (addr 0x1659a0bc0110)
0x1659a0bc00fc   b1c  710008bf       cmp w5, #0x2 (2)
0x1659a0bc0100   b20  540001e0       b.eq #+0x3c (addr 0x1659a0bc013c)
0x1659a0bc0104   b24  71000cbf       cmp w5, #0x3 (3)
0x1659a0bc0108   b28  540000c0       b.eq #+0x18 (addr 0x1659a0bc0120)
0x1659a0bc010c   b2c  1400000c       b #+0x30 (addr 0x1659a0bc013c)
0x1659a0bc0110   b30  34000325       cbz w5, #+0x64 (addr 0x1659a0bc0174)
0x1659a0bc0114   b34  710004bf       cmp w5, #0x1 (1)
0x1659a0bc0118   b38  54000200       b.eq #+0x40 (addr 0x1659a0bc0158)
0x1659a0bc011c   b3c  14000008       b #+0x20 (addr 0x1659a0bc013c)
0x1659a0bc0120   b40  2a0603e5       mov w5, w6
0x1659a0bc0124   b44  8b050026       add x6, x1, x5
0x1659a0bc0128   b48  f24004df       tst x6, #0x3
0x1659a0bc012c   b4c  54015601       b.ne #+0x2ac0 (addr 0x1659a0bc2bec)
0x1659a0bc0130   b50  8b050026       add x6, x1, x5
0x1659a0bc0134   b54  88dffcc5       ldar w5, [x6]
0x1659a0bc0138   b58  14000012       b #+0x48 (addr 0x1659a0bc0180)
0x1659a0bc013c   b5c  2a0603e5       mov w5, w6
0x1659a0bc0140   b60  8b050026       add x6, x1, x5
0x1659a0bc0144   b64  f24008df       tst x6, #0x7
0x1659a0bc0148   b68  54015501       b.ne #+0x2aa0 (addr 0x1659a0bc2be8)
0x1659a0bc014c   b6c  8b050026       add x6, x1, x5
0x1659a0bc0150   b70  c8dffcc5       ldar x5, [x6]
0x1659a0bc0154   b74  1400000b       b #+0x2c (addr 0x1659a0bc0180)
0x1659a0bc0158   b78  2a0603e5       mov w5, w6
0x1659a0bc015c   b7c  8b050026       add x6, x1, x5
0x1659a0bc0160   b80  f24000df       tst x6, #0x1
0x1659a0bc0164   b84  54015401       b.ne #+0x2a80 (addr 0x1659a0bc2be4)
0x1659a0bc0168   b88  8b050026       add x6, x1, x5
0x1659a0bc016c   b8c  48dffcc5       ldarh w5, [x6]
0x1659a0bc0170   b90  14000004       b #+0x10 (addr 0x1659a0bc0180)
0x1659a0bc0174   b94  2a0603e5       mov w5, w6
0x1659a0bc0178   b98  8b050026       add x6, x1, x5
0x1659a0bc017c   b9c  08dffcc5       ldarb w5, [x6]
0x1659a0bc0180   ba0  37b800f6       tbnz w22, #23, #+0x1c (addr 0x1659a0bc019c)
0x1659a0bc0184   ba4  2a0003e6       mov w6, w0
0x1659a0bc0188   ba8  8b060026       add x6, x1, x6
0x1659a0bc018c   bac  f90094df       str xzr, [x6, #296]
0x1659a0bc0190   bb0  f90090c5       str x5, [x6, #288]
0x1659a0bc0194   bb4  f9008cc4       str x4, [x6, #280]
0x1659a0bc0198   bb8  f90088c2       str x2, [x6, #272]
0x1659a0bc019c   bbc  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc01a0   bc0  54011ba0       b.eq #+0x2374 (addr 0x1659a0bc2514)
0x1659a0bc01a4   bc4  0b190c02       add w2, w0, w25, lsl #3
0x1659a0bc01a8   bc8  f8226825       str x5, [x1, x2]
0x1659a0bc01ac   bcc  140008da       b #+0x2368 (addr 0x1659a0bc2514)
0x1659a0bc01b0   bd0  0b180c02       add w2, w0, w24, lsl #3
0x1659a0bc01b4   bd4  f8626822       ldr x2, [x1, x2]
0x1659a0bc01b8   bd8  71007f1f       cmp w24, #0x1f (31)
0x1659a0bc01bc   bdc  54000061       b.ne #+0xc (addr 0x1659a0bc01c8)
0x1659a0bc01c0   be0  f2400c5f       tst x2, #0xf
0x1659a0bc01c4   be4  540131c1       b.ne #+0x2638 (addr 0x1659a0bc27fc)
0x1659a0bc01c8   be8  37f01936       tbnz w22, #30, #+0x324 (addr 0x1659a0bc04ec)
0x1659a0bc01cc   bec  3401318b       cbz w11, #+0x2630 (addr 0x1659a0bc27fc)
0x1659a0bc01d0   bf0  53057c44       lsr w4, w2, #5
0x1659a0bc01d4   bf4  12193484       and w4, w4, #0x1fff80
0x1659a0bc01d8   bf8  0b040164       add w4, w11, w4
0x1659a0bc01dc   bfc  8b040024       add x4, x1, x4
0x1659a0bc01e0   c00  f9400885       ldr x5, [x4, #16]
0x1659a0bc01e4   c04  91000c46       add x6, x2, #0x3 (3)
0x1659a0bc01e8   c08  b2402cc6       orr x6, x6, #0xfff
0x1659a0bc01ec   c0c  eb0600bf       cmp x5, x6
0x1659a0bc01f0   c10  54013061       b.ne #+0x260c (addr 0x1659a0bc27fc)
0x1659a0bc01f4   c14  f9400c84       ldr x4, [x4, #24]
0x1659a0bc01f8   c18  8b020082       add x2, x4, x2
0x1659a0bc01fc   c1c  7200045f       tst w2, #0x3
0x1659a0bc0200   c20  54012fe1       b.ne #+0x25fc (addr 0x1659a0bc27fc)
0x1659a0bc0204   c24  39401ae4       ldrb w4, [x23, #6]
0x1659a0bc0208   c28  0b040c04       add w4, w0, w4, lsl #3
0x1659a0bc020c   c2c  f8646824       ldr x4, [x1, x4]
0x1659a0bc0210   c30  530c3ec5       ubfx w5, w22, #12, #4
0x1659a0bc0214   c34  f10024bf       cmp x5, #0x9 (9)
0x1659a0bc0218   c38  54000202       b.hs #+0x40 (addr 0x1659a0bc0258)
0x1659a0bc021c   c3c  10015b10       adr x16, #+0x2b60 (addr 0x1659a0bc2d7c)
0x1659a0bc0220   c40  aa0203e2       mov x2, x2
0x1659a0bc0224   c44  aa0203e2       mov x2, x2
0x1659a0bc0228   c48  d2800011       movz x17, #0x0
0x1659a0bc022c   c4c  b8a57a11       ldrsw x17, [x16, x5, lsl #2]
0x1659a0bc0230   c50  8b110210       add x16, x16, x17
0x1659a0bc0234   c54  d61f0200       br x16
0x1659a0bc0238   c58  2a0203e2       mov w2, w2
0x1659a0bc023c   c5c  8b020025       add x5, x1, x2
0x1659a0bc0240   c60  f24004bf       tst x5, #0x3
0x1659a0bc0244   c64  54014ce1       b.ne #+0x299c (addr 0x1659a0bc2be0)
0x1659a0bc0248   c68  8b020025       add x5, x1, x2
0x1659a0bc024c   c6c  b8e480a2       swpal w4, w2, [x5]
0x1659a0bc0250   c70  2a0203e2       mov w2, w2
0x1659a0bc0254   c74  14000182       b #+0x608 (addr 0x1659a0bc085c)
0x1659a0bc0258   c78  92407c84       and x4, x4, #0xffffffff
0x1659a0bc025c   c7c  aa2403e6       mvn x6, x4
0x1659a0bc0260   c80  d3607c87       lsl x7, x4, #32
0x1659a0bc0264   c84  2a0203e2       mov w2, w2
0x1659a0bc0268   c88  8b020028       add x8, x1, x2
0x1659a0bc026c   c8c  f240051f       tst x8, #0x3
0x1659a0bc0270   c90  54014b61       b.ne #+0x296c (addr 0x1659a0bc2bdc)
0x1659a0bc0274   c94  8b020036       add x22, x1, x2
0x1659a0bc0278   c98  88dffec8       ldar w8, [x22]
0x1659a0bc027c   c9c  14000002       b #+0x8 (addr 0x1659a0bc0284)
0x1659a0bc0280   ca0  aa1803e8       mov x8, x24
0x1659a0bc0284   ca4  2a0803f6       mov w22, w8
0x1659a0bc0288   ca8  f10020bf       cmp x5, #0x8 (8)
0x1659a0bc028c   cac  54000102       b.hs #+0x20 (addr 0x1659a0bc02ac)
0x1659a0bc0290   cb0  10015670       adr x16, #+0x2acc (addr 0x1659a0bc2d5c)
0x1659a0bc0294   cb4  aa0203e2       mov x2, x2
0x1659a0bc0298   cb8  aa0203e2       mov x2, x2
0x1659a0bc029c   cbc  d2800011       movz x17, #0x0
0x1659a0bc02a0   cc0  b8a57a11       ldrsw x17, [x16, x5, lsl #2]
0x1659a0bc02a4   cc4  8b110210       add x16, x16, x17
0x1659a0bc02a8   cc8  d61f0200       br x16
0x1659a0bc02ac   ccc  aa0403f7       mov x23, x4
0x1659a0bc02b0   cd0  14000016       b #+0x58 (addr 0x1659a0bc0308)
0x1659a0bc02b4   cd4  eb0402df       cmp x22, x4
0x1659a0bc02b8   cd8  9a8432d7       csel x23, x22, x4, lo
0x1659a0bc02bc   cdc  14000013       b #+0x4c (addr 0x1659a0bc0308)
0x1659a0bc02c0   ce0  eb16009f       cmp x4, x22
0x1659a0bc02c4   ce4  9a8432d7       csel x23, x22, x4, lo
0x1659a0bc02c8   ce8  14000010       b #+0x40 (addr 0x1659a0bc0308)
0x1659a0bc02cc   cec  d3607ed7       lsl x23, x22, #32
0x1659a0bc02d0   cf0  eb0702ff       cmp x23, x7
0x1659a0bc02d4   cf4  9a84b2d7       csel x23, x22, x4, lt
0x1659a0bc02d8   cf8  1400000c       b #+0x30 (addr 0x1659a0bc0308)
0x1659a0bc02dc   cfc  d3607ed7       lsl x23, x22, #32
0x1659a0bc02e0   d00  eb1700ff       cmp x7, x23
0x1659a0bc02e4   d04  9a84b2d7       csel x23, x22, x4, lt
0x1659a0bc02e8   d08  14000008       b #+0x20 (addr 0x1659a0bc0308)
0x1659a0bc02ec   d0c  aa160097       orr x23, x4, x22
0x1659a0bc02f0   d10  14000006       b #+0x18 (addr 0x1659a0bc0308)
0x1659a0bc02f4   d14  ca160097       eor x23, x4, x22
0x1659a0bc02f8   d18  14000004       b #+0x10 (addr 0x1659a0bc0308)
0x1659a0bc02fc   d1c  8a0602d7       and x23, x22, x6
0x1659a0bc0300   d20  14000002       b #+0x8 (addr 0x1659a0bc0308)
0x1659a0bc0304   d24  8b160097       add x23, x4, x22
0x1659a0bc0308   d28  aa0803f8       mov x24, x8
0x1659a0bc030c   d2c  8b02003b       add cp, x1, x2
0x1659a0bc0310   d30  88f8ff77       casal w24, w23, [cp]
0x1659a0bc0314   d34  6b08031f       cmp w24, w8
0x1659a0bc0318   d38  54000a00       b.eq #+0x140 (addr 0x1659a0bc0458)
0x1659a0bc031c   d3c  2a1803e8       mov w8, w24
0x1659a0bc0320   d40  f10020bf       cmp x5, #0x8 (8)
0x1659a0bc0324   d44  54000102       b.hs #+0x20 (addr 0x1659a0bc0344)
0x1659a0bc0328   d48  100150b0       adr x16, #+0x2a14 (addr 0x1659a0bc2d3c)
0x1659a0bc032c   d4c  aa0203e2       mov x2, x2
0x1659a0bc0330   d50  aa0203e2       mov x2, x2
0x1659a0bc0334   d54  d2800011       movz x17, #0x0
0x1659a0bc0338   d58  b8a57a11       ldrsw x17, [x16, x5, lsl #2]
0x1659a0bc033c   d5c  8b110210       add x16, x16, x17
0x1659a0bc0340   d60  d61f0200       br x16
0x1659a0bc0344   d64  aa0403f6       mov x22, x4
0x1659a0bc0348   d68  14000016       b #+0x58 (addr 0x1659a0bc03a0)
0x1659a0bc034c   d6c  eb04011f       cmp x8, x4
0x1659a0bc0350   d70  9a843116       csel x22, x8, x4, lo
0x1659a0bc0354   d74  14000013       b #+0x4c (addr 0x1659a0bc03a0)
0x1659a0bc0358   d78  eb08009f       cmp x4, x8
0x1659a0bc035c   d7c  9a843116       csel x22, x8, x4, lo
0x1659a0bc0360   d80  14000010       b #+0x40 (addr 0x1659a0bc03a0)
0x1659a0bc0364   d84  d3607d16       lsl x22, x8, #32
0x1659a0bc0368   d88  eb0702df       cmp x22, x7
0x1659a0bc036c   d8c  9a84b116       csel x22, x8, x4, lt
0x1659a0bc0370   d90  1400000c       b #+0x30 (addr 0x1659a0bc03a0)
0x1659a0bc0374   d94  d3607d16       lsl x22, x8, #32
0x1659a0bc0378   d98  eb1600ff       cmp x7, x22
0x1659a0bc037c   d9c  9a84b116       csel x22, x8, x4, lt
0x1659a0bc0380   da0  14000008       b #+0x20 (addr 0x1659a0bc03a0)
0x1659a0bc0384   da4  aa080096       orr x22, x4, x8
0x1659a0bc0388   da8  14000006       b #+0x18 (addr 0x1659a0bc03a0)
0x1659a0bc038c   dac  ca080096       eor x22, x4, x8
0x1659a0bc0390   db0  14000004       b #+0x10 (addr 0x1659a0bc03a0)
0x1659a0bc0394   db4  8a060116       and x22, x8, x6
0x1659a0bc0398   db8  14000002       b #+0x8 (addr 0x1659a0bc03a0)
0x1659a0bc039c   dbc  8b080096       add x22, x4, x8
0x1659a0bc03a0   dc0  aa1803f7       mov x23, x24
0x1659a0bc03a4   dc4  8b02003b       add cp, x1, x2
0x1659a0bc03a8   dc8  88f7ff76       casal w23, w22, [cp]
0x1659a0bc03ac   dcc  6b1802ff       cmp w23, w24
0x1659a0bc03b0   dd0  54000560       b.eq #+0xac (addr 0x1659a0bc045c)
0x1659a0bc03b4   dd4  38531348       ldurb w8, [x26, #-207]
0x1659a0bc03b8   dd8  35012cc8       cbnz w8, #+0x2598 (addr 0x1659a0bc2950)
0x1659a0bc03bc   ddc  2a1703e8       mov w8, w23
0x1659a0bc03c0   de0  f10020bf       cmp x5, #0x8 (8)
0x1659a0bc03c4   de4  54000102       b.hs #+0x20 (addr 0x1659a0bc03e4)
0x1659a0bc03c8   de8  10014ab0       adr x16, #+0x2954 (addr 0x1659a0bc2d1c)
0x1659a0bc03cc   dec  aa0203e2       mov x2, x2
0x1659a0bc03d0   df0  aa0203e2       mov x2, x2
0x1659a0bc03d4   df4  d2800011       movz x17, #0x0
0x1659a0bc03d8   df8  b8a57a11       ldrsw x17, [x16, x5, lsl #2]
0x1659a0bc03dc   dfc  8b110210       add x16, x16, x17
0x1659a0bc03e0   e00  d61f0200       br x16
0x1659a0bc03e4   e04  aa0403f6       mov x22, x4
0x1659a0bc03e8   e08  14000016       b #+0x58 (addr 0x1659a0bc0440)
0x1659a0bc03ec   e0c  eb04011f       cmp x8, x4
0x1659a0bc03f0   e10  9a843116       csel x22, x8, x4, lo
0x1659a0bc03f4   e14  14000013       b #+0x4c (addr 0x1659a0bc0440)
0x1659a0bc03f8   e18  eb08009f       cmp x4, x8
0x1659a0bc03fc   e1c  9a843116       csel x22, x8, x4, lo
0x1659a0bc0400   e20  14000010       b #+0x40 (addr 0x1659a0bc0440)
0x1659a0bc0404   e24  d3607d16       lsl x22, x8, #32
0x1659a0bc0408   e28  eb0702df       cmp x22, x7
0x1659a0bc040c   e2c  9a84b116       csel x22, x8, x4, lt
0x1659a0bc0410   e30  1400000c       b #+0x30 (addr 0x1659a0bc0440)
0x1659a0bc0414   e34  d3607d16       lsl x22, x8, #32
0x1659a0bc0418   e38  eb1600ff       cmp x7, x22
0x1659a0bc041c   e3c  9a84b116       csel x22, x8, x4, lt
0x1659a0bc0420   e40  14000008       b #+0x20 (addr 0x1659a0bc0440)
0x1659a0bc0424   e44  aa080096       orr x22, x4, x8
0x1659a0bc0428   e48  14000006       b #+0x18 (addr 0x1659a0bc0440)
0x1659a0bc042c   e4c  ca080096       eor x22, x4, x8
0x1659a0bc0430   e50  14000004       b #+0x10 (addr 0x1659a0bc0440)
0x1659a0bc0434   e54  8a060116       and x22, x8, x6
0x1659a0bc0438   e58  14000002       b #+0x8 (addr 0x1659a0bc0440)
0x1659a0bc043c   e5c  8b080096       add x22, x4, x8
0x1659a0bc0440   e60  aa1703f8       mov x24, x23
0x1659a0bc0444   e64  8b02003b       add cp, x1, x2
0x1659a0bc0448   e68  88f8ff76       casal w24, w22, [cp]
0x1659a0bc044c   e6c  6b17031f       cmp w24, w23
0x1659a0bc0450   e70  54fff181       b.ne #-0x1d0 (addr 0x1659a0bc0280)
0x1659a0bc0454   e74  14000002       b #+0x8 (addr 0x1659a0bc045c)
0x1659a0bc0458   e78  aa1603e8       mov x8, x22
0x1659a0bc045c   e7c  aa0803e2       mov x2, x8
0x1659a0bc0460   e80  140000ff       b #+0x3fc (addr 0x1659a0bc085c)
0x1659a0bc0464   e84  2a0203e2       mov w2, w2
0x1659a0bc0468   e88  8b020025       add x5, x1, x2
0x1659a0bc046c   e8c  f24004bf       tst x5, #0x3
0x1659a0bc0470   e90  54013b41       b.ne #+0x2768 (addr 0x1659a0bc2bd8)
0x1659a0bc0474   e94  8b020025       add x5, x1, x2
0x1659a0bc0478   e98  b8e430a2       ldsetal w4, w2, [x5]
0x1659a0bc047c   e9c  2a0203e2       mov w2, w2
0x1659a0bc0480   ea0  140000f7       b #+0x3dc (addr 0x1659a0bc085c)
0x1659a0bc0484   ea4  2a0203e2       mov w2, w2
0x1659a0bc0488   ea8  8b020025       add x5, x1, x2
0x1659a0bc048c   eac  f24004bf       tst x5, #0x3
0x1659a0bc0490   eb0  54013a21       b.ne #+0x2744 (addr 0x1659a0bc2bd4)
0x1659a0bc0494   eb4  8b020025       add x5, x1, x2
0x1659a0bc0498   eb8  b8e420a2       ldeoral w4, w2, [x5]
0x1659a0bc049c   ebc  2a0203e2       mov w2, w2
0x1659a0bc04a0   ec0  140000ef       b #+0x3bc (addr 0x1659a0bc085c)
0x1659a0bc04a4   ec4  2a2403e4       mvn w4, w4
0x1659a0bc04a8   ec8  2a0203e2       mov w2, w2
0x1659a0bc04ac   ecc  8b020025       add x5, x1, x2
0x1659a0bc04b0   ed0  f24004bf       tst x5, #0x3
0x1659a0bc04b4   ed4  540138e1       b.ne #+0x271c (addr 0x1659a0bc2bd0)
0x1659a0bc04b8   ed8  8b020025       add x5, x1, x2
0x1659a0bc04bc   edc  2a2403f0       mvn w16, w4
0x1659a0bc04c0   ee0  b8f010a2       ldclral w16, w2, [x5]
0x1659a0bc04c4   ee4  2a0203e2       mov w2, w2
0x1659a0bc04c8   ee8  140000e5       b #+0x394 (addr 0x1659a0bc085c)
0x1659a0bc04cc   eec  2a0203e2       mov w2, w2
0x1659a0bc04d0   ef0  8b020025       add x5, x1, x2
0x1659a0bc04d4   ef4  f24004bf       tst x5, #0x3
0x1659a0bc04d8   ef8  540137a1       b.ne #+0x26f4 (addr 0x1659a0bc2bcc)
0x1659a0bc04dc   efc  8b020025       add x5, x1, x2
0x1659a0bc04e0   f00  b8e400a2       ldaddal w4, w2, [x5]
0x1659a0bc04e4   f04  2a0203e2       mov w2, w2
0x1659a0bc04e8   f08  140000dd       b #+0x374 (addr 0x1659a0bc085c)
0x1659a0bc04ec   f0c  3401188b       cbz w11, #+0x2310 (addr 0x1659a0bc27fc)
0x1659a0bc04f0   f10  53057c44       lsr w4, w2, #5
0x1659a0bc04f4   f14  12193484       and w4, w4, #0x1fff80
0x1659a0bc04f8   f18  0b040164       add w4, w11, w4
0x1659a0bc04fc   f1c  8b040024       add x4, x1, x4
0x1659a0bc0500   f20  f9400885       ldr x5, [x4, #16]
0x1659a0bc0504   f24  91001c46       add x6, x2, #0x7 (7)
0x1659a0bc0508   f28  b2402cc6       orr x6, x6, #0xfff
0x1659a0bc050c   f2c  eb0600bf       cmp x5, x6
0x1659a0bc0510   f30  54011761       b.ne #+0x22ec (addr 0x1659a0bc27fc)
0x1659a0bc0514   f34  f9400c84       ldr x4, [x4, #24]
0x1659a0bc0518   f38  8b020082       add x2, x4, x2
0x1659a0bc051c   f3c  7200085f       tst w2, #0x7
0x1659a0bc0520   f40  540116e1       b.ne #+0x22dc (addr 0x1659a0bc27fc)
0x1659a0bc0524   f44  39401ae4       ldrb w4, [x23, #6]
0x1659a0bc0528   f48  0b040c04       add w4, w0, w4, lsl #3
0x1659a0bc052c   f4c  f8646824       ldr x4, [x1, x4]
0x1659a0bc0530   f50  530c3ec5       ubfx w5, w22, #12, #4
0x1659a0bc0534   f54  f10024bf       cmp x5, #0x9 (9)
0x1659a0bc0538   f58  540001e2       b.hs #+0x3c (addr 0x1659a0bc0574)
0x1659a0bc053c   f5c  10013df0       adr x16, #+0x27bc (addr 0x1659a0bc2cf8)
0x1659a0bc0540   f60  aa0203e2       mov x2, x2
0x1659a0bc0544   f64  aa0203e2       mov x2, x2
0x1659a0bc0548   f68  d2800011       movz x17, #0x0
0x1659a0bc054c   f6c  b8a57a11       ldrsw x17, [x16, x5, lsl #2]
0x1659a0bc0550   f70  8b110210       add x16, x16, x17
0x1659a0bc0554   f74  d61f0200       br x16
0x1659a0bc0558   f78  2a0203e2       mov w2, w2
0x1659a0bc055c   f7c  8b020025       add x5, x1, x2
0x1659a0bc0560   f80  f24008bf       tst x5, #0x7
0x1659a0bc0564   f84  54013321       b.ne #+0x2664 (addr 0x1659a0bc2bc8)
0x1659a0bc0568   f88  8b020025       add x5, x1, x2
0x1659a0bc056c   f8c  f8e480a2       swpal x4, x2, [x5]
0x1659a0bc0570   f90  140000bb       b #+0x2ec (addr 0x1659a0bc085c)
0x1659a0bc0574   f94  aa2403e6       mvn x6, x4
0x1659a0bc0578   f98  2a0203e2       mov w2, w2
0x1659a0bc057c   f9c  8b020027       add x7, x1, x2
0x1659a0bc0580   fa0  f24008ff       tst x7, #0x7
0x1659a0bc0584   fa4  54013201       b.ne #+0x2640 (addr 0x1659a0bc2bc4)
0x1659a0bc0588   fa8  8b020028       add x8, x1, x2
0x1659a0bc058c   fac  c8dffd07       ldar x7, [x8]
0x1659a0bc0590   fb0  14000002       b #+0x8 (addr 0x1659a0bc0598)
0x1659a0bc0594   fb4  aa0803e7       mov x7, x8
0x1659a0bc0598   fb8  f10020bf       cmp x5, #0x8 (8)
0x1659a0bc059c   fbc  54000102       b.hs #+0x20 (addr 0x1659a0bc05bc)
0x1659a0bc05a0   fc0  100139d0       adr x16, #+0x2738 (addr 0x1659a0bc2cd8)
0x1659a0bc05a4   fc4  aa0203e2       mov x2, x2
0x1659a0bc05a8   fc8  aa0203e2       mov x2, x2
0x1659a0bc05ac   fcc  d2800011       movz x17, #0x0
0x1659a0bc05b0   fd0  b8a57a11       ldrsw x17, [x16, x5, lsl #2]
0x1659a0bc05b4   fd4  8b110210       add x16, x16, x17
0x1659a0bc05b8   fd8  d61f0200       br x16
0x1659a0bc05bc   fdc  aa0403e8       mov x8, x4
0x1659a0bc05c0   fe0  14000014       b #+0x50 (addr 0x1659a0bc0610)
0x1659a0bc05c4   fe4  eb0400ff       cmp x7, x4
0x1659a0bc05c8   fe8  9a8430e8       csel x8, x7, x4, lo
0x1659a0bc05cc   fec  14000011       b #+0x44 (addr 0x1659a0bc0610)
0x1659a0bc05d0   ff0  eb07009f       cmp x4, x7
0x1659a0bc05d4   ff4  9a8430e8       csel x8, x7, x4, lo
0x1659a0bc05d8   ff8  1400000e       b #+0x38 (addr 0x1659a0bc0610)
0x1659a0bc05dc   ffc  eb0400ff       cmp x7, x4
0x1659a0bc05e0  1000  9a84b0e8       csel x8, x7, x4, lt
0x1659a0bc05e4  1004  1400000b       b #+0x2c (addr 0x1659a0bc0610)
0x1659a0bc05e8  1008  eb07009f       cmp x4, x7
0x1659a0bc05ec  100c  9a84b0e8       csel x8, x7, x4, lt
0x1659a0bc05f0  1010  14000008       b #+0x20 (addr 0x1659a0bc0610)
0x1659a0bc05f4  1014  aa0400e8       orr x8, x7, x4
0x1659a0bc05f8  1018  14000006       b #+0x18 (addr 0x1659a0bc0610)
0x1659a0bc05fc  101c  ca0400e8       eor x8, x7, x4
0x1659a0bc0600  1020  14000004       b #+0x10 (addr 0x1659a0bc0610)
0x1659a0bc0604  1024  8a0600e8       and x8, x7, x6
0x1659a0bc0608  1028  14000002       b #+0x8 (addr 0x1659a0bc0610)
0x1659a0bc060c  102c  8b0400e8       add x8, x7, x4
0x1659a0bc0610  1030  aa0703f6       mov x22, x7
0x1659a0bc0614  1034  8b020037       add x23, x1, x2
0x1659a0bc0618  1038  c8f6fee8       casal x22, x8, [x23]
0x1659a0bc061c  103c  eb0702df       cmp x22, x7
0x1659a0bc0620  1040  54000de0       b.eq #+0x1bc (addr 0x1659a0bc07dc)
0x1659a0bc0624  1044  f10020bf       cmp x5, #0x8 (8)
0x1659a0bc0628  1048  54000102       b.hs #+0x20 (addr 0x1659a0bc0648)
0x1659a0bc062c  104c  10013470       adr x16, #+0x268c (addr 0x1659a0bc2cb8)
0x1659a0bc0630  1050  aa0203e2       mov x2, x2
0x1659a0bc0634  1054  aa0203e2       mov x2, x2
0x1659a0bc0638  1058  d2800011       movz x17, #0x0
0x1659a0bc063c  105c  b8a57a11       ldrsw x17, [x16, x5, lsl #2]
0x1659a0bc0640  1060  8b110210       add x16, x16, x17
0x1659a0bc0644  1064  d61f0200       br x16
0x1659a0bc0648  1068  aa0403e7       mov x7, x4
0x1659a0bc064c  106c  14000014       b #+0x50 (addr 0x1659a0bc069c)
0x1659a0bc0650  1070  eb0402df       cmp x22, x4
0x1659a0bc0654  1074  9a8432c7       csel x7, x22, x4, lo
0x1659a0bc0658  1078  14000011       b #+0x44 (addr 0x1659a0bc069c)
0x1659a0bc065c  107c  eb16009f       cmp x4, x22
0x1659a0bc0660  1080  9a8432c7       csel x7, x22, x4, lo
0x1659a0bc0664  1084  1400000e       b #+0x38 (addr 0x1659a0bc069c)
0x1659a0bc0668  1088  eb0402df       cmp x22, x4
0x1659a0bc066c  108c  9a84b2c7       csel x7, x22, x4, lt
0x1659a0bc0670  1090  1400000b       b #+0x2c (addr 0x1659a0bc069c)
0x1659a0bc0674  1094  eb16009f       cmp x4, x22
0x1659a0bc0678  1098  9a84b2c7       csel x7, x22, x4, lt
0x1659a0bc067c  109c  14000008       b #+0x20 (addr 0x1659a0bc069c)
0x1659a0bc0680  10a0  aa0402c7       orr x7, x22, x4
0x1659a0bc0684  10a4  14000006       b #+0x18 (addr 0x1659a0bc069c)
0x1659a0bc0688  10a8  ca0402c7       eor x7, x22, x4
0x1659a0bc068c  10ac  14000004       b #+0x10 (addr 0x1659a0bc069c)
0x1659a0bc0690  10b0  8a0602c7       and x7, x22, x6
0x1659a0bc0694  10b4  14000002       b #+0x8 (addr 0x1659a0bc069c)
0x1659a0bc0698  10b8  8b0402c7       add x7, x22, x4
0x1659a0bc069c  10bc  aa1603e8       mov x8, x22
0x1659a0bc06a0  10c0  8b020037       add x23, x1, x2
0x1659a0bc06a4  10c4  c8e8fee7       casal x8, x7, [x23]
0x1659a0bc06a8  10c8  eb16011f       cmp x8, x22
0x1659a0bc06ac  10cc  540009a0       b.eq #+0x134 (addr 0x1659a0bc07e0)
0x1659a0bc06b0  10d0  f10020bf       cmp x5, #0x8 (8)
0x1659a0bc06b4  10d4  54000102       b.hs #+0x20 (addr 0x1659a0bc06d4)
0x1659a0bc06b8  10d8  10012f10       adr x16, #+0x25e0 (addr 0x1659a0bc2c98)
0x1659a0bc06bc  10dc  aa0203e2       mov x2, x2
0x1659a0bc06c0  10e0  aa0203e2       mov x2, x2
0x1659a0bc06c4  10e4  d2800011       movz x17, #0x0
0x1659a0bc06c8  10e8  b8a57a11       ldrsw x17, [x16, x5, lsl #2]
0x1659a0bc06cc  10ec  8b110210       add x16, x16, x17
0x1659a0bc06d0  10f0  d61f0200       br x16
0x1659a0bc06d4  10f4  aa0403e7       mov x7, x4
0x1659a0bc06d8  10f8  14000014       b #+0x50 (addr 0x1659a0bc0728)
0x1659a0bc06dc  10fc  eb04011f       cmp x8, x4
0x1659a0bc06e0  1100  9a843107       csel x7, x8, x4, lo
0x1659a0bc06e4  1104  14000011       b #+0x44 (addr 0x1659a0bc0728)
0x1659a0bc06e8  1108  eb08009f       cmp x4, x8
0x1659a0bc06ec  110c  9a843107       csel x7, x8, x4, lo
0x1659a0bc06f0  1110  1400000e       b #+0x38 (addr 0x1659a0bc0728)
0x1659a0bc06f4  1114  eb04011f       cmp x8, x4
0x1659a0bc06f8  1118  9a84b107       csel x7, x8, x4, lt
0x1659a0bc06fc  111c  1400000b       b #+0x2c (addr 0x1659a0bc0728)
0x1659a0bc0700  1120  eb08009f       cmp x4, x8
0x1659a0bc0704  1124  9a84b107       csel x7, x8, x4, lt
0x1659a0bc0708  1128  14000008       b #+0x20 (addr 0x1659a0bc0728)
0x1659a0bc070c  112c  aa040107       orr x7, x8, x4
0x1659a0bc0710  1130  14000006       b #+0x18 (addr 0x1659a0bc0728)
0x1659a0bc0714  1134  ca040107       eor x7, x8, x4
0x1659a0bc0718  1138  14000004       b #+0x10 (addr 0x1659a0bc0728)
0x1659a0bc071c  113c  8a060107       and x7, x8, x6
0x1659a0bc0720  1140  14000002       b #+0x8 (addr 0x1659a0bc0728)
0x1659a0bc0724  1144  8b040107       add x7, x8, x4
0x1659a0bc0728  1148  aa0803f6       mov x22, x8
0x1659a0bc072c  114c  8b020037       add x23, x1, x2
0x1659a0bc0730  1150  c8f6fee7       casal x22, x7, [x23]
0x1659a0bc0734  1154  eb0802df       cmp x22, x8
0x1659a0bc0738  1158  540004e0       b.eq #+0x9c (addr 0x1659a0bc07d4)
0x1659a0bc073c  115c  38531347       ldurb w7, [x26, #-207]
0x1659a0bc0740  1160  35011547       cbnz w7, #+0x22a8 (addr 0x1659a0bc29e8)
0x1659a0bc0744  1164  f10020bf       cmp x5, #0x8 (8)
0x1659a0bc0748  1168  54000102       b.hs #+0x20 (addr 0x1659a0bc0768)
0x1659a0bc074c  116c  10012970       adr x16, #+0x252c (addr 0x1659a0bc2c78)
0x1659a0bc0750  1170  aa0203e2       mov x2, x2
0x1659a0bc0754  1174  aa0203e2       mov x2, x2
0x1659a0bc0758  1178  d2800011       movz x17, #0x0
0x1659a0bc075c  117c  b8a57a11       ldrsw x17, [x16, x5, lsl #2]
0x1659a0bc0760  1180  8b110210       add x16, x16, x17
0x1659a0bc0764  1184  d61f0200       br x16
0x1659a0bc0768  1188  aa0403e7       mov x7, x4
0x1659a0bc076c  118c  14000014       b #+0x50 (addr 0x1659a0bc07bc)
0x1659a0bc0770  1190  eb0402df       cmp x22, x4
0x1659a0bc0774  1194  9a8432c7       csel x7, x22, x4, lo
0x1659a0bc0778  1198  14000011       b #+0x44 (addr 0x1659a0bc07bc)
0x1659a0bc077c  119c  eb16009f       cmp x4, x22
0x1659a0bc0780  11a0  9a8432c7       csel x7, x22, x4, lo
0x1659a0bc0784  11a4  1400000e       b #+0x38 (addr 0x1659a0bc07bc)
0x1659a0bc0788  11a8  eb0402df       cmp x22, x4
0x1659a0bc078c  11ac  9a84b2c7       csel x7, x22, x4, lt
0x1659a0bc0790  11b0  1400000b       b #+0x2c (addr 0x1659a0bc07bc)
0x1659a0bc0794  11b4  eb16009f       cmp x4, x22
0x1659a0bc0798  11b8  9a84b2c7       csel x7, x22, x4, lt
0x1659a0bc079c  11bc  14000008       b #+0x20 (addr 0x1659a0bc07bc)
0x1659a0bc07a0  11c0  aa0402c7       orr x7, x22, x4
0x1659a0bc07a4  11c4  14000006       b #+0x18 (addr 0x1659a0bc07bc)
0x1659a0bc07a8  11c8  ca0402c7       eor x7, x22, x4
0x1659a0bc07ac  11cc  14000004       b #+0x10 (addr 0x1659a0bc07bc)
0x1659a0bc07b0  11d0  8a0602c7       and x7, x22, x6
0x1659a0bc07b4  11d4  14000002       b #+0x8 (addr 0x1659a0bc07bc)
0x1659a0bc07b8  11d8  8b0402c7       add x7, x22, x4
0x1659a0bc07bc  11dc  aa1603e8       mov x8, x22
0x1659a0bc07c0  11e0  8b020037       add x23, x1, x2
0x1659a0bc07c4  11e4  c8e8fee7       casal x8, x7, [x23]
0x1659a0bc07c8  11e8  eb16011f       cmp x8, x22
0x1659a0bc07cc  11ec  54ffee41       b.ne #-0x238 (addr 0x1659a0bc0594)
0x1659a0bc07d0  11f0  14000004       b #+0x10 (addr 0x1659a0bc07e0)
0x1659a0bc07d4  11f4  aa0803f6       mov x22, x8
0x1659a0bc07d8  11f8  14000002       b #+0x8 (addr 0x1659a0bc07e0)
0x1659a0bc07dc  11fc  aa0703f6       mov x22, x7
0x1659a0bc07e0  1200  aa1603e2       mov x2, x22
0x1659a0bc07e4  1204  1400001e       b #+0x78 (addr 0x1659a0bc085c)
0x1659a0bc07e8  1208  2a0203e2       mov w2, w2
0x1659a0bc07ec  120c  8b020025       add x5, x1, x2
0x1659a0bc07f0  1210  f24008bf       tst x5, #0x7
0x1659a0bc07f4  1214  54011e61       b.ne #+0x23cc (addr 0x1659a0bc2bc0)
0x1659a0bc07f8  1218  8b020025       add x5, x1, x2
0x1659a0bc07fc  121c  f8e430a2       ldsetal x4, x2, [x5]
0x1659a0bc0800  1220  14000017       b #+0x5c (addr 0x1659a0bc085c)
0x1659a0bc0804  1224  2a0203e2       mov w2, w2
0x1659a0bc0808  1228  8b020025       add x5, x1, x2
0x1659a0bc080c  122c  f24008bf       tst x5, #0x7
0x1659a0bc0810  1230  54011d61       b.ne #+0x23ac (addr 0x1659a0bc2bbc)
0x1659a0bc0814  1234  8b020025       add x5, x1, x2
0x1659a0bc0818  1238  f8e420a2       ldeoral x4, x2, [x5]
0x1659a0bc081c  123c  14000010       b #+0x40 (addr 0x1659a0bc085c)
0x1659a0bc0820  1240  aa2403e4       mvn x4, x4
0x1659a0bc0824  1244  2a0203e2       mov w2, w2
0x1659a0bc0828  1248  8b020025       add x5, x1, x2
0x1659a0bc082c  124c  f24008bf       tst x5, #0x7
0x1659a0bc0830  1250  54011c41       b.ne #+0x2388 (addr 0x1659a0bc2bb8)
0x1659a0bc0834  1254  8b020025       add x5, x1, x2
0x1659a0bc0838  1258  aa2403f0       mvn x16, x4
0x1659a0bc083c  125c  f8f010a2       ldclral x16, x2, [x5]
0x1659a0bc0840  1260  14000007       b #+0x1c (addr 0x1659a0bc085c)
0x1659a0bc0844  1264  2a0203e2       mov w2, w2
0x1659a0bc0848  1268  8b020025       add x5, x1, x2
0x1659a0bc084c  126c  f24008bf       tst x5, #0x7
0x1659a0bc0850  1270  54011b21       b.ne #+0x2364 (addr 0x1659a0bc2bb4)
0x1659a0bc0854  1274  8b020025       add x5, x1, x2
0x1659a0bc0858  1278  f8e400a2       ldaddal x4, x2, [x5]
0x1659a0bc085c  127c  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc0860  1280  5400e5a0       b.eq #+0x1cb4 (addr 0x1659a0bc2514)
0x1659a0bc0864  1284  0b190c04       add w4, w0, w25, lsl #3
0x1659a0bc0868  1288  f8246822       str x2, [x1, x4]
0x1659a0bc086c  128c  1400072a       b #+0x1ca8 (addr 0x1659a0bc2514)
0x1659a0bc0870  1290  2a0003e2       mov w2, w0
0x1659a0bc0874  1294  8b020022       add x2, x1, x2
0x1659a0bc0878  1298  f941c044       ldr x4, [x2, #896]
0x1659a0bc087c  129c  d3545484       ubfx x4, x4, #20, #2
0x1659a0bc0880  12a0  d1000484       sub x4, x4, #0x1 (1)
0x1659a0bc0884  12a4  f100089f       cmp x4, #0x2 (2)
0x1659a0bc0888  12a8  5400fba8       b.hi #+0x1f74 (addr 0x1659a0bc27fc)
0x1659a0bc088c  12ac  7100089f       cmp w4, #0x2 (2)
0x1659a0bc0890  12b0  540000e0       b.eq #+0x1c (addr 0x1659a0bc08ac)
0x1659a0bc0894  12b4  7100049f       cmp w4, #0x1 (1)
0x1659a0bc0898  12b8  5400fb20       b.eq #+0x1f64 (addr 0x1659a0bc27fc)
0x1659a0bc089c  12bc  f941a042       ldr x2, [x2, #832]
0x1659a0bc08a0  12c0  927e0442       and x2, x2, #0xc
0x1659a0bc08a4  12c4  f100105f       cmp x2, #0x4 (4)
0x1659a0bc08a8  12c8  5400faa1       b.ne #+0x1f54 (addr 0x1659a0bc27fc)
0x1659a0bc08ac  12cc  0b180c02       add w2, w0, w24, lsl #3
0x1659a0bc08b0  12d0  f8626824       ldr x4, [x1, x2]
0x1659a0bc08b4  12d4  71007f1f       cmp w24, #0x1f (31)
0x1659a0bc08b8  12d8  54000061       b.ne #+0xc (addr 0x1659a0bc08c4)
0x1659a0bc08bc  12dc  f2400c9f       tst x4, #0xf
0x1659a0bc08c0  12e0  5400f9e1       b.ne #+0x1f3c (addr 0x1659a0bc27fc)
0x1659a0bc08c4  12e4  3400f9cb       cbz w11, #+0x1f38 (addr 0x1659a0bc27fc)
0x1659a0bc08c8  12e8  0b160de5       add w5, w15, w22, lsl #3
0x1659a0bc08cc  12ec  f8656825       ldr x5, [x1, x5]
0x1659a0bc08d0  12f0  8b85a086       add x6, x4, x5, asr #40
0x1659a0bc08d4  12f4  d363fca7       lsr x7, x5, #35
0x1659a0bc08d8  12f8  120004e8       and w8, w7, #0x3
0x1659a0bc08dc  12fc  7100091f       cmp w8, #0x2 (2)
0x1659a0bc08e0  1300  9a860088       csel x8, x4, x6, eq
0x1659a0bc08e4  1304  53057d04       lsr w4, w8, #5
0x1659a0bc08e8  1308  12193484       and w4, w4, #0x1fff80
0x1659a0bc08ec  130c  0b040164       add w4, w11, w4
0x1659a0bc08f0  1310  d360fca5       lsr x5, x5, #32
0x1659a0bc08f4  1314  121b00b6       and w22, w5, #0x20
0x1659a0bc08f8  1318  53017ed6       lsr w22, w22, #1
0x1659a0bc08fc  131c  521c02d6       eor w22, w22, #0x10
0x1659a0bc0900  1320  0b160084       add w4, w4, w22
0x1659a0bc0904  1324  f8646836       ldr x22, [x1, x4]
0x1659a0bc0908  1328  120008b8       and w24, w5, #0x7
0x1659a0bc090c  132c  d280005b       movz cp, #0x2
0x1659a0bc0910  1330  1ad8237b       lsl w27, w27, w24
0x1659a0bc0914  1334  1200131c       and w28, w24, #0x1f
0x1659a0bc0918  1338  d2800023       movz x3, #0x1
0x1659a0bc091c  133c  1adc2063       lsl w3, w3, w28
0x1659a0bc0920  1340  721a00bf       tst w5, #0x40
0x1659a0bc0924  1344  1a83137b       csel w27, w27, w3, ne
0x1659a0bc0928  1348  2a1b03fb       mov w27, w27
0x1659a0bc092c  134c  8b08037b       add cp, cp, x8
0x1659a0bc0930  1350  d100077b       sub cp, cp, #0x1 (1)
0x1659a0bc0934  1354  b2402f7b       orr cp, cp, #0xfff
0x1659a0bc0938  1358  eb1b02df       cmp x22, cp
0x1659a0bc093c  135c  5400f601       b.ne #+0x1ec0 (addr 0x1659a0bc27fc)
0x1659a0bc0940  1360  d2800116       movz x22, #0x8
0x1659a0bc0944  1364  7100207f       cmp w3, #0x8 (8)
0x1659a0bc0948  1368  1a96307b       csel w27, w3, w22, lo
0x1659a0bc094c  136c  51000776       sub w22, w27, #0x1 (1)
0x1659a0bc0950  1370  8b040024       add x4, x1, x4
0x1659a0bc0954  1374  f9400484       ldr x4, [x4, #8]
0x1659a0bc0958  1378  8b080084       add x4, x4, x8
0x1659a0bc095c  137c  6a0402df       tst w22, w4
0x1659a0bc0960  1380  5400f4e1       b.ne #+0x1e9c (addr 0x1659a0bc27fc)
0x1659a0bc0964  1384  0b030088       add w8, w4, w3
0x1659a0bc0968  1388  12001336       and w22, w25, #0x1f
0x1659a0bc096c  138c  39401af7       ldrb w23, [x23, #6]
0x1659a0bc0970  1390  120012f7       and w23, w23, #0x1f
0x1659a0bc0974  1394  37280f05       tbnz w5, #5, #+0x1e0 (addr 0x1659a0bc0b54)
0x1659a0bc0978  1398  0b161276       add w22, w19, w22, lsl #4
0x1659a0bc097c  139c  f8766839       ldr x25, [x1, x22]
0x1659a0bc0980  13a0  7100131f       cmp w24, #0x4 (4)
0x1659a0bc0984  13a4  54000500       b.eq #+0xa0 (addr 0x1659a0bc0a24)
0x1659a0bc0988  13a8  51000476       sub w22, w3, #0x1 (1)
0x1659a0bc098c  13ac  6a0402df       tst w22, w4
0x1659a0bc0990  13b0  540006e1       b.ne #+0xdc (addr 0x1659a0bc0a6c)
0x1659a0bc0994  13b4  71000adf       cmp w22, #0x2 (2)
0x1659a0bc0998  13b8  540000cb       b.lt #+0x18 (addr 0x1659a0bc09b0)
0x1659a0bc099c  13bc  71000adf       cmp w22, #0x2 (2)
0x1659a0bc09a0  13c0  540001e0       b.eq #+0x3c (addr 0x1659a0bc09dc)
0x1659a0bc09a4  13c4  71000edf       cmp w22, #0x3 (3)
0x1659a0bc09a8  13c8  540000c0       b.eq #+0x18 (addr 0x1659a0bc09c0)
0x1659a0bc09ac  13cc  1400000c       b #+0x30 (addr 0x1659a0bc09dc)
0x1659a0bc09b0  13d0  34000336       cbz w22, #+0x64 (addr 0x1659a0bc0a14)
0x1659a0bc09b4  13d4  710006df       cmp w22, #0x1 (1)
0x1659a0bc09b8  13d8  54000200       b.eq #+0x40 (addr 0x1659a0bc09f8)
0x1659a0bc09bc  13dc  14000008       b #+0x20 (addr 0x1659a0bc09dc)
0x1659a0bc09c0  13e0  2a0403e4       mov w4, w4
0x1659a0bc09c4  13e4  8b040036       add x22, x1, x4
0x1659a0bc09c8  13e8  f24006df       tst x22, #0x3
0x1659a0bc09cc  13ec  54010f21       b.ne #+0x21e4 (addr 0x1659a0bc2bb0)
0x1659a0bc09d0  13f0  8b040036       add x22, x1, x4
0x1659a0bc09d4  13f4  889ffed9       stlr w25, [x22]
0x1659a0bc09d8  13f8  14000025       b #+0x94 (addr 0x1659a0bc0a6c)
0x1659a0bc09dc  13fc  2a0403e4       mov w4, w4
0x1659a0bc09e0  1400  8b040036       add x22, x1, x4
0x1659a0bc09e4  1404  f2400adf       tst x22, #0x7
0x1659a0bc09e8  1408  54010e21       b.ne #+0x21c4 (addr 0x1659a0bc2bac)
0x1659a0bc09ec  140c  8b040036       add x22, x1, x4
0x1659a0bc09f0  1410  c89ffed9       stlr x25, [x22]
0x1659a0bc09f4  1414  1400001e       b #+0x78 (addr 0x1659a0bc0a6c)
0x1659a0bc09f8  1418  2a0403e4       mov w4, w4
0x1659a0bc09fc  141c  8b040036       add x22, x1, x4
0x1659a0bc0a00  1420  f24002df       tst x22, #0x1
0x1659a0bc0a04  1424  54010d21       b.ne #+0x21a4 (addr 0x1659a0bc2ba8)
0x1659a0bc0a08  1428  8b040036       add x22, x1, x4
0x1659a0bc0a0c  142c  489ffed9       stlrh w25, [x22]
0x1659a0bc0a10  1430  14000017       b #+0x5c (addr 0x1659a0bc0a6c)
0x1659a0bc0a14  1434  2a0403e4       mov w4, w4
0x1659a0bc0a18  1438  8b040036       add x22, x1, x4
0x1659a0bc0a1c  143c  089ffed9       stlrb w25, [x22]
0x1659a0bc0a20  1440  14000013       b #+0x4c (addr 0x1659a0bc0a6c)
0x1659a0bc0a24  1444  1100209b       add w27, w4, #0x8 (8)
0x1659a0bc0a28  1448  72000b7f       tst w27, #0x7
0x1659a0bc0a2c  144c  54000101       b.ne #+0x20 (addr 0x1659a0bc0a4c)
0x1659a0bc0a30  1450  8b160036       add x22, x1, x22
0x1659a0bc0a34  1454  f94006d6       ldr x22, [x22, #8]
0x1659a0bc0a38  1458  8b1b003c       add x28, x1, cp
0x1659a0bc0a3c  145c  f2400b9f       tst x28, #0x7
0x1659a0bc0a40  1460  54010b21       b.ne #+0x2164 (addr 0x1659a0bc2ba4)
0x1659a0bc0a44  1464  8b1b003c       add x28, x1, cp
0x1659a0bc0a48  1468  c89fff96       stlr x22, [x28]
0x1659a0bc0a4c  146c  7200089f       tst w4, #0x7
0x1659a0bc0a50  1470  540000e1       b.ne #+0x1c (addr 0x1659a0bc0a6c)
0x1659a0bc0a54  1474  2a0403e4       mov w4, w4
0x1659a0bc0a58  1478  8b040036       add x22, x1, x4
0x1659a0bc0a5c  147c  f2400adf       tst x22, #0x7
0x1659a0bc0a60  1480  54010a01       b.ne #+0x2140 (addr 0x1659a0bc2ba0)
0x1659a0bc0a64  1484  8b040036       add x22, x1, x4
0x1659a0bc0a68  1488  c89ffed9       stlr x25, [x22]
0x1659a0bc0a6c  148c  36301925       tbz w5, #6, #+0x324 (addr 0x1659a0bc0d90)
0x1659a0bc0a70  1490  0b171264       add w4, w19, w23, lsl #4
0x1659a0bc0a74  1494  f8646825       ldr x5, [x1, x4]
0x1659a0bc0a78  1498  7100131f       cmp w24, #0x4 (4)
0x1659a0bc0a7c  149c  54000480       b.eq #+0x90 (addr 0x1659a0bc0b0c)
0x1659a0bc0a80  14a0  51000463       sub w3, w3, #0x1 (1)
0x1659a0bc0a84  14a4  6a08007f       tst w3, w8
0x1659a0bc0a88  14a8  54001841       b.ne #+0x308 (addr 0x1659a0bc0d90)
0x1659a0bc0a8c  14ac  7100087f       cmp w3, #0x2 (2)
0x1659a0bc0a90  14b0  540000cb       b.lt #+0x18 (addr 0x1659a0bc0aa8)
0x1659a0bc0a94  14b4  7100087f       cmp w3, #0x2 (2)
0x1659a0bc0a98  14b8  540001c0       b.eq #+0x38 (addr 0x1659a0bc0ad0)
0x1659a0bc0a9c  14bc  71000c7f       cmp w3, #0x3 (3)
0x1659a0bc0aa0  14c0  540000c0       b.eq #+0x18 (addr 0x1659a0bc0ab8)
0x1659a0bc0aa4  14c4  1400000b       b #+0x2c (addr 0x1659a0bc0ad0)
0x1659a0bc0aa8  14c8  340002c3       cbz w3, #+0x58 (addr 0x1659a0bc0b00)
0x1659a0bc0aac  14cc  7100047f       cmp w3, #0x1 (1)
0x1659a0bc0ab0  14d0  540001c0       b.eq #+0x38 (addr 0x1659a0bc0ae8)
0x1659a0bc0ab4  14d4  14000007       b #+0x1c (addr 0x1659a0bc0ad0)
0x1659a0bc0ab8  14d8  8b080023       add x3, x1, x8
0x1659a0bc0abc  14dc  f240047f       tst x3, #0x3
0x1659a0bc0ac0  14e0  540106e1       b.ne #+0x20dc (addr 0x1659a0bc2b9c)
0x1659a0bc0ac4  14e4  8b080023       add x3, x1, x8
0x1659a0bc0ac8  14e8  889ffc65       stlr w5, [x3]
0x1659a0bc0acc  14ec  140000b1       b #+0x2c4 (addr 0x1659a0bc0d90)
0x1659a0bc0ad0  14f0  8b080023       add x3, x1, x8
0x1659a0bc0ad4  14f4  f240087f       tst x3, #0x7
0x1659a0bc0ad8  14f8  54010601       b.ne #+0x20c0 (addr 0x1659a0bc2b98)
0x1659a0bc0adc  14fc  8b080023       add x3, x1, x8
0x1659a0bc0ae0  1500  c89ffc65       stlr x5, [x3]
0x1659a0bc0ae4  1504  140000ab       b #+0x2ac (addr 0x1659a0bc0d90)
0x1659a0bc0ae8  1508  8b080023       add x3, x1, x8
0x1659a0bc0aec  150c  f240007f       tst x3, #0x1
0x1659a0bc0af0  1510  54010521       b.ne #+0x20a4 (addr 0x1659a0bc2b94)
0x1659a0bc0af4  1514  8b080023       add x3, x1, x8
0x1659a0bc0af8  1518  489ffc65       stlrh w5, [x3]
0x1659a0bc0afc  151c  140000a5       b #+0x294 (addr 0x1659a0bc0d90)
0x1659a0bc0b00  1520  8b080023       add x3, x1, x8
0x1659a0bc0b04  1524  089ffc65       stlrb w5, [x3]
0x1659a0bc0b08  1528  140000a2       b #+0x288 (addr 0x1659a0bc0d90)
0x1659a0bc0b0c  152c  11002103       add w3, w8, #0x8 (8)
0x1659a0bc0b10  1530  7200087f       tst w3, #0x7
0x1659a0bc0b14  1534  54000101       b.ne #+0x20 (addr 0x1659a0bc0b34)
0x1659a0bc0b18  1538  8b040024       add x4, x1, x4
0x1659a0bc0b1c  153c  f9400484       ldr x4, [x4, #8]
0x1659a0bc0b20  1540  8b030036       add x22, x1, x3
0x1659a0bc0b24  1544  f2400adf       tst x22, #0x7
0x1659a0bc0b28  1548  54010341       b.ne #+0x2068 (addr 0x1659a0bc2b90)
0x1659a0bc0b2c  154c  8b030036       add x22, x1, x3
0x1659a0bc0b30  1550  c89ffec4       stlr x4, [x22]
0x1659a0bc0b34  1554  7200091f       tst w8, #0x7
0x1659a0bc0b38  1558  540012c1       b.ne #+0x258 (addr 0x1659a0bc0d90)
0x1659a0bc0b3c  155c  8b080023       add x3, x1, x8
0x1659a0bc0b40  1560  f240087f       tst x3, #0x7
0x1659a0bc0b44  1564  54010241       b.ne #+0x2048 (addr 0x1659a0bc2b8c)
0x1659a0bc0b48  1568  8b080023       add x3, x1, x8
0x1659a0bc0b4c  156c  c89ffc65       stlr x5, [x3]
0x1659a0bc0b50  1570  14000090       b #+0x240 (addr 0x1659a0bc0d90)
0x1659a0bc0b54  1574  7100131f       cmp w24, #0x4 (4)
0x1659a0bc0b58  1578  54000aa0       b.eq #+0x154 (addr 0x1659a0bc0cac)
0x1659a0bc0b5c  157c  51000463       sub w3, w3, #0x1 (1)
0x1659a0bc0b60  1580  6a04007f       tst w3, w4
0x1659a0bc0b64  1584  540004a1       b.ne #+0x94 (addr 0x1659a0bc0bf8)
0x1659a0bc0b68  1588  7100087f       cmp w3, #0x2 (2)
0x1659a0bc0b6c  158c  540000cb       b.lt #+0x18 (addr 0x1659a0bc0b84)
0x1659a0bc0b70  1590  7100087f       cmp w3, #0x2 (2)
0x1659a0bc0b74  1594  540001e0       b.eq #+0x3c (addr 0x1659a0bc0bb0)
0x1659a0bc0b78  1598  71000c7f       cmp w3, #0x3 (3)
0x1659a0bc0b7c  159c  540000c0       b.eq #+0x18 (addr 0x1659a0bc0b94)
0x1659a0bc0b80  15a0  1400000c       b #+0x30 (addr 0x1659a0bc0bb0)
0x1659a0bc0b84  15a4  34000323       cbz w3, #+0x64 (addr 0x1659a0bc0be8)
0x1659a0bc0b88  15a8  7100047f       cmp w3, #0x1 (1)
0x1659a0bc0b8c  15ac  54000200       b.eq #+0x40 (addr 0x1659a0bc0bcc)
0x1659a0bc0b90  15b0  14000008       b #+0x20 (addr 0x1659a0bc0bb0)
0x1659a0bc0b94  15b4  2a0403e4       mov w4, w4
0x1659a0bc0b98  15b8  8b040038       add x24, x1, x4
0x1659a0bc0b9c  15bc  f240071f       tst x24, #0x3
0x1659a0bc0ba0  15c0  5400ff41       b.ne #+0x1fe8 (addr 0x1659a0bc2b88)
0x1659a0bc0ba4  15c4  8b040038       add x24, x1, x4
0x1659a0bc0ba8  15c8  88dfff04       ldar w4, [x24]
0x1659a0bc0bac  15cc  14000014       b #+0x50 (addr 0x1659a0bc0bfc)
0x1659a0bc0bb0  15d0  2a0403e4       mov w4, w4
0x1659a0bc0bb4  15d4  8b040038       add x24, x1, x4
0x1659a0bc0bb8  15d8  f2400b1f       tst x24, #0x7
0x1659a0bc0bbc  15dc  5400fe41       b.ne #+0x1fc8 (addr 0x1659a0bc2b84)
0x1659a0bc0bc0  15e0  8b040038       add x24, x1, x4
0x1659a0bc0bc4  15e4  c8dfff04       ldar x4, [x24]
0x1659a0bc0bc8  15e8  1400000d       b #+0x34 (addr 0x1659a0bc0bfc)
0x1659a0bc0bcc  15ec  2a0403e4       mov w4, w4
0x1659a0bc0bd0  15f0  8b040038       add x24, x1, x4
0x1659a0bc0bd4  15f4  f240031f       tst x24, #0x1
0x1659a0bc0bd8  15f8  5400fd41       b.ne #+0x1fa8 (addr 0x1659a0bc2b80)
0x1659a0bc0bdc  15fc  8b040038       add x24, x1, x4
0x1659a0bc0be0  1600  48dfff04       ldarh w4, [x24]
0x1659a0bc0be4  1604  14000006       b #+0x18 (addr 0x1659a0bc0bfc)
0x1659a0bc0be8  1608  2a0403e4       mov w4, w4
0x1659a0bc0bec  160c  8b040038       add x24, x1, x4
0x1659a0bc0bf0  1610  08dfff04       ldarb w4, [x24]
0x1659a0bc0bf4  1614  14000002       b #+0x8 (addr 0x1659a0bc0bfc)
0x1659a0bc0bf8  1618  aa1403e4       mov x4, x20
0x1659a0bc0bfc  161c  37300085       tbnz w5, #6, #+0x10 (addr 0x1659a0bc0c0c)
0x1659a0bc0c00  1620  aa0403e3       mov x3, x4
0x1659a0bc0c04  1624  aa1403e4       mov x4, x20
0x1659a0bc0c08  1628  1400003e       b #+0xf8 (addr 0x1659a0bc0d00)
0x1659a0bc0c0c  162c  6a08007f       tst w3, w8
0x1659a0bc0c10  1630  54000421       b.ne #+0x84 (addr 0x1659a0bc0c94)
0x1659a0bc0c14  1634  7100087f       cmp w3, #0x2 (2)
0x1659a0bc0c18  1638  540000cb       b.lt #+0x18 (addr 0x1659a0bc0c30)
0x1659a0bc0c1c  163c  7100087f       cmp w3, #0x2 (2)
0x1659a0bc0c20  1640  540001c0       b.eq #+0x38 (addr 0x1659a0bc0c58)
0x1659a0bc0c24  1644  71000c7f       cmp w3, #0x3 (3)
0x1659a0bc0c28  1648  540000c0       b.eq #+0x18 (addr 0x1659a0bc0c40)
0x1659a0bc0c2c  164c  1400000b       b #+0x2c (addr 0x1659a0bc0c58)
0x1659a0bc0c30  1650  340002c3       cbz w3, #+0x58 (addr 0x1659a0bc0c88)
0x1659a0bc0c34  1654  7100047f       cmp w3, #0x1 (1)
0x1659a0bc0c38  1658  540001c0       b.eq #+0x38 (addr 0x1659a0bc0c70)
0x1659a0bc0c3c  165c  14000007       b #+0x1c (addr 0x1659a0bc0c58)
0x1659a0bc0c40  1660  8b080023       add x3, x1, x8
0x1659a0bc0c44  1664  f240047f       tst x3, #0x3
0x1659a0bc0c48  1668  5400f9a1       b.ne #+0x1f34 (addr 0x1659a0bc2b7c)
0x1659a0bc0c4c  166c  8b080025       add x5, x1, x8
0x1659a0bc0c50  1670  88dffca3       ldar w3, [x5]
0x1659a0bc0c54  1674  14000011       b #+0x44 (addr 0x1659a0bc0c98)
0x1659a0bc0c58  1678  8b080023       add x3, x1, x8
0x1659a0bc0c5c  167c  f240087f       tst x3, #0x7
0x1659a0bc0c60  1680  5400f8c1       b.ne #+0x1f18 (addr 0x1659a0bc2b78)
0x1659a0bc0c64  1684  8b080025       add x5, x1, x8
0x1659a0bc0c68  1688  c8dffca3       ldar x3, [x5]
0x1659a0bc0c6c  168c  1400000b       b #+0x2c (addr 0x1659a0bc0c98)
0x1659a0bc0c70  1690  8b080023       add x3, x1, x8
0x1659a0bc0c74  1694  f240007f       tst x3, #0x1
0x1659a0bc0c78  1698  5400f7e1       b.ne #+0x1efc (addr 0x1659a0bc2b74)
0x1659a0bc0c7c  169c  8b080025       add x5, x1, x8
0x1659a0bc0c80  16a0  48dffca3       ldarh w3, [x5]
0x1659a0bc0c84  16a4  14000005       b #+0x14 (addr 0x1659a0bc0c98)
0x1659a0bc0c88  16a8  8b080025       add x5, x1, x8
0x1659a0bc0c8c  16ac  08dffca3       ldarb w3, [x5]
0x1659a0bc0c90  16b0  14000002       b #+0x8 (addr 0x1659a0bc0c98)
0x1659a0bc0c94  16b4  aa1403e3       mov x3, x20
0x1659a0bc0c98  16b8  aa0303e5       mov x5, x3
0x1659a0bc0c9c  16bc  aa1403e3       mov x3, x20
0x1659a0bc0ca0  16c0  aa0403e8       mov x8, x4
0x1659a0bc0ca4  16c4  aa1403e4       mov x4, x20
0x1659a0bc0ca8  16c8  14000032       b #+0xc8 (addr 0x1659a0bc0d70)
0x1659a0bc0cac  16cc  7200089f       tst w4, #0x7
0x1659a0bc0cb0  16d0  54000101       b.ne #+0x20 (addr 0x1659a0bc0cd0)
0x1659a0bc0cb4  16d4  2a0403e3       mov w3, w4
0x1659a0bc0cb8  16d8  8b030038       add x24, x1, x3
0x1659a0bc0cbc  16dc  f2400b1f       tst x24, #0x7
0x1659a0bc0cc0  16e0  5400f581       b.ne #+0x1eb0 (addr 0x1659a0bc2b70)
0x1659a0bc0cc4  16e4  8b030038       add x24, x1, x3
0x1659a0bc0cc8  16e8  c8dfff03       ldar x3, [x24]
0x1659a0bc0ccc  16ec  14000002       b #+0x8 (addr 0x1659a0bc0cd4)
0x1659a0bc0cd0  16f0  aa1403e3       mov x3, x20
0x1659a0bc0cd4  16f4  11002084       add w4, w4, #0x8 (8)
0x1659a0bc0cd8  16f8  7200089f       tst w4, #0x7
0x1659a0bc0cdc  16fc  540000e1       b.ne #+0x1c (addr 0x1659a0bc0cf8)
0x1659a0bc0ce0  1700  8b040038       add x24, x1, x4
0x1659a0bc0ce4  1704  f2400b1f       tst x24, #0x7
0x1659a0bc0ce8  1708  5400f421       b.ne #+0x1e84 (addr 0x1659a0bc2b6c)
0x1659a0bc0cec  170c  8b040038       add x24, x1, x4
0x1659a0bc0cf0  1710  c8dfff04       ldar x4, [x24]
0x1659a0bc0cf4  1714  14000002       b #+0x8 (addr 0x1659a0bc0cfc)
0x1659a0bc0cf8  1718  aa1403e4       mov x4, x20
0x1659a0bc0cfc  171c  373000c5       tbnz w5, #6, #+0x18 (addr 0x1659a0bc0d14)
0x1659a0bc0d00  1720  0b161265       add w5, w19, w22, lsl #4
0x1659a0bc0d04  1724  8b050028       add x8, x1, x5
0x1659a0bc0d08  1728  f9000504       str x4, [x8, #8]
0x1659a0bc0d0c  172c  f8256823       str x3, [x1, x5]
0x1659a0bc0d10  1730  14000020       b #+0x80 (addr 0x1659a0bc0d90)
0x1659a0bc0d14  1734  7200091f       tst w8, #0x7
0x1659a0bc0d18  1738  540000e1       b.ne #+0x1c (addr 0x1659a0bc0d34)
0x1659a0bc0d1c  173c  8b080025       add x5, x1, x8
0x1659a0bc0d20  1740  f24008bf       tst x5, #0x7
0x1659a0bc0d24  1744  5400f221       b.ne #+0x1e44 (addr 0x1659a0bc2b68)
0x1659a0bc0d28  1748  8b080038       add x24, x1, x8
0x1659a0bc0d2c  174c  c8dfff05       ldar x5, [x24]
0x1659a0bc0d30  1750  14000002       b #+0x8 (addr 0x1659a0bc0d38)
0x1659a0bc0d34  1754  aa1403e5       mov x5, x20
0x1659a0bc0d38  1758  11002108       add w8, w8, #0x8 (8)
0x1659a0bc0d3c  175c  7200091f       tst w8, #0x7
0x1659a0bc0d40  1760  54000141       b.ne #+0x28 (addr 0x1659a0bc0d68)
0x1659a0bc0d44  1764  8b080038       add x24, x1, x8
0x1659a0bc0d48  1768  f2400b1f       tst x24, #0x7
0x1659a0bc0d4c  176c  5400f0c1       b.ne #+0x1e18 (addr 0x1659a0bc2b64)
0x1659a0bc0d50  1770  8b080038       add x24, x1, x8
0x1659a0bc0d54  1774  c8dfff08       ldar x8, [x24]
0x1659a0bc0d58  1778  aa0803f0       mov x16, x8
0x1659a0bc0d5c  177c  aa0303e8       mov x8, x3
0x1659a0bc0d60  1780  aa1003e3       mov x3, x16
0x1659a0bc0d64  1784  14000003       b #+0xc (addr 0x1659a0bc0d70)
0x1659a0bc0d68  1788  aa0303e8       mov x8, x3
0x1659a0bc0d6c  178c  aa1403e3       mov x3, x20
0x1659a0bc0d70  1790  0b161276       add w22, w19, w22, lsl #4
0x1659a0bc0d74  1794  f8366828       str x8, [x1, x22]
0x1659a0bc0d78  1798  8b160028       add x8, x1, x22
0x1659a0bc0d7c  179c  f9000504       str x4, [x8, #8]
0x1659a0bc0d80  17a0  0b171264       add w4, w19, w23, lsl #4
0x1659a0bc0d84  17a4  f8246825       str x5, [x1, x4]
0x1659a0bc0d88  17a8  8b040024       add x4, x1, x4
0x1659a0bc0d8c  17ac  f9000483       str x3, [x4, #8]
0x1659a0bc0d90  17b0  720004ff       tst w7, #0x3
0x1659a0bc0d94  17b4  5400bc00       b.eq #+0x1780 (addr 0x1659a0bc2514)
0x1659a0bc0d98  17b8  f8226826       str x6, [x1, x2]
0x1659a0bc0d9c  17bc  140005de       b #+0x1778 (addr 0x1659a0bc2514)
0x1659a0bc0da0  17c0  0b180c02       add w2, w0, w24, lsl #3
0x1659a0bc0da4  17c4  f8626822       ldr x2, [x1, x2]
0x1659a0bc0da8  17c8  12000ac3       and w3, w22, #0x7
0x1659a0bc0dac  17cc  7100087f       cmp w3, #0x2 (2)
0x1659a0bc0db0  17d0  540000cb       b.lt #+0x18 (addr 0x1659a0bc0dc8)
0x1659a0bc0db4  17d4  7100087f       cmp w3, #0x2 (2)
0x1659a0bc0db8  17d8  540004e0       b.eq #+0x9c (addr 0x1659a0bc0e54)
0x1659a0bc0dbc  17dc  71000c7f       cmp w3, #0x3 (3)
0x1659a0bc0dc0  17e0  54000180       b.eq #+0x30 (addr 0x1659a0bc0df0)
0x1659a0bc0dc4  17e4  14000005       b #+0x14 (addr 0x1659a0bc0dd8)
0x1659a0bc0dc8  17e8  34000803       cbz w3, #+0x100 (addr 0x1659a0bc0ec8)
0x1659a0bc0dcc  17ec  7100047f       cmp w3, #0x1 (1)
0x1659a0bc0dd0  17f0  540006a0       b.eq #+0xd4 (addr 0x1659a0bc0ea4)
0x1659a0bc0dd4  17f4  14000001       b #+0x4 (addr 0x1659a0bc0dd8)
0x1659a0bc0dd8  17f8  37400096       tbnz w22, #8, #+0x10 (addr 0x1659a0bc0de8)
0x1659a0bc0ddc  17fc  5ac01042       clz w2, w2
0x1659a0bc0de0  1800  2a0203e2       mov w2, w2
0x1659a0bc0de4  1804  14000069       b #+0x1a4 (addr 0x1659a0bc0f88)
0x1659a0bc0de8  1808  dac01042       clz x2, x2
0x1659a0bc0dec  180c  14000067       b #+0x19c (addr 0x1659a0bc0f88)
0x1659a0bc0df0  1810  374000d6       tbnz w22, #8, #+0x18 (addr 0x1659a0bc0e08)
0x1659a0bc0df4  1814  4ac24043       eor w3, w2, w2, ror #16
0x1659a0bc0df8  1818  12089c63       and w3, w3, #0xff00ff00
0x1659a0bc0dfc  181c  53087c63       lsr w3, w3, #8
0x1659a0bc0e00  1820  4ac22062       eor w2, w3, w2, ror #8
0x1659a0bc0e04  1824  14000061       b #+0x184 (addr 0x1659a0bc0f88)
0x1659a0bc0e08  1828  d3481c43       lsl x3, x2, #56
0x1659a0bc0e0c  182c  92781c44       and x4, x2, #0xff00
0x1659a0bc0e10  1830  aa04a063       orr x3, x3, x4, lsl #40
0x1659a0bc0e14  1834  92701c44       and x4, x2, #0xff0000
0x1659a0bc0e18  1838  d3689c84       lsl x4, x4, #24
0x1659a0bc0e1c  183c  92681c45       and x5, x2, #0xff000000
0x1659a0bc0e20  1840  aa052084       orr x4, x4, x5, lsl #8
0x1659a0bc0e24  1844  aa040063       orr x3, x3, x4
0x1659a0bc0e28  1848  d348fc44       lsr x4, x2, #8
0x1659a0bc0e2c  184c  92681c84       and x4, x4, #0xff000000
0x1659a0bc0e30  1850  d358fc45       lsr x5, x2, #24
0x1659a0bc0e34  1854  92701ca5       and x5, x5, #0xff0000
0x1659a0bc0e38  1858  aa050084       orr x4, x4, x5
0x1659a0bc0e3c  185c  d368fc45       lsr x5, x2, #40
0x1659a0bc0e40  1860  92781ca5       and x5, x5, #0xff00
0x1659a0bc0e44  1864  aa42e0a2       orr x2, x5, x2, lsr #56
0x1659a0bc0e48  1868  aa020082       orr x2, x4, x2
0x1659a0bc0e4c  186c  aa020062       orr x2, x3, x2
0x1659a0bc0e50  1870  1400004e       b #+0x138 (addr 0x1659a0bc0f88)
0x1659a0bc0e54  1874  93c28042       ror x2, x2, #32
0x1659a0bc0e58  1878  d3481c43       lsl x3, x2, #56
0x1659a0bc0e5c  187c  92781c44       and x4, x2, #0xff00
0x1659a0bc0e60  1880  aa04a063       orr x3, x3, x4, lsl #40
0x1659a0bc0e64  1884  92701c44       and x4, x2, #0xff0000
0x1659a0bc0e68  1888  d3689c84       lsl x4, x4, #24
0x1659a0bc0e6c  188c  92681c45       and x5, x2, #0xff000000
0x1659a0bc0e70  1890  aa052084       orr x4, x4, x5, lsl #8
0x1659a0bc0e74  1894  aa040063       orr x3, x3, x4
0x1659a0bc0e78  1898  d348fc44       lsr x4, x2, #8
0x1659a0bc0e7c  189c  92681c84       and x4, x4, #0xff000000
0x1659a0bc0e80  18a0  d358fc45       lsr x5, x2, #24
0x1659a0bc0e84  18a4  92701ca5       and x5, x5, #0xff0000
0x1659a0bc0e88  18a8  aa050084       orr x4, x4, x5
0x1659a0bc0e8c  18ac  d368fc45       lsr x5, x2, #40
0x1659a0bc0e90  18b0  92781ca5       and x5, x5, #0xff00
0x1659a0bc0e94  18b4  aa42e0a2       orr x2, x5, x2, lsr #56
0x1659a0bc0e98  18b8  aa020082       orr x2, x4, x2
0x1659a0bc0e9c  18bc  aa020062       orr x2, x3, x2
0x1659a0bc0ea0  18c0  1400003a       b #+0xe8 (addr 0x1659a0bc0f88)
0x1659a0bc0ea4  18c4  d378dc43       lsl x3, x2, #8
0x1659a0bc0ea8  18c8  92089c63       and x3, x3, #0xff00ff00ff00ff00
0x1659a0bc0eac  18cc  d348fc42       lsr x2, x2, #8
0x1659a0bc0eb0  18d0  92009c42       and x2, x2, #0xff00ff00ff00ff
0x1659a0bc0eb4  18d4  aa020062       orr x2, x3, x2
0x1659a0bc0eb8  18d8  92407c43       and x3, x2, #0xffffffff
0x1659a0bc0ebc  18dc  721802df       tst w22, #0x100
0x1659a0bc0ec0  18e0  9a831042       csel x2, x2, x3, ne
0x1659a0bc0ec4  18e4  14000031       b #+0xc4 (addr 0x1659a0bc0f88)
0x1659a0bc0ec8  18e8  37400256       tbnz w22, #8, #+0x48 (addr 0x1659a0bc0f10)
0x1659a0bc0ecc  18ec  4ac24043       eor w3, w2, w2, ror #16
0x1659a0bc0ed0  18f0  12089c63       and w3, w3, #0xff00ff00
0x1659a0bc0ed4  18f4  53087c63       lsr w3, w3, #8
0x1659a0bc0ed8  18f8  4ac22062       eor w2, w3, w2, ror #8
0x1659a0bc0edc  18fc  53047c43       lsr w3, w2, #4
0x1659a0bc0ee0  1900  1200cc63       and w3, w3, #0xf0f0f0f
0x1659a0bc0ee4  1904  1200cc42       and w2, w2, #0xf0f0f0f
0x1659a0bc0ee8  1908  2a021062       orr w2, w3, w2, lsl #4
0x1659a0bc0eec  190c  53027c43       lsr w3, w2, #2
0x1659a0bc0ef0  1910  1200e463       and w3, w3, #0x33333333
0x1659a0bc0ef4  1914  1200e442       and w2, w2, #0x33333333
0x1659a0bc0ef8  1918  2a020862       orr w2, w3, w2, lsl #2
0x1659a0bc0efc  191c  53017c43       lsr w3, w2, #1
0x1659a0bc0f00  1920  1200f063       and w3, w3, #0x55555555
0x1659a0bc0f04  1924  1200f042       and w2, w2, #0x55555555
0x1659a0bc0f08  1928  2a020462       orr w2, w3, w2, lsl #1
0x1659a0bc0f0c  192c  1400001f       b #+0x7c (addr 0x1659a0bc0f88)
0x1659a0bc0f10  1930  d3481c43       lsl x3, x2, #56
0x1659a0bc0f14  1934  92781c44       and x4, x2, #0xff00
0x1659a0bc0f18  1938  aa04a063       orr x3, x3, x4, lsl #40
0x1659a0bc0f1c  193c  92701c44       and x4, x2, #0xff0000
0x1659a0bc0f20  1940  d3689c84       lsl x4, x4, #24
0x1659a0bc0f24  1944  92681c45       and x5, x2, #0xff000000
0x1659a0bc0f28  1948  aa052084       orr x4, x4, x5, lsl #8
0x1659a0bc0f2c  194c  aa040063       orr x3, x3, x4
0x1659a0bc0f30  1950  d348fc44       lsr x4, x2, #8
0x1659a0bc0f34  1954  92681c84       and x4, x4, #0xff000000
0x1659a0bc0f38  1958  d358fc45       lsr x5, x2, #24
0x1659a0bc0f3c  195c  92701ca5       and x5, x5, #0xff0000
0x1659a0bc0f40  1960  aa050084       orr x4, x4, x5
0x1659a0bc0f44  1964  d368fc45       lsr x5, x2, #40
0x1659a0bc0f48  1968  92781ca5       and x5, x5, #0xff00
0x1659a0bc0f4c  196c  aa42e0a2       orr x2, x5, x2, lsr #56
0x1659a0bc0f50  1970  aa020082       orr x2, x4, x2
0x1659a0bc0f54  1974  aa020062       orr x2, x3, x2
0x1659a0bc0f58  1978  d344fc43       lsr x3, x2, #4
0x1659a0bc0f5c  197c  9200cc63       and x3, x3, #0xf0f0f0f0f0f0f0f
0x1659a0bc0f60  1980  9200cc42       and x2, x2, #0xf0f0f0f0f0f0f0f
0x1659a0bc0f64  1984  aa021062       orr x2, x3, x2, lsl #4
0x1659a0bc0f68  1988  d342fc43       lsr x3, x2, #2
0x1659a0bc0f6c  198c  9200e463       and x3, x3, #0x3333333333333333
0x1659a0bc0f70  1990  9200e442       and x2, x2, #0x3333333333333333
0x1659a0bc0f74  1994  aa020862       orr x2, x3, x2, lsl #2
0x1659a0bc0f78  1998  d341fc43       lsr x3, x2, #1
0x1659a0bc0f7c  199c  9200f063       and x3, x3, #0x5555555555555555
0x1659a0bc0f80  19a0  9200f042       and x2, x2, #0x5555555555555555
0x1659a0bc0f84  19a4  aa020462       orr x2, x3, x2, lsl #1
0x1659a0bc0f88  19a8  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc0f8c  19ac  5400ac40       b.eq #+0x1588 (addr 0x1659a0bc2514)
0x1659a0bc0f90  19b0  0b190c03       add w3, w0, w25, lsl #3
0x1659a0bc0f94  19b4  f8236822       str x2, [x1, x3]
0x1659a0bc0f98  19b8  1400055f       b #+0x157c (addr 0x1659a0bc2514)
0x1659a0bc0f9c  19bc  120016c2       and w2, w22, #0x3f
0x1659a0bc0fa0  19c0  0b180c03       add w3, w0, w24, lsl #3
0x1659a0bc0fa4  19c4  f8636823       ldr x3, [x1, x3]
0x1659a0bc0fa8  19c8  39401ae4       ldrb w4, [x23, #6]
0x1659a0bc0fac  19cc  0b040c04       add w4, w0, w4, lsl #3
0x1659a0bc0fb0  19d0  f8646824       ldr x4, [x1, x4]
0x1659a0bc0fb4  19d4  374000f6       tbnz w22, #8, #+0x1c (addr 0x1659a0bc0fd0)
0x1659a0bc0fb8  19d8  92407c84       and x4, x4, #0xffffffff
0x1659a0bc0fbc  19dc  aa038083       orr x3, x4, x3, lsl #32
0x1659a0bc0fc0  19e0  12001442       and w2, w2, #0x3f
0x1659a0bc0fc4  19e4  9ac22462       lsr x2, x3, x2
0x1659a0bc0fc8  19e8  92407c44       and x4, x2, #0xffffffff
0x1659a0bc0fcc  19ec  14000009       b #+0x24 (addr 0x1659a0bc0ff0)
0x1659a0bc0fd0  19f0  34000102       cbz w2, #+0x20 (addr 0x1659a0bc0ff0)
0x1659a0bc0fd4  19f4  12001445       and w5, w2, #0x3f
0x1659a0bc0fd8  19f8  9ac52484       lsr x4, x4, x5
0x1659a0bc0fdc  19fc  d2800805       movz x5, #0x40
0x1659a0bc0fe0  1a00  4b0200a2       sub w2, w5, w2
0x1659a0bc0fe4  1a04  12001442       and w2, w2, #0x3f
0x1659a0bc0fe8  1a08  9ac22062       lsl x2, x3, x2
0x1659a0bc0fec  1a0c  aa020084       orr x4, x4, x2
0x1659a0bc0ff0  1a10  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc0ff4  1a14  5400a900       b.eq #+0x1520 (addr 0x1659a0bc2514)
0x1659a0bc0ff8  1a18  0b190c02       add w2, w0, w25, lsl #3
0x1659a0bc0ffc  1a1c  f8226824       str x4, [x1, x2]
0x1659a0bc1000  1a20  14000545       b #+0x1514 (addr 0x1659a0bc2514)
0x1659a0bc1004  1a24  0b180c02       add w2, w0, w24, lsl #3
0x1659a0bc1008  1a28  39401ae3       ldrb w3, [x23, #6]
0x1659a0bc100c  1a2c  0b030c03       add w3, w0, w3, lsl #3
0x1659a0bc1010  1a30  120012c4       and w4, w22, #0x1f
0x1659a0bc1014  1a34  71007c9f       cmp w4, #0x1f (31)
0x1659a0bc1018  1a38  54000080       b.eq #+0x10 (addr 0x1659a0bc1028)
0x1659a0bc101c  1a3c  0b040c04       add w4, w0, w4, lsl #3
0x1659a0bc1020  1a40  f8646824       ldr x4, [x1, x4]
0x1659a0bc1024  1a44  14000002       b #+0x8 (addr 0x1659a0bc102c)
0x1659a0bc1028  1a48  aa1403e4       mov x4, x20
0x1659a0bc102c  1a4c  b8626822       ldr w2, [x1, x2]
0x1659a0bc1030  1a50  b8636823       ldr w3, [x1, x3]
0x1659a0bc1034  1a54  36300076       tbz w22, #6, #+0xc (addr 0x1659a0bc1040)
0x1659a0bc1038  1a58  93407c63       sxtw x3, w3
0x1659a0bc103c  1a5c  93407c42       sxtw x2, w2
0x1659a0bc1040  1a60  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc1044  1a64  5400a680       b.eq #+0x14d0 (addr 0x1659a0bc2514)
0x1659a0bc1048  1a68  0b190c05       add w5, w0, w25, lsl #3
0x1659a0bc104c  1a6c  9b027c62       mul x2, x3, x2
0x1659a0bc1050  1a70  cb0203e3       neg x3, x2
0x1659a0bc1054  1a74  721b02df       tst w22, #0x20
0x1659a0bc1058  1a78  9a821062       csel x2, x3, x2, ne
0x1659a0bc105c  1a7c  8b040042       add x2, x2, x4
0x1659a0bc1060  1a80  f8256822       str x2, [x1, x5]
0x1659a0bc1064  1a84  1400052c       b #+0x14b0 (addr 0x1659a0bc2514)
0x1659a0bc1068  1a88  0b180c02       add w2, w0, w24, lsl #3
0x1659a0bc106c  1a8c  f8626823       ldr x3, [x1, x2]
0x1659a0bc1070  1a90  71007f1f       cmp w24, #0x1f (31)
0x1659a0bc1074  1a94  54000061       b.ne #+0xc (addr 0x1659a0bc1080)
0x1659a0bc1078  1a98  f2400c7f       tst x3, #0xf
0x1659a0bc107c  1a9c  5400bc01       b.ne #+0x1780 (addr 0x1659a0bc27fc)
0x1659a0bc1080  1aa0  3400bbeb       cbz w11, #+0x177c (addr 0x1659a0bc27fc)
0x1659a0bc1084  1aa4  13107ec4       asr w4, w22, #16
0x1659a0bc1088  1aa8  8b24c064       add x4, x3, w4, sxtw
0x1659a0bc108c  1aac  121806c5       and w5, w22, #0x300
0x1659a0bc1090  1ab0  710400bf       cmp w5, #0x100 (256)
0x1659a0bc1094  1ab4  9a840065       csel x5, x3, x4, eq
0x1659a0bc1098  1ab8  53057ca3       lsr w3, w5, #5
0x1659a0bc109c  1abc  12193463       and w3, w3, #0x1fff80
0x1659a0bc10a0  1ac0  0b030163       add w3, w11, w3
0x1659a0bc10a4  1ac4  71007f7f       cmp w27, #0x1f (31)
0x1659a0bc10a8  1ac8  9a9f07e6       cset x6, ne
0x1659a0bc10ac  1acc  0b061063       add w3, w3, w6, lsl #4
0x1659a0bc10b0  1ad0  f8636826       ldr x6, [x1, x3]
0x1659a0bc10b4  1ad4  12000ec7       and w7, w22, #0xf
0x1659a0bc10b8  1ad8  531f78e8       lsl w8, w7, #1
0x1659a0bc10bc  1adc  8b050108       add x8, x8, x5
0x1659a0bc10c0  1ae0  d1000508       sub x8, x8, #0x1 (1)
0x1659a0bc10c4  1ae4  b2402d08       orr x8, x8, #0xfff
0x1659a0bc10c8  1ae8  eb0800df       cmp x6, x8
0x1659a0bc10cc  1aec  5400b981       b.ne #+0x1730 (addr 0x1659a0bc27fc)
0x1659a0bc10d0  1af0  510004e6       sub w6, w7, #0x1 (1)
0x1659a0bc10d4  1af4  8b030023       add x3, x1, x3
0x1659a0bc10d8  1af8  f9400463       ldr x3, [x3, #8]
0x1659a0bc10dc  1afc  8b050063       add x3, x3, x5
0x1659a0bc10e0  1b00  6a0300df       tst w6, w3
0x1659a0bc10e4  1b04  5400b8c1       b.ne #+0x1718 (addr 0x1659a0bc27fc)
0x1659a0bc10e8  1b08  39401ae5       ldrb w5, [x23, #6]
0x1659a0bc10ec  1b0c  0b070067       add w7, w3, w7
0x1659a0bc10f0  1b10  71007f7f       cmp w27, #0x1f (31)
0x1659a0bc10f4  1b14  54000940       b.eq #+0x128 (addr 0x1659a0bc121c)
0x1659a0bc10f8  1b18  0b050c05       add w5, w0, w5, lsl #3
0x1659a0bc10fc  1b1c  f8656825       ldr x5, [x1, x5]
0x1659a0bc1100  1b20  0b190c08       add w8, w0, w25, lsl #3
0x1659a0bc1104  1b24  f8686828       ldr x8, [x1, x8]
0x1659a0bc1108  1b28  710008df       cmp w6, #0x2 (2)
0x1659a0bc110c  1b2c  540000cb       b.lt #+0x18 (addr 0x1659a0bc1124)
0x1659a0bc1110  1b30  710008df       cmp w6, #0x2 (2)
0x1659a0bc1114  1b34  540001e0       b.eq #+0x3c (addr 0x1659a0bc1150)
0x1659a0bc1118  1b38  71000cdf       cmp w6, #0x3 (3)
0x1659a0bc111c  1b3c  540000c0       b.eq #+0x18 (addr 0x1659a0bc1134)
0x1659a0bc1120  1b40  1400000c       b #+0x30 (addr 0x1659a0bc1150)
0x1659a0bc1124  1b44  34000326       cbz w6, #+0x64 (addr 0x1659a0bc1188)
0x1659a0bc1128  1b48  710004df       cmp w6, #0x1 (1)
0x1659a0bc112c  1b4c  54000200       b.eq #+0x40 (addr 0x1659a0bc116c)
0x1659a0bc1130  1b50  14000008       b #+0x20 (addr 0x1659a0bc1150)
0x1659a0bc1134  1b54  2a0303e3       mov w3, w3
0x1659a0bc1138  1b58  8b030037       add x23, x1, x3
0x1659a0bc113c  1b5c  f24006ff       tst x23, #0x3
0x1659a0bc1140  1b60  5400d101       b.ne #+0x1a20 (addr 0x1659a0bc2b60)
0x1659a0bc1144  1b64  8b030037       add x23, x1, x3
0x1659a0bc1148  1b68  889ffee8       stlr w8, [x23]
0x1659a0bc114c  1b6c  14000012       b #+0x48 (addr 0x1659a0bc1194)
0x1659a0bc1150  1b70  2a0303e3       mov w3, w3
0x1659a0bc1154  1b74  8b030037       add x23, x1, x3
0x1659a0bc1158  1b78  f2400aff       tst x23, #0x7
0x1659a0bc115c  1b7c  5400d001       b.ne #+0x1a00 (addr 0x1659a0bc2b5c)
0x1659a0bc1160  1b80  8b030037       add x23, x1, x3
0x1659a0bc1164  1b84  c89ffee8       stlr x8, [x23]
0x1659a0bc1168  1b88  1400000b       b #+0x2c (addr 0x1659a0bc1194)
0x1659a0bc116c  1b8c  2a0303e3       mov w3, w3
0x1659a0bc1170  1b90  8b030037       add x23, x1, x3
0x1659a0bc1174  1b94  f24002ff       tst x23, #0x1
0x1659a0bc1178  1b98  5400cf01       b.ne #+0x19e0 (addr 0x1659a0bc2b58)
0x1659a0bc117c  1b9c  8b030037       add x23, x1, x3
0x1659a0bc1180  1ba0  489ffee8       stlrh w8, [x23]
0x1659a0bc1184  1ba4  14000004       b #+0x10 (addr 0x1659a0bc1194)
0x1659a0bc1188  1ba8  2a0303e3       mov w3, w3
0x1659a0bc118c  1bac  8b030037       add x23, x1, x3
0x1659a0bc1190  1bb0  089ffee8       stlrb w8, [x23]
0x1659a0bc1194  1bb4  6a0700df       tst w6, w7
0x1659a0bc1198  1bb8  54000ee1       b.ne #+0x1dc (addr 0x1659a0bc1374)
0x1659a0bc119c  1bbc  710008df       cmp w6, #0x2 (2)
0x1659a0bc11a0  1bc0  540000cb       b.lt #+0x18 (addr 0x1659a0bc11b8)
0x1659a0bc11a4  1bc4  710008df       cmp w6, #0x2 (2)
0x1659a0bc11a8  1bc8  540001c0       b.eq #+0x38 (addr 0x1659a0bc11e0)
0x1659a0bc11ac  1bcc  71000cdf       cmp w6, #0x3 (3)
0x1659a0bc11b0  1bd0  540000c0       b.eq #+0x18 (addr 0x1659a0bc11c8)
0x1659a0bc11b4  1bd4  1400000b       b #+0x2c (addr 0x1659a0bc11e0)
0x1659a0bc11b8  1bd8  340002c6       cbz w6, #+0x58 (addr 0x1659a0bc1210)
0x1659a0bc11bc  1bdc  710004df       cmp w6, #0x1 (1)
0x1659a0bc11c0  1be0  540001c0       b.eq #+0x38 (addr 0x1659a0bc11f8)
0x1659a0bc11c4  1be4  14000007       b #+0x1c (addr 0x1659a0bc11e0)
0x1659a0bc11c8  1be8  8b070023       add x3, x1, x7
0x1659a0bc11cc  1bec  f240047f       tst x3, #0x3
0x1659a0bc11d0  1bf0  5400cc21       b.ne #+0x1984 (addr 0x1659a0bc2b54)
0x1659a0bc11d4  1bf4  8b070023       add x3, x1, x7
0x1659a0bc11d8  1bf8  889ffc65       stlr w5, [x3]
0x1659a0bc11dc  1bfc  14000066       b #+0x198 (addr 0x1659a0bc1374)
0x1659a0bc11e0  1c00  8b070023       add x3, x1, x7
0x1659a0bc11e4  1c04  f240087f       tst x3, #0x7
0x1659a0bc11e8  1c08  5400cb41       b.ne #+0x1968 (addr 0x1659a0bc2b50)
0x1659a0bc11ec  1c0c  8b070023       add x3, x1, x7
0x1659a0bc11f0  1c10  c89ffc65       stlr x5, [x3]
0x1659a0bc11f4  1c14  14000060       b #+0x180 (addr 0x1659a0bc1374)
0x1659a0bc11f8  1c18  8b070023       add x3, x1, x7
0x1659a0bc11fc  1c1c  f240007f       tst x3, #0x1
0x1659a0bc1200  1c20  5400ca61       b.ne #+0x194c (addr 0x1659a0bc2b4c)
0x1659a0bc1204  1c24  8b070023       add x3, x1, x7
0x1659a0bc1208  1c28  489ffc65       stlrh w5, [x3]
0x1659a0bc120c  1c2c  1400005a       b #+0x168 (addr 0x1659a0bc1374)
0x1659a0bc1210  1c30  8b070023       add x3, x1, x7
0x1659a0bc1214  1c34  089ffc65       stlrb w5, [x3]
0x1659a0bc1218  1c38  14000057       b #+0x15c (addr 0x1659a0bc1374)
0x1659a0bc121c  1c3c  710008df       cmp w6, #0x2 (2)
0x1659a0bc1220  1c40  540000cb       b.lt #+0x18 (addr 0x1659a0bc1238)
0x1659a0bc1224  1c44  710008df       cmp w6, #0x2 (2)
0x1659a0bc1228  1c48  540001e0       b.eq #+0x3c (addr 0x1659a0bc1264)
0x1659a0bc122c  1c4c  71000cdf       cmp w6, #0x3 (3)
0x1659a0bc1230  1c50  540000c0       b.eq #+0x18 (addr 0x1659a0bc1248)
0x1659a0bc1234  1c54  1400000c       b #+0x30 (addr 0x1659a0bc1264)
0x1659a0bc1238  1c58  34000326       cbz w6, #+0x64 (addr 0x1659a0bc129c)
0x1659a0bc123c  1c5c  710004df       cmp w6, #0x1 (1)
0x1659a0bc1240  1c60  54000200       b.eq #+0x40 (addr 0x1659a0bc1280)
0x1659a0bc1244  1c64  14000008       b #+0x20 (addr 0x1659a0bc1264)
0x1659a0bc1248  1c68  2a0303e3       mov w3, w3
0x1659a0bc124c  1c6c  8b030028       add x8, x1, x3
0x1659a0bc1250  1c70  f240051f       tst x8, #0x3
0x1659a0bc1254  1c74  5400c7a1       b.ne #+0x18f4 (addr 0x1659a0bc2b48)
0x1659a0bc1258  1c78  8b030028       add x8, x1, x3
0x1659a0bc125c  1c7c  88dffd03       ldar w3, [x8]
0x1659a0bc1260  1c80  14000012       b #+0x48 (addr 0x1659a0bc12a8)
0x1659a0bc1264  1c84  2a0303e3       mov w3, w3
0x1659a0bc1268  1c88  8b030028       add x8, x1, x3
0x1659a0bc126c  1c8c  f240091f       tst x8, #0x7
0x1659a0bc1270  1c90  5400c6a1       b.ne #+0x18d4 (addr 0x1659a0bc2b44)
0x1659a0bc1274  1c94  8b030028       add x8, x1, x3
0x1659a0bc1278  1c98  c8dffd03       ldar x3, [x8]
0x1659a0bc127c  1c9c  1400000b       b #+0x2c (addr 0x1659a0bc12a8)
0x1659a0bc1280  1ca0  2a0303e3       mov w3, w3
0x1659a0bc1284  1ca4  8b030028       add x8, x1, x3
0x1659a0bc1288  1ca8  f240011f       tst x8, #0x1
0x1659a0bc128c  1cac  5400c5a1       b.ne #+0x18b4 (addr 0x1659a0bc2b40)
0x1659a0bc1290  1cb0  8b030028       add x8, x1, x3
0x1659a0bc1294  1cb4  48dffd03       ldarh w3, [x8]
0x1659a0bc1298  1cb8  14000004       b #+0x10 (addr 0x1659a0bc12a8)
0x1659a0bc129c  1cbc  2a0303e3       mov w3, w3
0x1659a0bc12a0  1cc0  8b030028       add x8, x1, x3
0x1659a0bc12a4  1cc4  08dffd03       ldarb w3, [x8]
0x1659a0bc12a8  1cc8  6a0700df       tst w6, w7
0x1659a0bc12ac  1ccc  54000421       b.ne #+0x84 (addr 0x1659a0bc1330)
0x1659a0bc12b0  1cd0  710008df       cmp w6, #0x2 (2)
0x1659a0bc12b4  1cd4  540000cb       b.lt #+0x18 (addr 0x1659a0bc12cc)
0x1659a0bc12b8  1cd8  710008df       cmp w6, #0x2 (2)
0x1659a0bc12bc  1cdc  540001c0       b.eq #+0x38 (addr 0x1659a0bc12f4)
0x1659a0bc12c0  1ce0  71000cdf       cmp w6, #0x3 (3)
0x1659a0bc12c4  1ce4  540000c0       b.eq #+0x18 (addr 0x1659a0bc12dc)
0x1659a0bc12c8  1ce8  1400000b       b #+0x2c (addr 0x1659a0bc12f4)
0x1659a0bc12cc  1cec  340002c6       cbz w6, #+0x58 (addr 0x1659a0bc1324)
0x1659a0bc12d0  1cf0  710004df       cmp w6, #0x1 (1)
0x1659a0bc12d4  1cf4  540001c0       b.eq #+0x38 (addr 0x1659a0bc130c)
0x1659a0bc12d8  1cf8  14000007       b #+0x1c (addr 0x1659a0bc12f4)
0x1659a0bc12dc  1cfc  8b070026       add x6, x1, x7
0x1659a0bc12e0  1d00  f24004df       tst x6, #0x3
0x1659a0bc12e4  1d04  5400c2c1       b.ne #+0x1858 (addr 0x1659a0bc2b3c)
0x1659a0bc12e8  1d08  8b070027       add x7, x1, x7
0x1659a0bc12ec  1d0c  88dffce6       ldar w6, [x7]
0x1659a0bc12f0  1d10  14000011       b #+0x44 (addr 0x1659a0bc1334)
0x1659a0bc12f4  1d14  8b070026       add x6, x1, x7
0x1659a0bc12f8  1d18  f24008df       tst x6, #0x7
0x1659a0bc12fc  1d1c  5400c1e1       b.ne #+0x183c (addr 0x1659a0bc2b38)
0x1659a0bc1300  1d20  8b070027       add x7, x1, x7
0x1659a0bc1304  1d24  c8dffce6       ldar x6, [x7]
0x1659a0bc1308  1d28  1400000b       b #+0x2c (addr 0x1659a0bc1334)
0x1659a0bc130c  1d2c  8b070026       add x6, x1, x7
0x1659a0bc1310  1d30  f24000df       tst x6, #0x1
0x1659a0bc1314  1d34  5400c101       b.ne #+0x1820 (addr 0x1659a0bc2b34)
0x1659a0bc1318  1d38  8b070027       add x7, x1, x7
0x1659a0bc131c  1d3c  48dffce6       ldarh w6, [x7]
0x1659a0bc1320  1d40  14000005       b #+0x14 (addr 0x1659a0bc1334)
0x1659a0bc1324  1d44  8b070027       add x7, x1, x7
0x1659a0bc1328  1d48  08dffce6       ldarb w6, [x7]
0x1659a0bc132c  1d4c  14000002       b #+0x8 (addr 0x1659a0bc1334)
0x1659a0bc1330  1d50  aa1403e6       mov x6, x20
0x1659a0bc1334  1d54  372000d6       tbnz w22, #4, #+0x18 (addr 0x1659a0bc134c)
0x1659a0bc1338  1d58  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc133c  1d5c  54000140       b.eq #+0x28 (addr 0x1659a0bc1364)
0x1659a0bc1340  1d60  0b190c07       add w7, w0, w25, lsl #3
0x1659a0bc1344  1d64  f8276823       str x3, [x1, x7]
0x1659a0bc1348  1d68  14000007       b #+0x1c (addr 0x1659a0bc1364)
0x1659a0bc134c  1d6c  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc1350  1d70  54000080       b.eq #+0x10 (addr 0x1659a0bc1360)
0x1659a0bc1354  1d74  0b190c07       add w7, w0, w25, lsl #3
0x1659a0bc1358  1d78  93407c63       sxtw x3, w3
0x1659a0bc135c  1d7c  f8276823       str x3, [x1, x7]
0x1659a0bc1360  1d80  93407cc6       sxtw x6, w6
0x1659a0bc1364  1d84  71007cbf       cmp w5, #0x1f (31)
0x1659a0bc1368  1d88  54000060       b.eq #+0xc (addr 0x1659a0bc1374)
0x1659a0bc136c  1d8c  0b050c03       add w3, w0, w5, lsl #3
0x1659a0bc1370  1d90  f8236826       str x6, [x1, x3]
0x1659a0bc1374  1d94  36408d16       tbz w22, #8, #+0x11a0 (addr 0x1659a0bc2514)
0x1659a0bc1378  1d98  f8226824       str x4, [x1, x2]
0x1659a0bc137c  1d9c  14000466       b #+0x1198 (addr 0x1659a0bc2514)
0x1659a0bc1380  1da0  0b180c02       add w2, w0, w24, lsl #3
0x1659a0bc1384  1da4  f8626822       ldr x2, [x1, x2]
0x1659a0bc1388  1da8  71007f1f       cmp w24, #0x1f (31)
0x1659a0bc138c  1dac  54000061       b.ne #+0xc (addr 0x1659a0bc1398)
0x1659a0bc1390  1db0  f2400c5f       tst x2, #0xf
0x1659a0bc1394  1db4  5400a341       b.ne #+0x1468 (addr 0x1659a0bc27fc)
0x1659a0bc1398  1db8  120002c3       and w3, w22, #0x1
0x1659a0bc139c  1dbc  d2800084       movz x4, #0x4
0x1659a0bc13a0  1dc0  1ac32083       lsl w3, w4, w3
0x1659a0bc13a4  1dc4  13107ec5       asr w5, w22, #16
0x1659a0bc13a8  1dc8  8b25c042       add x2, x2, w5, sxtw
0x1659a0bc13ac  1dcc  71007b7f       cmp w27, #0x1e (30)
0x1659a0bc13b0  1dd0  54000480       b.eq #+0x90 (addr 0x1659a0bc1440)
0x1659a0bc13b4  1dd4  3400a24b       cbz w11, #+0x1448 (addr 0x1659a0bc27fc)
0x1659a0bc13b8  1dd8  53057c45       lsr w5, w2, #5
0x1659a0bc13bc  1ddc  121934a5       and w5, w5, #0x1fff80
0x1659a0bc13c0  1de0  0b050165       add w5, w11, w5
0x1659a0bc13c4  1de4  f8656826       ldr x6, [x1, x5]
0x1659a0bc13c8  1de8  8b020067       add x7, x3, x2
0x1659a0bc13cc  1dec  d10004e7       sub x7, x7, #0x1 (1)
0x1659a0bc13d0  1df0  b2402ce7       orr x7, x7, #0xfff
0x1659a0bc13d4  1df4  eb0700df       cmp x6, x7
0x1659a0bc13d8  1df8  5400a121       b.ne #+0x1424 (addr 0x1659a0bc27fc)
0x1659a0bc13dc  1dfc  51000463       sub w3, w3, #0x1 (1)
0x1659a0bc13e0  1e00  8b050025       add x5, x1, x5
0x1659a0bc13e4  1e04  f94004a5       ldr x5, [x5, #8]
0x1659a0bc13e8  1e08  8b0200a2       add x2, x5, x2
0x1659a0bc13ec  1e0c  6a02007f       tst w3, w2
0x1659a0bc13f0  1e10  5400a061       b.ne #+0x140c (addr 0x1659a0bc27fc)
0x1659a0bc13f4  1e14  37000116       tbnz w22, #0, #+0x20 (addr 0x1659a0bc1414)
0x1659a0bc13f8  1e18  2a0203e2       mov w2, w2
0x1659a0bc13fc  1e1c  8b020023       add x3, x1, x2
0x1659a0bc1400  1e20  f240047f       tst x3, #0x3
0x1659a0bc1404  1e24  5400b961       b.ne #+0x172c (addr 0x1659a0bc2b30)
0x1659a0bc1408  1e28  8b020023       add x3, x1, x2
0x1659a0bc140c  1e2c  88dffc62       ldar w2, [x3]
0x1659a0bc1410  1e30  14000007       b #+0x1c (addr 0x1659a0bc142c)
0x1659a0bc1414  1e34  2a0203e2       mov w2, w2
0x1659a0bc1418  1e38  8b020023       add x3, x1, x2
0x1659a0bc141c  1e3c  f240087f       tst x3, #0x7
0x1659a0bc1420  1e40  5400b861       b.ne #+0x170c (addr 0x1659a0bc2b2c)
0x1659a0bc1424  1e44  8b020023       add x3, x1, x2
0x1659a0bc1428  1e48  c8dffc62       ldar x2, [x3]
0x1659a0bc142c  1e4c  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc1430  1e50  54000480       b.eq #+0x90 (addr 0x1659a0bc14c0)
0x1659a0bc1434  1e54  0b190c03       add w3, w0, w25, lsl #3
0x1659a0bc1438  1e58  f8236822       str x2, [x1, x3]
0x1659a0bc143c  1e5c  14000021       b #+0x84 (addr 0x1659a0bc14c0)
0x1659a0bc1440  1e60  34009deb       cbz w11, #+0x13bc (addr 0x1659a0bc27fc)
0x1659a0bc1444  1e64  53057c45       lsr w5, w2, #5
0x1659a0bc1448  1e68  121934a5       and w5, w5, #0x1fff80
0x1659a0bc144c  1e6c  0b050165       add w5, w11, w5
0x1659a0bc1450  1e70  8b050025       add x5, x1, x5
0x1659a0bc1454  1e74  f94008a6       ldr x6, [x5, #16]
0x1659a0bc1458  1e78  8b020067       add x7, x3, x2
0x1659a0bc145c  1e7c  d10004e7       sub x7, x7, #0x1 (1)
0x1659a0bc1460  1e80  b2402ce7       orr x7, x7, #0xfff
0x1659a0bc1464  1e84  eb0700df       cmp x6, x7
0x1659a0bc1468  1e88  54009ca1       b.ne #+0x1394 (addr 0x1659a0bc27fc)
0x1659a0bc146c  1e8c  51000463       sub w3, w3, #0x1 (1)
0x1659a0bc1470  1e90  f9400ca5       ldr x5, [x5, #24]
0x1659a0bc1474  1e94  8b0200a2       add x2, x5, x2
0x1659a0bc1478  1e98  6a02007f       tst w3, w2
0x1659a0bc147c  1e9c  54009c01       b.ne #+0x1380 (addr 0x1659a0bc27fc)
0x1659a0bc1480  1ea0  0b190c03       add w3, w0, w25, lsl #3
0x1659a0bc1484  1ea4  f8636823       ldr x3, [x1, x3]
0x1659a0bc1488  1ea8  37000116       tbnz w22, #0, #+0x20 (addr 0x1659a0bc14a8)
0x1659a0bc148c  1eac  2a0203e2       mov w2, w2
0x1659a0bc1490  1eb0  8b020025       add x5, x1, x2
0x1659a0bc1494  1eb4  f24004bf       tst x5, #0x3
0x1659a0bc1498  1eb8  5400b481       b.ne #+0x1690 (addr 0x1659a0bc2b28)
0x1659a0bc149c  1ebc  8b020025       add x5, x1, x2
0x1659a0bc14a0  1ec0  889ffca3       stlr w3, [x5]
0x1659a0bc14a4  1ec4  14000007       b #+0x1c (addr 0x1659a0bc14c0)
0x1659a0bc14a8  1ec8  2a0203e2       mov w2, w2
0x1659a0bc14ac  1ecc  8b020025       add x5, x1, x2
0x1659a0bc14b0  1ed0  f24008bf       tst x5, #0x7
0x1659a0bc14b4  1ed4  5400b381       b.ne #+0x1670 (addr 0x1659a0bc2b24)
0x1659a0bc14b8  1ed8  8b020025       add x5, x1, x2
0x1659a0bc14bc  1edc  c89ffca3       stlr x3, [x5]
0x1659a0bc14c0  1ee0  367882b6       tbz w22, #15, #+0x1054 (addr 0x1659a0bc2514)
0x1659a0bc14c4  1ee4  110021e2       add w2, w15, #0x8 (8)
0x1659a0bc14c8  1ee8  6b0e005f       cmp w2, w14
0x1659a0bc14cc  1eec  54008240       b.eq #+0x1048 (addr 0x1659a0bc2514)
0x1659a0bc14d0  1ef0  910011ad       add x13, x13, #0x4 (4)
0x1659a0bc14d4  1ef4  394036e3       ldrb w3, [x23, #13]
0x1659a0bc14d8  1ef8  0b030c05       add w5, w0, w3, lsl #3
0x1659a0bc14dc  1efc  f8656825       ldr x5, [x1, x5]
0x1659a0bc14e0  1f00  394032e6       ldrb w6, [x23, #12]
0x1659a0bc14e4  1f04  71007c7f       cmp w3, #0x1f (31)
0x1659a0bc14e8  1f08  54000061       b.ne #+0xc (addr 0x1659a0bc14f4)
0x1659a0bc14ec  1f0c  f2400cbf       tst x5, #0xf
0x1659a0bc14f0  1f10  54009841       b.ne #+0x1308 (addr 0x1659a0bc27f8)
0x1659a0bc14f4  1f14  b9400ae3       ldr w3, [x23, #8]
0x1659a0bc14f8  1f18  12000067       and w7, w3, #0x1
0x1659a0bc14fc  1f1c  1ac72084       lsl w4, w4, w7
0x1659a0bc1500  1f20  13107c67       asr w7, w3, #16
0x1659a0bc1504  1f24  8b27c0a5       add x5, x5, w7, sxtw
0x1659a0bc1508  1f28  53057ca7       lsr w7, w5, #5
0x1659a0bc150c  1f2c  121934e7       and w7, w7, #0x1fff80
0x1659a0bc1510  1f30  0b070167       add w7, w11, w7
0x1659a0bc1514  1f34  39403ee8       ldrb w8, [x23, #15]
0x1659a0bc1518  1f38  7100791f       cmp w8, #0x1e (30)
0x1659a0bc151c  1f3c  54000460       b.eq #+0x8c (addr 0x1659a0bc15a8)
0x1659a0bc1520  1f40  f8676828       ldr x8, [x1, x7]
0x1659a0bc1524  1f44  8b05008f       add x15, x4, x5
0x1659a0bc1528  1f48  d10005ef       sub x15, x15, #0x1 (1)
0x1659a0bc152c  1f4c  b2402def       orr x15, x15, #0xfff
0x1659a0bc1530  1f50  eb0f011f       cmp x8, x15
0x1659a0bc1534  1f54  54009621       b.ne #+0x12c4 (addr 0x1659a0bc27f8)
0x1659a0bc1538  1f58  51000484       sub w4, w4, #0x1 (1)
0x1659a0bc153c  1f5c  8b070027       add x7, x1, x7
0x1659a0bc1540  1f60  f94004e7       ldr x7, [x7, #8]
0x1659a0bc1544  1f64  8b0500e5       add x5, x7, x5
0x1659a0bc1548  1f68  6a05009f       tst w4, w5
0x1659a0bc154c  1f6c  54009561       b.ne #+0x12ac (addr 0x1659a0bc27f8)
0x1659a0bc1550  1f70  37000103       tbnz w3, #0, #+0x20 (addr 0x1659a0bc1570)
0x1659a0bc1554  1f74  2a0503e3       mov w3, w5
0x1659a0bc1558  1f78  8b030024       add x4, x1, x3
0x1659a0bc155c  1f7c  f240049f       tst x4, #0x3
0x1659a0bc1560  1f80  5400ae01       b.ne #+0x15c0 (addr 0x1659a0bc2b20)
0x1659a0bc1564  1f84  8b030024       add x4, x1, x3
0x1659a0bc1568  1f88  88dffc83       ldar w3, [x4]
0x1659a0bc156c  1f8c  14000007       b #+0x1c (addr 0x1659a0bc1588)
0x1659a0bc1570  1f90  2a0503e3       mov w3, w5
0x1659a0bc1574  1f94  8b030024       add x4, x1, x3
0x1659a0bc1578  1f98  f240089f       tst x4, #0x7
0x1659a0bc157c  1f9c  5400ad01       b.ne #+0x15a0 (addr 0x1659a0bc2b1c)
0x1659a0bc1580  1fa0  8b030024       add x4, x1, x3
0x1659a0bc1584  1fa4  c8dffc83       ldar x3, [x4]
0x1659a0bc1588  1fa8  71007cdf       cmp w6, #0x1f (31)
0x1659a0bc158c  1fac  540000a0       b.eq #+0x14 (addr 0x1659a0bc15a0)
0x1659a0bc1590  1fb0  0b060c04       add w4, w0, w6, lsl #3
0x1659a0bc1594  1fb4  f8246823       str x3, [x1, x4]
0x1659a0bc1598  1fb8  aa0203ef       mov x15, x2
0x1659a0bc159c  1fbc  140003de       b #+0xf78 (addr 0x1659a0bc2514)
0x1659a0bc15a0  1fc0  aa0203ef       mov x15, x2
0x1659a0bc15a4  1fc4  140003dc       b #+0xf70 (addr 0x1659a0bc2514)
0x1659a0bc15a8  1fc8  8b070027       add x7, x1, x7
0x1659a0bc15ac  1fcc  f94008e8       ldr x8, [x7, #16]
0x1659a0bc15b0  1fd0  8b05008f       add x15, x4, x5
0x1659a0bc15b4  1fd4  d10005ef       sub x15, x15, #0x1 (1)
0x1659a0bc15b8  1fd8  b2402def       orr x15, x15, #0xfff
0x1659a0bc15bc  1fdc  eb0f011f       cmp x8, x15
0x1659a0bc15c0  1fe0  540091c1       b.ne #+0x1238 (addr 0x1659a0bc27f8)
0x1659a0bc15c4  1fe4  51000484       sub w4, w4, #0x1 (1)
0x1659a0bc15c8  1fe8  f9400ce7       ldr x7, [x7, #24]
0x1659a0bc15cc  1fec  8b0500e5       add x5, x7, x5
0x1659a0bc15d0  1ff0  6a05009f       tst w4, w5
0x1659a0bc15d4  1ff4  54009121       b.ne #+0x1224 (addr 0x1659a0bc27f8)
0x1659a0bc15d8  1ff8  0b060c04       add w4, w0, w6, lsl #3
0x1659a0bc15dc  1ffc  f8646824       ldr x4, [x1, x4]
0x1659a0bc15e0  2000  37000123       tbnz w3, #0, #+0x24 (addr 0x1659a0bc1604)
0x1659a0bc15e4  2004  2a0503e3       mov w3, w5
0x1659a0bc15e8  2008  8b030025       add x5, x1, x3
0x1659a0bc15ec  200c  f24004bf       tst x5, #0x3
0x1659a0bc15f0  2010  5400a941       b.ne #+0x1528 (addr 0x1659a0bc2b18)
0x1659a0bc15f4  2014  8b030025       add x5, x1, x3
0x1659a0bc15f8  2018  889ffca4       stlr w4, [x5]
0x1659a0bc15fc  201c  aa0203ef       mov x15, x2
0x1659a0bc1600  2020  140003c5       b #+0xf14 (addr 0x1659a0bc2514)
0x1659a0bc1604  2024  2a0503e3       mov w3, w5
0x1659a0bc1608  2028  8b030025       add x5, x1, x3
0x1659a0bc160c  202c  f24008bf       tst x5, #0x7
0x1659a0bc1610  2030  5400a821       b.ne #+0x1504 (addr 0x1659a0bc2b14)
0x1659a0bc1614  2034  8b030025       add x5, x1, x3
0x1659a0bc1618  2038  c89ffca4       stlr x4, [x5]
0x1659a0bc161c  203c  aa0203ef       mov x15, x2
0x1659a0bc1620  2040  140003bd       b #+0xef4 (addr 0x1659a0bc2514)
0x1659a0bc1624  2044  0b180c02       add w2, w0, w24, lsl #3
0x1659a0bc1628  2048  f8626823       ldr x3, [x1, x2]
0x1659a0bc162c  204c  71007f1f       cmp w24, #0x1f (31)
0x1659a0bc1630  2050  54000061       b.ne #+0xc (addr 0x1659a0bc163c)
0x1659a0bc1634  2054  f2400c7f       tst x3, #0xf
0x1659a0bc1638  2058  54008e21       b.ne #+0x11c4 (addr 0x1659a0bc27fc)
0x1659a0bc163c  205c  93507ec4       sbfx x4, x22, #16, #16
0x1659a0bc1640  2060  53020ec5       ubfx w5, w22, #2, #2
0x1659a0bc1644  2064  710008bf       cmp w5, #0x2 (2)
0x1659a0bc1648  2068  540000cb       b.lt #+0x18 (addr 0x1659a0bc1660)
0x1659a0bc164c  206c  710008bf       cmp w5, #0x2 (2)
0x1659a0bc1650  2070  540004e0       b.eq #+0x9c (addr 0x1659a0bc16ec)
0x1659a0bc1654  2074  71000cbf       cmp w5, #0x3 (3)
0x1659a0bc1658  2078  540000c0       b.eq #+0x18 (addr 0x1659a0bc1670)
0x1659a0bc165c  207c  1400002b       b #+0xac (addr 0x1659a0bc1708)
0x1659a0bc1660  2080  34000545       cbz w5, #+0xa8 (addr 0x1659a0bc1708)
0x1659a0bc1664  2084  710004bf       cmp w5, #0x1 (1)
0x1659a0bc1668  2088  54000480       b.eq #+0x90 (addr 0x1659a0bc16f8)
0x1659a0bc166c  208c  14000027       b #+0x9c (addr 0x1659a0bc1708)
0x1659a0bc1670  2090  530c7ec4       lsr w4, w22, #12
0x1659a0bc1674  2094  39401ae5       ldrb w5, [x23, #6]
0x1659a0bc1678  2098  0b050c05       add w5, w0, w5, lsl #3
0x1659a0bc167c  209c  f8656825       ldr x5, [x1, x5]
0x1659a0bc1680  20a0  53082ac6       ubfx w6, w22, #8, #3
0x1659a0bc1684  20a4  f1001cdf       cmp x6, #0x7 (7)
0x1659a0bc1688  20a8  54000262       b.hs #+0x4c (addr 0x1659a0bc16d4)
0x1659a0bc168c  20ac  1000ae90       adr x16, #+0x15d0 (addr 0x1659a0bc2c5c)
0x1659a0bc1690  20b0  aa0203e2       mov x2, x2
0x1659a0bc1694  20b4  aa0203e2       mov x2, x2
0x1659a0bc1698  20b8  d2800011       movz x17, #0x0
0x1659a0bc169c  20bc  b8a67a11       ldrsw x17, [x16, x6, lsl #2]
0x1659a0bc16a0  20c0  8b110210       add x16, x16, x17
0x1659a0bc16a4  20c4  d61f0200       br x16
0x1659a0bc16a8  20c8  93407ca5       sxtw x5, w5
0x1659a0bc16ac  20cc  1400000a       b #+0x28 (addr 0x1659a0bc16d4)
0x1659a0bc16b0  20d0  93403ca5       sxth x5, w5
0x1659a0bc16b4  20d4  14000008       b #+0x20 (addr 0x1659a0bc16d4)
0x1659a0bc16b8  20d8  93401ca5       sxtb x5, w5
0x1659a0bc16bc  20dc  14000006       b #+0x18 (addr 0x1659a0bc16d4)
0x1659a0bc16c0  20e0  92407ca5       and x5, x5, #0xffffffff
0x1659a0bc16c4  20e4  14000004       b #+0x10 (addr 0x1659a0bc16d4)
0x1659a0bc16c8  20e8  92403ca5       and x5, x5, #0xffff
0x1659a0bc16cc  20ec  14000002       b #+0x8 (addr 0x1659a0bc16d4)
0x1659a0bc16d0  20f0  92401ca5       and x5, x5, #0xff
0x1659a0bc16d4  20f4  12000884       and w4, w4, #0x7
0x1659a0bc16d8  20f8  9ac420a4       lsl x4, x5, x4
0x1659a0bc16dc  20fc  8b030083       add x3, x4, x3
0x1659a0bc16e0  2100  aa0503e4       mov x4, x5
0x1659a0bc16e4  2104  d2800005       movz x5, #0x0
0x1659a0bc16e8  2108  1400000a       b #+0x28 (addr 0x1659a0bc1710)
0x1659a0bc16ec  210c  8b040064       add x4, x3, x4
0x1659a0bc16f0  2110  d2800025       movz x5, #0x1
0x1659a0bc16f4  2114  14000007       b #+0x1c (addr 0x1659a0bc1710)
0x1659a0bc16f8  2118  8b040064       add x4, x3, x4
0x1659a0bc16fc  211c  d2800025       movz x5, #0x1
0x1659a0bc1700  2120  aa0403e3       mov x3, x4
0x1659a0bc1704  2124  14000003       b #+0xc (addr 0x1659a0bc1710)
0x1659a0bc1708  2128  8b040063       add x3, x3, x4
0x1659a0bc170c  212c  d2800005       movz x5, #0x0
0x1659a0bc1710  2130  120006c6       and w6, w22, #0x3
0x1659a0bc1714  2134  d2800027       movz x7, #0x1
0x1659a0bc1718  2138  1ac620e7       lsl w7, w7, w6
0x1659a0bc171c  213c  7100737f       cmp w27, #0x1c (28)
0x1659a0bc1720  2140  540009c0       b.eq #+0x138 (addr 0x1659a0bc1858)
0x1659a0bc1724  2144  340086cb       cbz w11, #+0x10d8 (addr 0x1659a0bc27fc)
0x1659a0bc1728  2148  53057c68       lsr w8, w3, #5
0x1659a0bc172c  214c  12193508       and w8, w8, #0x1fff80
0x1659a0bc1730  2150  0b080168       add w8, w11, w8
0x1659a0bc1734  2154  f8686837       ldr x23, [x1, x8]
0x1659a0bc1738  2158  8b0300f8       add x24, x7, x3
0x1659a0bc173c  215c  d1000718       sub x24, x24, #0x1 (1)
0x1659a0bc1740  2160  b2402f18       orr x24, x24, #0xfff
0x1659a0bc1744  2164  eb1802ff       cmp x23, x24
0x1659a0bc1748  2168  540085a1       b.ne #+0x10b4 (addr 0x1659a0bc27fc)
0x1659a0bc174c  216c  510004e7       sub w7, w7, #0x1 (1)
0x1659a0bc1750  2170  8b080028       add x8, x1, x8
0x1659a0bc1754  2174  f9400508       ldr x8, [x8, #8]
0x1659a0bc1758  2178  8b030103       add x3, x8, x3
0x1659a0bc175c  217c  6a0300ff       tst w7, w3
0x1659a0bc1760  2180  540084e1       b.ne #+0x109c (addr 0x1659a0bc27fc)
0x1659a0bc1764  2184  710008ff       cmp w7, #0x2 (2)
0x1659a0bc1768  2188  540000cb       b.lt #+0x18 (addr 0x1659a0bc1780)
0x1659a0bc176c  218c  710008ff       cmp w7, #0x2 (2)
0x1659a0bc1770  2190  540001e0       b.eq #+0x3c (addr 0x1659a0bc17ac)
0x1659a0bc1774  2194  71000cff       cmp w7, #0x3 (3)
0x1659a0bc1778  2198  540000c0       b.eq #+0x18 (addr 0x1659a0bc1790)
0x1659a0bc177c  219c  1400000c       b #+0x30 (addr 0x1659a0bc17ac)
0x1659a0bc1780  21a0  34000327       cbz w7, #+0x64 (addr 0x1659a0bc17e4)
0x1659a0bc1784  21a4  710004ff       cmp w7, #0x1 (1)
0x1659a0bc1788  21a8  54000200       b.eq #+0x40 (addr 0x1659a0bc17c8)
0x1659a0bc178c  21ac  14000008       b #+0x20 (addr 0x1659a0bc17ac)
0x1659a0bc1790  21b0  2a0303e3       mov w3, w3
0x1659a0bc1794  21b4  8b030027       add x7, x1, x3
0x1659a0bc1798  21b8  f24004ff       tst x7, #0x3
0x1659a0bc179c  21bc  54009ba1       b.ne #+0x1374 (addr 0x1659a0bc2b10)
0x1659a0bc17a0  21c0  8b030027       add x7, x1, x3
0x1659a0bc17a4  21c4  88dffce3       ldar w3, [x7]
0x1659a0bc17a8  21c8  14000012       b #+0x48 (addr 0x1659a0bc17f0)
0x1659a0bc17ac  21cc  2a0303e3       mov w3, w3
0x1659a0bc17b0  21d0  8b030027       add x7, x1, x3
0x1659a0bc17b4  21d4  f24008ff       tst x7, #0x7
0x1659a0bc17b8  21d8  54009aa1       b.ne #+0x1354 (addr 0x1659a0bc2b0c)
0x1659a0bc17bc  21dc  8b030027       add x7, x1, x3
0x1659a0bc17c0  21e0  c8dffce3       ldar x3, [x7]
0x1659a0bc17c4  21e4  1400000b       b #+0x2c (addr 0x1659a0bc17f0)
0x1659a0bc17c8  21e8  2a0303e3       mov w3, w3
0x1659a0bc17cc  21ec  8b030027       add x7, x1, x3
0x1659a0bc17d0  21f0  f24000ff       tst x7, #0x1
0x1659a0bc17d4  21f4  540099a1       b.ne #+0x1334 (addr 0x1659a0bc2b08)
0x1659a0bc17d8  21f8  8b030027       add x7, x1, x3
0x1659a0bc17dc  21fc  48dffce3       ldarh w3, [x7]
0x1659a0bc17e0  2200  14000004       b #+0x10 (addr 0x1659a0bc17f0)
0x1659a0bc17e4  2204  2a0303e3       mov w3, w3
0x1659a0bc17e8  2208  8b030027       add x7, x1, x3
0x1659a0bc17ec  220c  08dffce3       ldarb w3, [x7]
0x1659a0bc17f0  2210  121c06c7       and w7, w22, #0x30
0x1659a0bc17f4  2214  710040ff       cmp w7, #0x10 (16)
0x1659a0bc17f8  2218  54000180       b.eq #+0x30 (addr 0x1659a0bc1828)
0x1659a0bc17fc  221c  721c06df       tst w22, #0x30
0x1659a0bc1800  2220  54000220       b.eq #+0x44 (addr 0x1659a0bc1844)
0x1659a0bc1804  2224  120010c6       and w6, w6, #0x1f
0x1659a0bc1808  2228  928000e7       movn x7, #0x7
0x1659a0bc180c  222c  1ac620e6       lsl w6, w7, w6
0x1659a0bc1810  2230  110100c6       add w6, w6, #0x40 (64)
0x1659a0bc1814  2234  120014c6       and w6, w6, #0x3f
0x1659a0bc1818  2238  9ac62063       lsl x3, x3, x6
0x1659a0bc181c  223c  9ac62863       asr x3, x3, x6
0x1659a0bc1820  2240  92407c63       and x3, x3, #0xffffffff
0x1659a0bc1824  2244  14000008       b #+0x20 (addr 0x1659a0bc1844)
0x1659a0bc1828  2248  120010c6       and w6, w6, #0x1f
0x1659a0bc182c  224c  928000e7       movn x7, #0x7
0x1659a0bc1830  2250  1ac620e6       lsl w6, w7, w6
0x1659a0bc1834  2254  110100c6       add w6, w6, #0x40 (64)
0x1659a0bc1838  2258  120014c6       and w6, w6, #0x3f
0x1659a0bc183c  225c  9ac62063       lsl x3, x3, x6
0x1659a0bc1840  2260  9ac62863       asr x3, x3, x6
0x1659a0bc1844  2264  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc1848  2268  54000720       b.eq #+0xe4 (addr 0x1659a0bc192c)
0x1659a0bc184c  226c  0b190c06       add w6, w0, w25, lsl #3
0x1659a0bc1850  2270  f8266823       str x3, [x1, x6]
0x1659a0bc1854  2274  14000036       b #+0xd8 (addr 0x1659a0bc192c)
0x1659a0bc1858  2278  34007d2b       cbz w11, #+0xfa4 (addr 0x1659a0bc27fc)
0x1659a0bc185c  227c  53057c66       lsr w6, w3, #5
0x1659a0bc1860  2280  121934c6       and w6, w6, #0x1fff80
0x1659a0bc1864  2284  0b060166       add w6, w11, w6
0x1659a0bc1868  2288  8b060026       add x6, x1, x6
0x1659a0bc186c  228c  f94008c8       ldr x8, [x6, #16]
0x1659a0bc1870  2290  8b0300f6       add x22, x7, x3
0x1659a0bc1874  2294  d10006d6       sub x22, x22, #0x1 (1)
0x1659a0bc1878  2298  b2402ed6       orr x22, x22, #0xfff
0x1659a0bc187c  229c  eb16011f       cmp x8, x22
0x1659a0bc1880  22a0  54007be1       b.ne #+0xf7c (addr 0x1659a0bc27fc)
0x1659a0bc1884  22a4  510004e7       sub w7, w7, #0x1 (1)
0x1659a0bc1888  22a8  f9400cc6       ldr x6, [x6, #24]
0x1659a0bc188c  22ac  8b0300c3       add x3, x6, x3
0x1659a0bc1890  22b0  6a0300ff       tst w7, w3
0x1659a0bc1894  22b4  54007b41       b.ne #+0xf68 (addr 0x1659a0bc27fc)
0x1659a0bc1898  22b8  0b190c06       add w6, w0, w25, lsl #3
0x1659a0bc189c  22bc  f8666826       ldr x6, [x1, x6]
0x1659a0bc18a0  22c0  710008ff       cmp w7, #0x2 (2)
0x1659a0bc18a4  22c4  540000cb       b.lt #+0x18 (addr 0x1659a0bc18bc)
0x1659a0bc18a8  22c8  710008ff       cmp w7, #0x2 (2)
0x1659a0bc18ac  22cc  540001e0       b.eq #+0x3c (addr 0x1659a0bc18e8)
0x1659a0bc18b0  22d0  71000cff       cmp w7, #0x3 (3)
0x1659a0bc18b4  22d4  540000c0       b.eq #+0x18 (addr 0x1659a0bc18cc)
0x1659a0bc18b8  22d8  1400000c       b #+0x30 (addr 0x1659a0bc18e8)
0x1659a0bc18bc  22dc  34000327       cbz w7, #+0x64 (addr 0x1659a0bc1920)
0x1659a0bc18c0  22e0  710004ff       cmp w7, #0x1 (1)
0x1659a0bc18c4  22e4  54000200       b.eq #+0x40 (addr 0x1659a0bc1904)
0x1659a0bc18c8  22e8  14000008       b #+0x20 (addr 0x1659a0bc18e8)
0x1659a0bc18cc  22ec  2a0303e3       mov w3, w3
0x1659a0bc18d0  22f0  8b030027       add x7, x1, x3
0x1659a0bc18d4  22f4  f24004ff       tst x7, #0x3
0x1659a0bc18d8  22f8  54009161       b.ne #+0x122c (addr 0x1659a0bc2b04)
0x1659a0bc18dc  22fc  8b030027       add x7, x1, x3
0x1659a0bc18e0  2300  889ffce6       stlr w6, [x7]
0x1659a0bc18e4  2304  14000012       b #+0x48 (addr 0x1659a0bc192c)
0x1659a0bc18e8  2308  2a0303e3       mov w3, w3
0x1659a0bc18ec  230c  8b030027       add x7, x1, x3
0x1659a0bc18f0  2310  f24008ff       tst x7, #0x7
0x1659a0bc18f4  2314  54009061       b.ne #+0x120c (addr 0x1659a0bc2b00)
0x1659a0bc18f8  2318  8b030027       add x7, x1, x3
0x1659a0bc18fc  231c  c89ffce6       stlr x6, [x7]
0x1659a0bc1900  2320  1400000b       b #+0x2c (addr 0x1659a0bc192c)
0x1659a0bc1904  2324  2a0303e3       mov w3, w3
0x1659a0bc1908  2328  8b030027       add x7, x1, x3
0x1659a0bc190c  232c  f24000ff       tst x7, #0x1
0x1659a0bc1910  2330  54008f61       b.ne #+0x11ec (addr 0x1659a0bc2afc)
0x1659a0bc1914  2334  8b030027       add x7, x1, x3
0x1659a0bc1918  2338  489ffce6       stlrh w6, [x7]
0x1659a0bc191c  233c  14000004       b #+0x10 (addr 0x1659a0bc192c)
0x1659a0bc1920  2340  2a0303e3       mov w3, w3
0x1659a0bc1924  2344  8b030027       add x7, x1, x3
0x1659a0bc1928  2348  089ffce6       stlrb w6, [x7]
0x1659a0bc192c  234c  34005f45       cbz w5, #+0xbe8 (addr 0x1659a0bc2514)
0x1659a0bc1930  2350  f8226824       str x4, [x1, x2]
0x1659a0bc1934  2354  140002f8       b #+0xbe0 (addr 0x1659a0bc2514)
0x1659a0bc1938  2358  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc193c  235c  54005ec0       b.eq #+0xbd8 (addr 0x1659a0bc2514)
0x1659a0bc1940  2360  0b190c02       add w2, w0, w25, lsl #3
0x1659a0bc1944  2364  93407ec3       sxtw x3, w22
0x1659a0bc1948  2368  9274cda4       and x4, x13, #0xfffffffffffff000
0x1659a0bc194c  236c  8b033083       add x3, x4, x3, lsl #12
0x1659a0bc1950  2370  f8226823       str x3, [x1, x2]
0x1659a0bc1954  2374  140002f0       b #+0xbc0 (addr 0x1659a0bc2514)
0x1659a0bc1958  2378  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc195c  237c  54005dc0       b.eq #+0xbb8 (addr 0x1659a0bc2514)
0x1659a0bc1960  2380  0b190c02       add w2, w0, w25, lsl #3
0x1659a0bc1964  2384  8b36c1a3       add x3, x13, w22, sxtw
0x1659a0bc1968  2388  f8226823       str x3, [x1, x2]
0x1659a0bc196c  238c  140002ea       b #+0xba8 (addr 0x1659a0bc2514)
0x1659a0bc1970  2390  120012c2       and w2, w22, #0x1f
0x1659a0bc1974  2394  71007c5f       cmp w2, #0x1f (31)
0x1659a0bc1978  2398  54000080       b.eq #+0x10 (addr 0x1659a0bc1988)
0x1659a0bc197c  239c  0b020c02       add w2, w0, w2, lsl #3
0x1659a0bc1980  23a0  f8626822       ldr x2, [x1, x2]
0x1659a0bc1984  23a4  14000002       b #+0x8 (addr 0x1659a0bc198c)
0x1659a0bc1988  23a8  aa1403e2       mov x2, x20
0x1659a0bc198c  23ac  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc1990  23b0  54005c20       b.eq #+0xb84 (addr 0x1659a0bc2514)
0x1659a0bc1994  23b4  0b190c03       add w3, w0, w25, lsl #3
0x1659a0bc1998  23b8  39401ae4       ldrb w4, [x23, #6]
0x1659a0bc199c  23bc  0b040c04       add w4, w0, w4, lsl #3
0x1659a0bc19a0  23c0  f8646824       ldr x4, [x1, x4]
0x1659a0bc19a4  23c4  0b180c05       add w5, w0, w24, lsl #3
0x1659a0bc19a8  23c8  f8656825       ldr x5, [x1, x5]
0x1659a0bc19ac  23cc  9b057c84       mul x4, x4, x5
0x1659a0bc19b0  23d0  cb0403e5       neg x5, x4
0x1659a0bc19b4  23d4  721b02df       tst w22, #0x20
0x1659a0bc19b8  23d8  9a8410a4       csel x4, x5, x4, ne
0x1659a0bc19bc  23dc  8b040042       add x2, x2, x4
0x1659a0bc19c0  23e0  92407c44       and x4, x2, #0xffffffff
0x1659a0bc19c4  23e4  721a02df       tst w22, #0x40
0x1659a0bc19c8  23e8  9a841042       csel x2, x2, x4, ne
0x1659a0bc19cc  23ec  f8236822       str x2, [x1, x3]
0x1659a0bc19d0  23f0  140002d1       b #+0xb44 (addr 0x1659a0bc2514)
0x1659a0bc19d4  23f4  53107ec2       lsr w2, w22, #16
0x1659a0bc19d8  23f8  2a0003e3       mov w3, w0
0x1659a0bc19dc  23fc  8b030023       add x3, x1, x3
0x1659a0bc19e0  2400  b9410864       ldr w4, [x3, #264]
0x1659a0bc19e4  2404  531c7c84       lsr w4, w4, #28
0x1659a0bc19e8  2408  1ac42442       lsr w2, w2, w4
0x1659a0bc19ec  240c  370000a2       tbnz w2, #0, #+0x14 (addr 0x1659a0bc1a00)
0x1659a0bc19f0  2410  530c2ec2       lsl w2, w22, #20
0x1659a0bc19f4  2414  12040c42       and w2, w2, #0xf0000000
0x1659a0bc19f8  2418  f9008462       str x2, [x3, #264]
0x1659a0bc19fc  241c  140002c6       b #+0xb18 (addr 0x1659a0bc2514)
0x1659a0bc1a00  2420  39401ae2       ldrb w2, [x23, #6]
0x1659a0bc1a04  2424  37200076       tbnz w22, #4, #+0xc (addr 0x1659a0bc1a10)
0x1659a0bc1a08  2428  0b020c02       add w2, w0, w2, lsl #3
0x1659a0bc1a0c  242c  f8626822       ldr x2, [x1, x2]
0x1659a0bc1a10  2430  121b02c4       and w4, w22, #0x20
0x1659a0bc1a14  2434  53061485       lsl w5, w4, #26
0x1659a0bc1a18  2438  935f7ca5       sbfx x5, x5, #31, #1
0x1659a0bc1a1c  243c  ca050042       eor x2, x2, x5
0x1659a0bc1a20  2440  0b180c05       add w5, w0, w24, lsl #3
0x1659a0bc1a24  2444  f8656825       ldr x5, [x1, x5]
0x1659a0bc1a28  2448  373002d6       tbnz w22, #6, #+0x58 (addr 0x1659a0bc1a80)
0x1659a0bc1a2c  244c  0b050046       add w6, w2, w5
0x1659a0bc1a30  2450  0b4414c4       add w4, w6, w4, lsr #5
0x1659a0bc1a34  2454  d2a80007       movz x7, #0x40000000
0x1659a0bc1a38  2458  6a04009f       tst w4, w4
0x1659a0bc1a3c  245c  9a8713e7       csel x7, xzr, x7, ne
0x1659a0bc1a40  2460  12010088       and w8, w4, #0x80000000
0x1659a0bc1a44  2464  aa0800e7       orr x7, x7, x8
0x1659a0bc1a48  2468  d2a40008       movz x8, #0x20000000
0x1659a0bc1a4c  246c  6b06009f       cmp w4, w6
0x1659a0bc1a50  2470  9a943116       csel x22, x8, x20, lo
0x1659a0bc1a54  2474  6b0200df       cmp w6, w2
0x1659a0bc1a58  2478  9a963106       csel x6, x8, x22, lo
0x1659a0bc1a5c  247c  aa0600e6       orr x6, x7, x6
0x1659a0bc1a60  2480  4a050085       eor w5, w4, w5
0x1659a0bc1a64  2484  4a020082       eor w2, w4, w2
0x1659a0bc1a68  2488  0a0200a2       and w2, w5, w2
0x1659a0bc1a6c  248c  53037c42       lsr w2, w2, #3
0x1659a0bc1a70  2490  12040042       and w2, w2, #0x10000000
0x1659a0bc1a74  2494  aa0200c2       orr x2, x6, x2
0x1659a0bc1a78  2498  f9008462       str x2, [x3, #264]
0x1659a0bc1a7c  249c  140002a6       b #+0xa98 (addr 0x1659a0bc2514)
0x1659a0bc1a80  24a0  8b050044       add x4, x2, x5
0x1659a0bc1a84  24a4  530516c6       ubfx w6, w22, #5, #1
0x1659a0bc1a88  24a8  8b060086       add x6, x4, x6
0x1659a0bc1a8c  24ac  d360fcc7       lsr x7, x6, #32
0x1659a0bc1a90  24b0  926100e7       and x7, x7, #0x80000000
0x1659a0bc1a94  24b4  d2a80008       movz x8, #0x40000000
0x1659a0bc1a98  24b8  f10000df       cmp x6, #0x0 (0)
0x1659a0bc1a9c  24bc  9a9f0108       csel x8, x8, xzr, eq
0x1659a0bc1aa0  24c0  aa0800e7       orr x7, x7, x8
0x1659a0bc1aa4  24c4  d2a40008       movz x8, #0x20000000
0x1659a0bc1aa8  24c8  eb0400df       cmp x6, x4
0x1659a0bc1aac  24cc  9a9f3116       csel x22, x8, xzr, lo
0x1659a0bc1ab0  24d0  eb02009f       cmp x4, x2
0x1659a0bc1ab4  24d4  9a963104       csel x4, x8, x22, lo
0x1659a0bc1ab8  24d8  aa0400e4       orr x4, x7, x4
0x1659a0bc1abc  24dc  ca0500c5       eor x5, x6, x5
0x1659a0bc1ac0  24e0  ca0200c2       eor x2, x6, x2
0x1659a0bc1ac4  24e4  8a0200a2       and x2, x5, x2
0x1659a0bc1ac8  24e8  d363fc42       lsr x2, x2, #35
0x1659a0bc1acc  24ec  92640042       and x2, x2, #0x10000000
0x1659a0bc1ad0  24f0  aa020082       orr x2, x4, x2
0x1659a0bc1ad4  24f4  f9008462       str x2, [x3, #264]
0x1659a0bc1ad8  24f8  1400028f       b #+0xa3c (addr 0x1659a0bc2514)
0x1659a0bc1adc  24fc  53107ec2       lsr w2, w22, #16
0x1659a0bc1ae0  2500  2a0003e3       mov w3, w0
0x1659a0bc1ae4  2504  8b030023       add x3, x1, x3
0x1659a0bc1ae8  2508  b9410863       ldr w3, [x3, #264]
0x1659a0bc1aec  250c  531c7c63       lsr w3, w3, #28
0x1659a0bc1af0  2510  1ac32442       lsr w2, w2, w3
0x1659a0bc1af4  2514  370002c2       tbnz w2, #0, #+0x58 (addr 0x1659a0bc1b4c)
0x1659a0bc1af8  2518  39401ae2       ldrb w2, [x23, #6]
0x1659a0bc1afc  251c  0b020c02       add w2, w0, w2, lsl #3
0x1659a0bc1b00  2520  f8626822       ldr x2, [x1, x2]
0x1659a0bc1b04  2524  530416c3       ubfx w3, w22, #4, #2
0x1659a0bc1b08  2528  7100087f       cmp w3, #0x2 (2)
0x1659a0bc1b0c  252c  540000cb       b.lt #+0x18 (addr 0x1659a0bc1b24)
0x1659a0bc1b10  2530  7100087f       cmp w3, #0x2 (2)
0x1659a0bc1b14  2534  54000140       b.eq #+0x28 (addr 0x1659a0bc1b3c)
0x1659a0bc1b18  2538  71000c7f       cmp w3, #0x3 (3)
0x1659a0bc1b1c  253c  540000c0       b.eq #+0x18 (addr 0x1659a0bc1b34)
0x1659a0bc1b20  2540  1400000d       b #+0x34 (addr 0x1659a0bc1b54)
0x1659a0bc1b24  2544  34000183       cbz w3, #+0x30 (addr 0x1659a0bc1b54)
0x1659a0bc1b28  2548  7100047f       cmp w3, #0x1 (1)
0x1659a0bc1b2c  254c  540000c0       b.eq #+0x18 (addr 0x1659a0bc1b44)
0x1659a0bc1b30  2550  14000009       b #+0x24 (addr 0x1659a0bc1b54)
0x1659a0bc1b34  2554  cb0203e2       neg x2, x2
0x1659a0bc1b38  2558  14000007       b #+0x1c (addr 0x1659a0bc1b54)
0x1659a0bc1b3c  255c  aa2203e2       mvn x2, x2
0x1659a0bc1b40  2560  14000005       b #+0x14 (addr 0x1659a0bc1b54)
0x1659a0bc1b44  2564  91000442       add x2, x2, #0x1 (1)
0x1659a0bc1b48  2568  14000003       b #+0xc (addr 0x1659a0bc1b54)
0x1659a0bc1b4c  256c  0b180c02       add w2, w0, w24, lsl #3
0x1659a0bc1b50  2570  f8626822       ldr x2, [x1, x2]
0x1659a0bc1b54  2574  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc1b58  2578  54004de0       b.eq #+0x9bc (addr 0x1659a0bc2514)
0x1659a0bc1b5c  257c  0b190c03       add w3, w0, w25, lsl #3
0x1659a0bc1b60  2580  92407c44       and x4, x2, #0xffffffff
0x1659a0bc1b64  2584  721a02df       tst w22, #0x40
0x1659a0bc1b68  2588  9a841042       csel x2, x2, x4, ne
0x1659a0bc1b6c  258c  f8236822       str x2, [x1, x3]
0x1659a0bc1b70  2590  14000269       b #+0x9a4 (addr 0x1659a0bc2514)
0x1659a0bc1b74  2594  0b180c02       add w2, w0, w24, lsl #3
0x1659a0bc1b78  2598  f8626822       ldr x2, [x1, x2]
0x1659a0bc1b7c  259c  92407c43       and x3, x2, #0xffffffff
0x1659a0bc1b80  25a0  721e02df       tst w22, #0x4
0x1659a0bc1b84  25a4  9a831043       csel x3, x2, x3, ne
0x1659a0bc1b88  25a8  39401ae4       ldrb w4, [x23, #6]
0x1659a0bc1b8c  25ac  0b040c04       add w4, w0, w4, lsl #3
0x1659a0bc1b90  25b0  f8646824       ldr x4, [x1, x4]
0x1659a0bc1b94  25b4  d28007e5       movz x5, #0x3f
0x1659a0bc1b98  25b8  721e02df       tst w22, #0x4
0x1659a0bc1b9c  25bc  9a9510a5       csel x5, x5, x21, ne
0x1659a0bc1ba0  25c0  8a050084       and x4, x4, x5
0x1659a0bc1ba4  25c4  120006c5       and w5, w22, #0x3
0x1659a0bc1ba8  25c8  710008bf       cmp w5, #0x2 (2)
0x1659a0bc1bac  25cc  540000cb       b.lt #+0x18 (addr 0x1659a0bc1bc4)
0x1659a0bc1bb0  25d0  710008bf       cmp w5, #0x2 (2)
0x1659a0bc1bb4  25d4  540001e0       b.eq #+0x3c (addr 0x1659a0bc1bf0)
0x1659a0bc1bb8  25d8  71000cbf       cmp w5, #0x3 (3)
0x1659a0bc1bbc  25dc  540000c0       b.eq #+0x18 (addr 0x1659a0bc1bd4)
0x1659a0bc1bc0  25e0  14000016       b #+0x58 (addr 0x1659a0bc1c18)
0x1659a0bc1bc4  25e4  340002a5       cbz w5, #+0x54 (addr 0x1659a0bc1c18)
0x1659a0bc1bc8  25e8  710004bf       cmp w5, #0x1 (1)
0x1659a0bc1bcc  25ec  54000200       b.eq #+0x40 (addr 0x1659a0bc1c0c)
0x1659a0bc1bd0  25f0  14000012       b #+0x48 (addr 0x1659a0bc1c18)
0x1659a0bc1bd4  25f4  37100096       tbnz w22, #2, #+0x10 (addr 0x1659a0bc1be4)
0x1659a0bc1bd8  25f8  12001083       and w3, w4, #0x1f
0x1659a0bc1bdc  25fc  1ac32c42       ror w2, w2, w3
0x1659a0bc1be0  2600  14000011       b #+0x44 (addr 0x1659a0bc1c24)
0x1659a0bc1be4  2604  12001483       and w3, w4, #0x3f
0x1659a0bc1be8  2608  9ac32c42       ror x2, x2, x3
0x1659a0bc1bec  260c  1400000f       b #+0x3c (addr 0x1659a0bc1c28)
0x1659a0bc1bf0  2610  37100096       tbnz w22, #2, #+0x10 (addr 0x1659a0bc1c00)
0x1659a0bc1bf4  2614  12001083       and w3, w4, #0x1f
0x1659a0bc1bf8  2618  1ac32842       asr w2, w2, w3
0x1659a0bc1bfc  261c  1400000a       b #+0x28 (addr 0x1659a0bc1c24)
0x1659a0bc1c00  2620  12001483       and w3, w4, #0x3f
0x1659a0bc1c04  2624  9ac32842       asr x2, x2, x3
0x1659a0bc1c08  2628  14000008       b #+0x20 (addr 0x1659a0bc1c28)
0x1659a0bc1c0c  262c  12001482       and w2, w4, #0x3f
0x1659a0bc1c10  2630  9ac22462       lsr x2, x3, x2
0x1659a0bc1c14  2634  14000003       b #+0xc (addr 0x1659a0bc1c20)
0x1659a0bc1c18  2638  12001482       and w2, w4, #0x3f
0x1659a0bc1c1c  263c  9ac22062       lsl x2, x3, x2
0x1659a0bc1c20  2640  37100056       tbnz w22, #2, #+0x8 (addr 0x1659a0bc1c28)
0x1659a0bc1c24  2644  92407c42       and x2, x2, #0xffffffff
0x1659a0bc1c28  2648  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc1c2c  264c  54004740       b.eq #+0x8e8 (addr 0x1659a0bc2514)
0x1659a0bc1c30  2650  0b190c03       add w3, w0, w25, lsl #3
0x1659a0bc1c34  2654  f8236822       str x2, [x1, x3]
0x1659a0bc1c38  2658  14000237       b #+0x8dc (addr 0x1659a0bc2514)
0x1659a0bc1c3c  265c  0b180c02       add w2, w0, w24, lsl #3
0x1659a0bc1c40  2660  f8626822       ldr x2, [x1, x2]
0x1659a0bc1c44  2664  120016c3       and w3, w22, #0x3f
0x1659a0bc1c48  2668  39401ae4       ldrb w4, [x23, #6]
0x1659a0bc1c4c  266c  12001484       and w4, w4, #0x3f
0x1659a0bc1c50  2670  6b04007f       cmp w3, w4
0x1659a0bc1c54  2674  54000143       b.lo #+0x28 (addr 0x1659a0bc1c7c)
0x1659a0bc1c58  2678  12001483       and w3, w4, #0x3f
0x1659a0bc1c5c  267c  9ac32442       lsr x2, x2, x3
0x1659a0bc1c60  2680  2a3603e3       mvn w3, w22
0x1659a0bc1c64  2684  0b040063       add w3, w3, w4
0x1659a0bc1c68  2688  12001463       and w3, w3, #0x3f
0x1659a0bc1c6c  268c  9ac32042       lsl x2, x2, x3
0x1659a0bc1c70  2690  9ac32842       asr x2, x2, x3
0x1659a0bc1c74  2694  37400236       tbnz w22, #8, #+0x44 (addr 0x1659a0bc1cb8)
0x1659a0bc1c78  2698  1400000a       b #+0x28 (addr 0x1659a0bc1ca0)
0x1659a0bc1c7c  269c  52001463       eor w3, w3, #0x3f
0x1659a0bc1c80  26a0  12001463       and w3, w3, #0x3f
0x1659a0bc1c84  26a4  9ac32042       lsl x2, x2, x3
0x1659a0bc1c88  26a8  9ac32842       asr x2, x2, x3
0x1659a0bc1c8c  26ac  374000f6       tbnz w22, #8, #+0x1c (addr 0x1659a0bc1ca8)
0x1659a0bc1c90  26b0  d2800403       movz x3, #0x20
0x1659a0bc1c94  26b4  4b040063       sub w3, w3, w4
0x1659a0bc1c98  26b8  12001463       and w3, w3, #0x3f
0x1659a0bc1c9c  26bc  9ac32042       lsl x2, x2, x3
0x1659a0bc1ca0  26c0  92407c42       and x2, x2, #0xffffffff
0x1659a0bc1ca4  26c4  14000005       b #+0x14 (addr 0x1659a0bc1cb8)
0x1659a0bc1ca8  26c8  d2800803       movz x3, #0x40
0x1659a0bc1cac  26cc  4b040063       sub w3, w3, w4
0x1659a0bc1cb0  26d0  12001463       and w3, w3, #0x3f
0x1659a0bc1cb4  26d4  9ac32042       lsl x2, x2, x3
0x1659a0bc1cb8  26d8  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc1cbc  26dc  540042c0       b.eq #+0x858 (addr 0x1659a0bc2514)
0x1659a0bc1cc0  26e0  0b190c03       add w3, w0, w25, lsl #3
0x1659a0bc1cc4  26e4  f8236822       str x2, [x1, x3]
0x1659a0bc1cc8  26e8  14000213       b #+0x84c (addr 0x1659a0bc2514)
0x1659a0bc1ccc  26ec  0b180c02       add w2, w0, w24, lsl #3
0x1659a0bc1cd0  26f0  f8626822       ldr x2, [x1, x2]
0x1659a0bc1cd4  26f4  370000b6       tbnz w22, #0, #+0x14 (addr 0x1659a0bc1ce8)
0x1659a0bc1cd8  26f8  39401ae3       ldrb w3, [x23, #6]
0x1659a0bc1cdc  26fc  12001063       and w3, w3, #0x1f
0x1659a0bc1ce0  2700  1ac32c42       ror w2, w2, w3
0x1659a0bc1ce4  2704  14000004       b #+0x10 (addr 0x1659a0bc1cf4)
0x1659a0bc1ce8  2708  39401ae3       ldrb w3, [x23, #6]
0x1659a0bc1cec  270c  12001463       and w3, w3, #0x3f
0x1659a0bc1cf0  2710  9ac32c42       ror x2, x2, x3
0x1659a0bc1cf4  2714  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc1cf8  2718  540040e0       b.eq #+0x81c (addr 0x1659a0bc2514)
0x1659a0bc1cfc  271c  0b190c03       add w3, w0, w25, lsl #3
0x1659a0bc1d00  2720  4b5607e4       neg w4, w22, lsr #1
0x1659a0bc1d04  2724  12001484       and w4, w4, #0x3f
0x1659a0bc1d08  2728  92800005       movn x5, #0x0
0x1659a0bc1d0c  272c  9ac424a4       lsr x4, x5, x4
0x1659a0bc1d10  2730  530836c5       ubfx w5, w22, #8, #6
0x1659a0bc1d14  2734  9ac52084       lsl x4, x4, x5
0x1659a0bc1d18  2738  8a040042       and x2, x2, x4
0x1659a0bc1d1c  273c  f8236822       str x2, [x1, x3]
0x1659a0bc1d20  2740  140001fd       b #+0x7f4 (addr 0x1659a0bc2514)
0x1659a0bc1d24  2744  39401ae2       ldrb w2, [x23, #6]
0x1659a0bc1d28  2748  0b020c02       add w2, w0, w2, lsl #3
0x1659a0bc1d2c  274c  f8626822       ldr x2, [x1, x2]
0x1659a0bc1d30  2750  92407c43       and x3, x2, #0xffffffff
0x1659a0bc1d34  2754  721502df       tst w22, #0x800
0x1659a0bc1d38  2758  9a831043       csel x3, x2, x3, ne
0x1659a0bc1d3c  275c  53027ec4       lsr w4, w22, #2
0x1659a0bc1d40  2760  12001485       and w5, w4, #0x3f
0x1659a0bc1d44  2764  120006c6       and w6, w22, #0x3
0x1659a0bc1d48  2768  710008df       cmp w6, #0x2 (2)
0x1659a0bc1d4c  276c  540000cb       b.lt #+0x18 (addr 0x1659a0bc1d64)
0x1659a0bc1d50  2770  710008df       cmp w6, #0x2 (2)
0x1659a0bc1d54  2774  540001c0       b.eq #+0x38 (addr 0x1659a0bc1d8c)
0x1659a0bc1d58  2778  71000cdf       cmp w6, #0x3 (3)
0x1659a0bc1d5c  277c  540000c0       b.eq #+0x18 (addr 0x1659a0bc1d74)
0x1659a0bc1d60  2780  14000013       b #+0x4c (addr 0x1659a0bc1dac)
0x1659a0bc1d64  2784  34000246       cbz w6, #+0x48 (addr 0x1659a0bc1dac)
0x1659a0bc1d68  2788  710004df       cmp w6, #0x1 (1)
0x1659a0bc1d6c  278c  540001c0       b.eq #+0x38 (addr 0x1659a0bc1da4)
0x1659a0bc1d70  2790  1400000f       b #+0x3c (addr 0x1659a0bc1dac)
0x1659a0bc1d74  2794  37580096       tbnz w22, #11, #+0x10 (addr 0x1659a0bc1d84)
0x1659a0bc1d78  2798  12001083       and w3, w4, #0x1f
0x1659a0bc1d7c  279c  1ac32c42       ror w2, w2, w3
0x1659a0bc1d80  27a0  1400000e       b #+0x38 (addr 0x1659a0bc1db8)
0x1659a0bc1d84  27a4  9ac52c42       ror x2, x2, x5
0x1659a0bc1d88  27a8  1400000d       b #+0x34 (addr 0x1659a0bc1dbc)
0x1659a0bc1d8c  27ac  37580096       tbnz w22, #11, #+0x10 (addr 0x1659a0bc1d9c)
0x1659a0bc1d90  27b0  12001083       and w3, w4, #0x1f
0x1659a0bc1d94  27b4  1ac32842       asr w2, w2, w3
0x1659a0bc1d98  27b8  14000008       b #+0x20 (addr 0x1659a0bc1db8)
0x1659a0bc1d9c  27bc  9ac52842       asr x2, x2, x5
0x1659a0bc1da0  27c0  14000007       b #+0x1c (addr 0x1659a0bc1dbc)
0x1659a0bc1da4  27c4  9ac52462       lsr x2, x3, x5
0x1659a0bc1da8  27c8  14000003       b #+0xc (addr 0x1659a0bc1db4)
0x1659a0bc1dac  27cc  120014a2       and w2, w5, #0x3f
0x1659a0bc1db0  27d0  9ac22062       lsl x2, x3, x2
0x1659a0bc1db4  27d4  37580056       tbnz w22, #11, #+0x8 (addr 0x1659a0bc1dbc)
0x1659a0bc1db8  27d8  92407c42       and x2, x2, #0xffffffff
0x1659a0bc1dbc  27dc  530b2ac3       lsl w3, w22, #21
0x1659a0bc1dc0  27e0  935f7c63       sbfx x3, x3, #31, #1
0x1659a0bc1dc4  27e4  ca030042       eor x2, x2, x3
0x1659a0bc1dc8  27e8  0b180c03       add w3, w0, w24, lsl #3
0x1659a0bc1dcc  27ec  f8636823       ldr x3, [x1, x3]
0x1659a0bc1dd0  27f0  530826c4       ubfx w4, w22, #8, #2
0x1659a0bc1dd4  27f4  51000484       sub w4, w4, #0x1 (1)
0x1659a0bc1dd8  27f8  35000064       cbnz w4, #+0xc (addr 0x1659a0bc1de4)
0x1659a0bc1ddc  27fc  aa020062       orr x2, x3, x2
0x1659a0bc1de0  2800  14000006       b #+0x18 (addr 0x1659a0bc1df8)
0x1659a0bc1de4  2804  7100049f       cmp w4, #0x1 (1)
0x1659a0bc1de8  2808  54000060       b.eq #+0xc (addr 0x1659a0bc1df4)
0x1659a0bc1dec  280c  8a020062       and x2, x3, x2
0x1659a0bc1df0  2810  14000002       b #+0x8 (addr 0x1659a0bc1df8)
0x1659a0bc1df4  2814  ca020062       eor x2, x3, x2
0x1659a0bc1df8  2818  375800f6       tbnz w22, #11, #+0x1c (addr 0x1659a0bc1e14)
0x1659a0bc1dfc  281c  92407c42       and x2, x2, #0xffffffff
0x1659a0bc1e00  2820  121806c3       and w3, w22, #0x300
0x1659a0bc1e04  2824  710c007f       cmp w3, #0x300 (768)
0x1659a0bc1e08  2828  540000c1       b.ne #+0x18 (addr 0x1659a0bc1e20)
0x1659a0bc1e0c  282c  aa1503e3       mov x3, x21
0x1659a0bc1e10  2830  14000008       b #+0x20 (addr 0x1659a0bc1e30)
0x1659a0bc1e14  2834  121806c3       and w3, w22, #0x300
0x1659a0bc1e18  2838  710c007f       cmp w3, #0x300 (768)
0x1659a0bc1e1c  283c  54000080       b.eq #+0x10 (addr 0x1659a0bc1e2c)
0x1659a0bc1e20  2840  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc1e24  2844  54000240       b.eq #+0x48 (addr 0x1659a0bc1e6c)
0x1659a0bc1e28  2848  1400000f       b #+0x3c (addr 0x1659a0bc1e64)
0x1659a0bc1e2c  284c  d28007e3       movz x3, #0x3f
0x1659a0bc1e30  2850  12001463       and w3, w3, #0x3f
0x1659a0bc1e34  2854  9ac32443       lsr x3, x2, x3
0x1659a0bc1e38  2858  d3618063       lsl x3, x3, #31
0x1659a0bc1e3c  285c  92610063       and x3, x3, #0x80000000
0x1659a0bc1e40  2860  d2a80004       movz x4, #0x40000000
0x1659a0bc1e44  2864  f100005f       cmp x2, #0x0 (0)
0x1659a0bc1e48  2868  9a9f0084       csel x4, x4, xzr, eq
0x1659a0bc1e4c  286c  aa040063       orr x3, x3, x4
0x1659a0bc1e50  2870  2a0003e4       mov w4, w0
0x1659a0bc1e54  2874  8b040024       add x4, x1, x4
0x1659a0bc1e58  2878  f9008483       str x3, [x4, #264]
0x1659a0bc1e5c  287c  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc1e60  2880  54000060       b.eq #+0xc (addr 0x1659a0bc1e6c)
0x1659a0bc1e64  2884  0b190c03       add w3, w0, w25, lsl #3
0x1659a0bc1e68  2888  f8236822       str x2, [x1, x3]
0x1659a0bc1e6c  288c  36603556       tbz w22, #12, #+0x6a8 (addr 0x1659a0bc2514)
0x1659a0bc1e70  2890  110021e2       add w2, w15, #0x8 (8)
0x1659a0bc1e74  2894  6b0e005f       cmp w2, w14
0x1659a0bc1e78  2898  540034e0       b.eq #+0x69c (addr 0x1659a0bc2514)
0x1659a0bc1e7c  289c  140001eb       b #+0x7ac (addr 0x1659a0bc2628)
0x1659a0bc1e80  28a0  0b180c02       add w2, w0, w24, lsl #3
0x1659a0bc1e84  28a4  f8626822       ldr x2, [x1, x2]
0x1659a0bc1e88  28a8  0b160de3       add w3, w15, w22, lsl #3
0x1659a0bc1e8c  28ac  f8636823       ldr x3, [x1, x3]
0x1659a0bc1e90  28b0  39401ae4       ldrb w4, [x23, #6]
0x1659a0bc1e94  28b4  12000485       and w5, w4, #0x3
0x1659a0bc1e98  28b8  510004a6       sub w6, w5, #0x1 (1)
0x1659a0bc1e9c  28bc  35000066       cbnz w6, #+0xc (addr 0x1659a0bc1ea8)
0x1659a0bc1ea0  28c0  aa030042       orr x2, x2, x3
0x1659a0bc1ea4  28c4  14000006       b #+0x18 (addr 0x1659a0bc1ebc)
0x1659a0bc1ea8  28c8  710004df       cmp w6, #0x1 (1)
0x1659a0bc1eac  28cc  54000060       b.eq #+0xc (addr 0x1659a0bc1eb8)
0x1659a0bc1eb0  28d0  8a030042       and x2, x2, x3
0x1659a0bc1eb4  28d4  14000002       b #+0x8 (addr 0x1659a0bc1ebc)
0x1659a0bc1eb8  28d8  ca030042       eor x2, x2, x3
0x1659a0bc1ebc  28dc  371000c4       tbnz w4, #2, #+0x18 (addr 0x1659a0bc1ed4)
0x1659a0bc1ec0  28e0  92407c42       and x2, x2, #0xffffffff
0x1659a0bc1ec4  28e4  71000cbf       cmp w5, #0x3 (3)
0x1659a0bc1ec8  28e8  54000261       b.ne #+0x4c (addr 0x1659a0bc1f14)
0x1659a0bc1ecc  28ec  aa1503e3       mov x3, x21
0x1659a0bc1ed0  28f0  14000004       b #+0x10 (addr 0x1659a0bc1ee0)
0x1659a0bc1ed4  28f4  71000cbf       cmp w5, #0x3 (3)
0x1659a0bc1ed8  28f8  540001e1       b.ne #+0x3c (addr 0x1659a0bc1f14)
0x1659a0bc1edc  28fc  d28007e3       movz x3, #0x3f
0x1659a0bc1ee0  2900  12001463       and w3, w3, #0x3f
0x1659a0bc1ee4  2904  9ac32443       lsr x3, x2, x3
0x1659a0bc1ee8  2908  d3618063       lsl x3, x3, #31
0x1659a0bc1eec  290c  92610063       and x3, x3, #0x80000000
0x1659a0bc1ef0  2910  d2a80005       movz x5, #0x40000000
0x1659a0bc1ef4  2914  f100005f       cmp x2, #0x0 (0)
0x1659a0bc1ef8  2918  9a9f00a5       csel x5, x5, xzr, eq
0x1659a0bc1efc  291c  aa050063       orr x3, x3, x5
0x1659a0bc1f00  2920  2a0003e5       mov w5, w0
0x1659a0bc1f04  2924  8b050025       add x5, x1, x5
0x1659a0bc1f08  2928  f90084a3       str x3, [x5, #264]
0x1659a0bc1f0c  292c  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc1f10  2930  54000060       b.eq #+0xc (addr 0x1659a0bc1f1c)
0x1659a0bc1f14  2934  0b190c03       add w3, w0, w25, lsl #3
0x1659a0bc1f18  2938  f8236822       str x2, [x1, x3]
0x1659a0bc1f1c  293c  36182fc4       tbz w4, #3, #+0x5f8 (addr 0x1659a0bc2514)
0x1659a0bc1f20  2940  110021e2       add w2, w15, #0x8 (8)
0x1659a0bc1f24  2944  6b0e005f       cmp w2, w14
0x1659a0bc1f28  2948  54002f60       b.eq #+0x5ec (addr 0x1659a0bc2514)
0x1659a0bc1f2c  294c  140001cd       b #+0x734 (addr 0x1659a0bc2660)
0x1659a0bc1f30  2950  0b190c02       add w2, w0, w25, lsl #3
0x1659a0bc1f34  2954  39401ae3       ldrb w3, [x23, #6]
0x1659a0bc1f38  2958  0b030c03       add w3, w0, w3, lsl #3
0x1659a0bc1f3c  295c  f8636823       ldr x3, [x1, x3]
0x1659a0bc1f40  2960  92407c64       and x4, x3, #0xffffffff
0x1659a0bc1f44  2964  720002df       tst w22, #0x1
0x1659a0bc1f48  2968  9a841063       csel x3, x3, x4, ne
0x1659a0bc1f4c  296c  f8226823       str x3, [x1, x2]
0x1659a0bc1f50  2970  14000171       b #+0x5c4 (addr 0x1659a0bc2514)
0x1659a0bc1f54  2974  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc1f58  2978  54002de0       b.eq #+0x5bc (addr 0x1659a0bc2514)
0x1659a0bc1f5c  297c  0b190c02       add w2, w0, w25, lsl #3
0x1659a0bc1f60  2980  f8626823       ldr x3, [x1, x2]
0x1659a0bc1f64  2984  39401ae4       ldrb w4, [x23, #6]
0x1659a0bc1f68  2988  12001484       and w4, w4, #0x3f
0x1659a0bc1f6c  298c  d29fffe5       movz x5, #0xffff
0x1659a0bc1f70  2990  9ac420a5       lsl x5, x5, x4
0x1659a0bc1f74  2994  8a250063       bic x3, x3, x5
0x1659a0bc1f78  2998  9ac422c4       lsl x4, x22, x4
0x1659a0bc1f7c  299c  aa040063       orr x3, x3, x4
0x1659a0bc1f80  29a0  92407c64       and x4, x3, #0xffffffff
0x1659a0bc1f84  29a4  7200031f       tst w24, #0x1
0x1659a0bc1f88  29a8  9a841063       csel x3, x3, x4, ne
0x1659a0bc1f8c  29ac  f8226823       str x3, [x1, x2]
0x1659a0bc1f90  29b0  14000161       b #+0x584 (addr 0x1659a0bc2514)
0x1659a0bc1f94  29b4  39c01ae2       ldrsb w2, [x23, #6]
0x1659a0bc1f98  29b8  92800003       movn x3, #0x0
0x1659a0bc1f9c  29bc  6b02007f       cmp w3, w2
0x1659a0bc1fa0  29c0  5400008b       b.lt #+0x10 (addr 0x1659a0bc1fb0)
0x1659a0bc1fa4  29c4  0b160de2       add w2, w15, w22, lsl #3
0x1659a0bc1fa8  29c8  f8626822       ldr x2, [x1, x2]
0x1659a0bc1fac  29cc  14000007       b #+0x1c (addr 0x1659a0bc1fc8)
0x1659a0bc1fb0  29d0  93407ec4       sxtw x4, w22
0x1659a0bc1fb4  29d4  7101005f       cmp w2, #0x40 (64)
0x1659a0bc1fb8  29d8  9a963085       csel x5, x4, x22, lo
0x1659a0bc1fbc  29dc  92401c42       and x2, x2, #0xff
0x1659a0bc1fc0  29e0  12001442       and w2, w2, #0x3f
0x1659a0bc1fc4  29e4  9ac22ca2       ror x2, x5, x2
0x1659a0bc1fc8  29e8  0b190c04       add w4, w0, w25, lsl #3
0x1659a0bc1fcc  29ec  f8246822       str x2, [x1, x4]
0x1659a0bc1fd0  29f0  4b0f01c2       sub w2, w14, w15
0x1659a0bc1fd4  29f4  13037c42       asr w2, w2, #3
0x1659a0bc1fd8  29f8  51000442       sub w2, w2, #0x1 (1)
0x1659a0bc1fdc  29fc  6b02031f       cmp w24, w2
0x1659a0bc1fe0  2a00  1a823304       csel w4, w24, w2, lo
0x1659a0bc1fe4  2a04  34000884       cbz w4, #+0x110 (addr 0x1659a0bc20f4)
0x1659a0bc1fe8  2a08  110021e2       add w2, w15, #0x8 (8)
0x1659a0bc1fec  2a0c  aa0403e5       mov x5, x4
0x1659a0bc1ff0  2a10  11001046       add w6, w2, #0x4 (4)
0x1659a0bc1ff4  2a14  38666826       ldrb w6, [x1, x6]
0x1659a0bc1ff8  2a18  b8626827       ldr w7, [x1, x2]
0x1659a0bc1ffc  2a1c  11001848       add w8, w2, #0x6 (6)
0x1659a0bc2000  2a20  38e86828       ldrsb w8, [x1, x8]
0x1659a0bc2004  2a24  6b03011f       cmp w8, w3
0x1659a0bc2008  2a28  5400010d       b.le #+0x20 (addr 0x1659a0bc2028)
0x1659a0bc200c  2a2c  93407cf6       sxtw x22, w7
0x1659a0bc2010  2a30  7101011f       cmp w8, #0x40 (64)
0x1659a0bc2014  2a34  9a8732d7       csel x23, x22, x7, lo
0x1659a0bc2018  2a38  92401d07       and x7, x8, #0xff
0x1659a0bc201c  2a3c  120014e7       and w7, w7, #0x3f
0x1659a0bc2020  2a40  9ac72ee7       ror x7, x23, x7
0x1659a0bc2024  2a44  14000003       b #+0xc (addr 0x1659a0bc2030)
0x1659a0bc2028  2a48  0b070c47       add w7, w2, w7, lsl #3
0x1659a0bc202c  2a4c  f8676827       ldr x7, [x1, x7]
0x1659a0bc2030  2a50  0b060c06       add w6, w0, w6, lsl #3
0x1659a0bc2034  2a54  f8266827       str x7, [x1, x6]
0x1659a0bc2038  2a58  11002046       add w6, w2, #0x8 (8)
0x1659a0bc203c  2a5c  510004a5       sub w5, w5, #0x1 (1)
0x1659a0bc2040  2a60  340005a5       cbz w5, #+0xb4 (addr 0x1659a0bc20f4)
0x1659a0bc2044  2a64  11003042       add w2, w2, #0xc (12)
0x1659a0bc2048  2a68  38626822       ldrb w2, [x1, x2]
0x1659a0bc204c  2a6c  b8666827       ldr w7, [x1, x6]
0x1659a0bc2050  2a70  110018c8       add w8, w6, #0x6 (6)
0x1659a0bc2054  2a74  38e86828       ldrsb w8, [x1, x8]
0x1659a0bc2058  2a78  6b03011f       cmp w8, w3
0x1659a0bc205c  2a7c  5400010d       b.le #+0x20 (addr 0x1659a0bc207c)
0x1659a0bc2060  2a80  93407cf6       sxtw x22, w7
0x1659a0bc2064  2a84  7101011f       cmp w8, #0x40 (64)
0x1659a0bc2068  2a88  9a8732d7       csel x23, x22, x7, lo
0x1659a0bc206c  2a8c  92401d07       and x7, x8, #0xff
0x1659a0bc2070  2a90  120014e7       and w7, w7, #0x3f
0x1659a0bc2074  2a94  9ac72ee7       ror x7, x23, x7
0x1659a0bc2078  2a98  14000003       b #+0xc (addr 0x1659a0bc2084)
0x1659a0bc207c  2a9c  0b070cc7       add w7, w6, w7, lsl #3
0x1659a0bc2080  2aa0  f8676827       ldr x7, [x1, x7]
0x1659a0bc2084  2aa4  0b020c02       add w2, w0, w2, lsl #3
0x1659a0bc2088  2aa8  f8226827       str x7, [x1, x2]
0x1659a0bc208c  2aac  110020c2       add w2, w6, #0x8 (8)
0x1659a0bc2090  2ab0  510004a5       sub w5, w5, #0x1 (1)
0x1659a0bc2094  2ab4  34000305       cbz w5, #+0x60 (addr 0x1659a0bc20f4)
0x1659a0bc2098  2ab8  38531347       ldurb w7, [x26, #-207]
0x1659a0bc209c  2abc  35004ee7       cbnz w7, #+0x9dc (addr 0x1659a0bc2a78)
0x1659a0bc20a0  2ac0  110030c6       add w6, w6, #0xc (12)
0x1659a0bc20a4  2ac4  38666826       ldrb w6, [x1, x6]
0x1659a0bc20a8  2ac8  b8626827       ldr w7, [x1, x2]
0x1659a0bc20ac  2acc  11001848       add w8, w2, #0x6 (6)
0x1659a0bc20b0  2ad0  38e86828       ldrsb w8, [x1, x8]
0x1659a0bc20b4  2ad4  6b03011f       cmp w8, w3
0x1659a0bc20b8  2ad8  5400010d       b.le #+0x20 (addr 0x1659a0bc20d8)
0x1659a0bc20bc  2adc  93407cf6       sxtw x22, w7
0x1659a0bc20c0  2ae0  7101011f       cmp w8, #0x40 (64)
0x1659a0bc20c4  2ae4  9a8732d7       csel x23, x22, x7, lo
0x1659a0bc20c8  2ae8  92401d07       and x7, x8, #0xff
0x1659a0bc20cc  2aec  120014e7       and w7, w7, #0x3f
0x1659a0bc20d0  2af0  9ac72ee7       ror x7, x23, x7
0x1659a0bc20d4  2af4  14000003       b #+0xc (addr 0x1659a0bc20e0)
0x1659a0bc20d8  2af8  0b070c47       add w7, w2, w7, lsl #3
0x1659a0bc20dc  2afc  f8676827       ldr x7, [x1, x7]
0x1659a0bc20e0  2b00  0b060c06       add w6, w0, w6, lsl #3
0x1659a0bc20e4  2b04  f8266827       str x7, [x1, x6]
0x1659a0bc20e8  2b08  11002042       add w2, w2, #0x8 (8)
0x1659a0bc20ec  2b0c  510004a5       sub w5, w5, #0x1 (1)
0x1659a0bc20f0  2b10  35fff805       cbnz w5, #-0x100 (addr 0x1659a0bc1ff0)
0x1659a0bc20f4  2b14  0b040def       add w15, w15, w4, lsl #3
0x1659a0bc20f8  2b18  531e7482       lsl w2, w4, #2
0x1659a0bc20fc  2b1c  8b0201ad       add x13, x13, x2
0x1659a0bc2100  2b20  14000105       b #+0x414 (addr 0x1659a0bc2514)
0x1659a0bc2104  2b24  53037ec2       lsr w2, w22, #3
0x1659a0bc2108  2b28  39401ae3       ldrb w3, [x23, #6]
0x1659a0bc210c  2b2c  0b030c03       add w3, w0, w3, lsl #3
0x1659a0bc2110  2b30  f8636823       ldr x3, [x1, x3]
0x1659a0bc2114  2b34  12000ac4       and w4, w22, #0x7
0x1659a0bc2118  2b38  f1001c9f       cmp x4, #0x7 (7)
0x1659a0bc211c  2b3c  54000262       b.hs #+0x4c (addr 0x1659a0bc2168)
0x1659a0bc2120  2b40  10005910       adr x16, #+0xb20 (addr 0x1659a0bc2c40)
0x1659a0bc2124  2b44  aa0203e2       mov x2, x2
0x1659a0bc2128  2b48  aa0203e2       mov x2, x2
0x1659a0bc212c  2b4c  d2800011       movz x17, #0x0
0x1659a0bc2130  2b50  b8a47a11       ldrsw x17, [x16, x4, lsl #2]
0x1659a0bc2134  2b54  8b110210       add x16, x16, x17
0x1659a0bc2138  2b58  d61f0200       br x16
0x1659a0bc213c  2b5c  93407c63       sxtw x3, w3
0x1659a0bc2140  2b60  1400000a       b #+0x28 (addr 0x1659a0bc2168)
0x1659a0bc2144  2b64  93403c63       sxth x3, w3
0x1659a0bc2148  2b68  14000008       b #+0x20 (addr 0x1659a0bc2168)
0x1659a0bc214c  2b6c  93401c63       sxtb x3, w3
0x1659a0bc2150  2b70  14000006       b #+0x18 (addr 0x1659a0bc2168)
0x1659a0bc2154  2b74  92407c63       and x3, x3, #0xffffffff
0x1659a0bc2158  2b78  14000004       b #+0x10 (addr 0x1659a0bc2168)
0x1659a0bc215c  2b7c  92403c63       and x3, x3, #0xffff
0x1659a0bc2160  2b80  14000002       b #+0x8 (addr 0x1659a0bc2168)
0x1659a0bc2164  2b84  92401c63       and x3, x3, #0xff
0x1659a0bc2168  2b88  12000842       and w2, w2, #0x7
0x1659a0bc216c  2b8c  9ac22062       lsl x2, x3, x2
0x1659a0bc2170  2b90  121602c3       and w3, w22, #0x400
0x1659a0bc2174  2b94  530b2864       lsl w4, w3, #21
0x1659a0bc2178  2b98  935f7c84       sbfx x4, x4, #31, #1
0x1659a0bc217c  2b9c  ca040042       eor x2, x2, x4
0x1659a0bc2180  2ba0  0b180c04       add w4, w0, w24, lsl #3
0x1659a0bc2184  2ba4  f8646824       ldr x4, [x1, x4]
0x1659a0bc2188  2ba8  374002b6       tbnz w22, #8, #+0x54 (addr 0x1659a0bc21dc)
0x1659a0bc218c  2bac  0b040045       add w5, w2, w4
0x1659a0bc2190  2bb0  0b4328a3       add w3, w5, w3, lsr #10
0x1659a0bc2194  2bb4  d2a80006       movz x6, #0x40000000
0x1659a0bc2198  2bb8  6a03007f       tst w3, w3
0x1659a0bc219c  2bbc  9a8613e6       csel x6, xzr, x6, ne
0x1659a0bc21a0  2bc0  12010067       and w7, w3, #0x80000000
0x1659a0bc21a4  2bc4  aa0700c6       orr x6, x6, x7
0x1659a0bc21a8  2bc8  d2a40007       movz x7, #0x20000000
0x1659a0bc21ac  2bcc  6b05007f       cmp w3, w5
0x1659a0bc21b0  2bd0  9a9430e8       csel x8, x7, x20, lo
0x1659a0bc21b4  2bd4  6b0200bf       cmp w5, w2
0x1659a0bc21b8  2bd8  9a8830e5       csel x5, x7, x8, lo
0x1659a0bc21bc  2bdc  aa0500c5       orr x5, x6, x5
0x1659a0bc21c0  2be0  4a040064       eor w4, w3, w4
0x1659a0bc21c4  2be4  4a020062       eor w2, w3, w2
0x1659a0bc21c8  2be8  0a020082       and w2, w4, w2
0x1659a0bc21cc  2bec  53037c42       lsr w2, w2, #3
0x1659a0bc21d0  2bf0  12040042       and w2, w2, #0x10000000
0x1659a0bc21d4  2bf4  aa0200a2       orr x2, x5, x2
0x1659a0bc21d8  2bf8  14000017       b #+0x5c (addr 0x1659a0bc2234)
0x1659a0bc21dc  2bfc  8b040043       add x3, x2, x4
0x1659a0bc21e0  2c00  530a2ac5       ubfx w5, w22, #10, #1
0x1659a0bc21e4  2c04  8b050065       add x5, x3, x5
0x1659a0bc21e8  2c08  d360fca6       lsr x6, x5, #32
0x1659a0bc21ec  2c0c  926100c6       and x6, x6, #0x80000000
0x1659a0bc21f0  2c10  d2a80007       movz x7, #0x40000000
0x1659a0bc21f4  2c14  f10000bf       cmp x5, #0x0 (0)
0x1659a0bc21f8  2c18  9a9f00e7       csel x7, x7, xzr, eq
0x1659a0bc21fc  2c1c  aa0700c6       orr x6, x6, x7
0x1659a0bc2200  2c20  d2a40007       movz x7, #0x20000000
0x1659a0bc2204  2c24  eb0300bf       cmp x5, x3
0x1659a0bc2208  2c28  9a9f30e8       csel x8, x7, xzr, lo
0x1659a0bc220c  2c2c  eb02007f       cmp x3, x2
0x1659a0bc2210  2c30  9a8830e3       csel x3, x7, x8, lo
0x1659a0bc2214  2c34  aa0300c3       orr x3, x6, x3
0x1659a0bc2218  2c38  ca0400a4       eor x4, x5, x4
0x1659a0bc221c  2c3c  ca0200a2       eor x2, x5, x2
0x1659a0bc2220  2c40  8a020082       and x2, x4, x2
0x1659a0bc2224  2c44  d363fc42       lsr x2, x2, #35
0x1659a0bc2228  2c48  92640042       and x2, x2, #0x10000000
0x1659a0bc222c  2c4c  aa020062       orr x2, x3, x2
0x1659a0bc2230  2c50  aa0503e3       mov x3, x5
0x1659a0bc2234  2c54  37480096       tbnz w22, #9, #+0x10 (addr 0x1659a0bc2244)
0x1659a0bc2238  2c58  0b190c02       add w2, w0, w25, lsl #3
0x1659a0bc223c  2c5c  f8226823       str x3, [x1, x2]
0x1659a0bc2240  2c60  140000b5       b #+0x2d4 (addr 0x1659a0bc2514)
0x1659a0bc2244  2c64  2a0003e4       mov w4, w0
0x1659a0bc2248  2c68  8b040024       add x4, x1, x4
0x1659a0bc224c  2c6c  f9008482       str x2, [x4, #264]
0x1659a0bc2250  2c70  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc2254  2c74  54001600       b.eq #+0x2c0 (addr 0x1659a0bc2514)
0x1659a0bc2258  2c78  0b190c02       add w2, w0, w25, lsl #3
0x1659a0bc225c  2c7c  f8226823       str x3, [x1, x2]
0x1659a0bc2260  2c80  140000ad       b #+0x2b4 (addr 0x1659a0bc2514)
0x1659a0bc2264  2c84  39401ae2       ldrb w2, [x23, #6]
0x1659a0bc2268  2c88  0b020c02       add w2, w0, w2, lsl #3
0x1659a0bc226c  2c8c  f8626822       ldr x2, [x1, x2]
0x1659a0bc2270  2c90  92407c43       and x3, x2, #0xffffffff
0x1659a0bc2274  2c94  721802df       tst w22, #0x100
0x1659a0bc2278  2c98  9a831043       csel x3, x2, x3, ne
0x1659a0bc227c  2c9c  53027ec4       lsr w4, w22, #2
0x1659a0bc2280  2ca0  12001485       and w5, w4, #0x3f
0x1659a0bc2284  2ca4  120006c6       and w6, w22, #0x3
0x1659a0bc2288  2ca8  710008df       cmp w6, #0x2 (2)
0x1659a0bc228c  2cac  540000cb       b.lt #+0x18 (addr 0x1659a0bc22a4)
0x1659a0bc2290  2cb0  710008df       cmp w6, #0x2 (2)
0x1659a0bc2294  2cb4  540001c0       b.eq #+0x38 (addr 0x1659a0bc22cc)
0x1659a0bc2298  2cb8  71000cdf       cmp w6, #0x3 (3)
0x1659a0bc229c  2cbc  540000c0       b.eq #+0x18 (addr 0x1659a0bc22b4)
0x1659a0bc22a0  2cc0  14000013       b #+0x4c (addr 0x1659a0bc22ec)
0x1659a0bc22a4  2cc4  34000246       cbz w6, #+0x48 (addr 0x1659a0bc22ec)
0x1659a0bc22a8  2cc8  710004df       cmp w6, #0x1 (1)
0x1659a0bc22ac  2ccc  540001c0       b.eq #+0x38 (addr 0x1659a0bc22e4)
0x1659a0bc22b0  2cd0  1400000f       b #+0x3c (addr 0x1659a0bc22ec)
0x1659a0bc22b4  2cd4  37400096       tbnz w22, #8, #+0x10 (addr 0x1659a0bc22c4)
0x1659a0bc22b8  2cd8  12001083       and w3, w4, #0x1f
0x1659a0bc22bc  2cdc  1ac32c42       ror w2, w2, w3
0x1659a0bc22c0  2ce0  1400000e       b #+0x38 (addr 0x1659a0bc22f8)
0x1659a0bc22c4  2ce4  9ac52c42       ror x2, x2, x5
0x1659a0bc22c8  2ce8  1400000d       b #+0x34 (addr 0x1659a0bc22fc)
0x1659a0bc22cc  2cec  37400096       tbnz w22, #8, #+0x10 (addr 0x1659a0bc22dc)
0x1659a0bc22d0  2cf0  12001083       and w3, w4, #0x1f
0x1659a0bc22d4  2cf4  1ac32842       asr w2, w2, w3
0x1659a0bc22d8  2cf8  14000008       b #+0x20 (addr 0x1659a0bc22f8)
0x1659a0bc22dc  2cfc  9ac52842       asr x2, x2, x5
0x1659a0bc22e0  2d00  14000007       b #+0x1c (addr 0x1659a0bc22fc)
0x1659a0bc22e4  2d04  9ac52462       lsr x2, x3, x5
0x1659a0bc22e8  2d08  14000003       b #+0xc (addr 0x1659a0bc22f4)
0x1659a0bc22ec  2d0c  120014a2       and w2, w5, #0x3f
0x1659a0bc22f0  2d10  9ac22062       lsl x2, x3, x2
0x1659a0bc22f4  2d14  37400056       tbnz w22, #8, #+0x8 (addr 0x1659a0bc22fc)
0x1659a0bc22f8  2d18  92407c42       and x2, x2, #0xffffffff
0x1659a0bc22fc  2d1c  121602c3       and w3, w22, #0x400
0x1659a0bc2300  2d20  530b2864       lsl w4, w3, #21
0x1659a0bc2304  2d24  935f7c84       sbfx x4, x4, #31, #1
0x1659a0bc2308  2d28  ca040042       eor x2, x2, x4
0x1659a0bc230c  2d2c  0b180c04       add w4, w0, w24, lsl #3
0x1659a0bc2310  2d30  f8646824       ldr x4, [x1, x4]
0x1659a0bc2314  2d34  374002b6       tbnz w22, #8, #+0x54 (addr 0x1659a0bc2368)
0x1659a0bc2318  2d38  0b040045       add w5, w2, w4
0x1659a0bc231c  2d3c  0b4328a3       add w3, w5, w3, lsr #10
0x1659a0bc2320  2d40  d2a80006       movz x6, #0x40000000
0x1659a0bc2324  2d44  6a03007f       tst w3, w3
0x1659a0bc2328  2d48  9a8613e6       csel x6, xzr, x6, ne
0x1659a0bc232c  2d4c  12010067       and w7, w3, #0x80000000
0x1659a0bc2330  2d50  aa0700c6       orr x6, x6, x7
0x1659a0bc2334  2d54  d2a40007       movz x7, #0x20000000
0x1659a0bc2338  2d58  6b05007f       cmp w3, w5
0x1659a0bc233c  2d5c  9a9430e8       csel x8, x7, x20, lo
0x1659a0bc2340  2d60  6b0200bf       cmp w5, w2
0x1659a0bc2344  2d64  9a8830e5       csel x5, x7, x8, lo
0x1659a0bc2348  2d68  aa0500c5       orr x5, x6, x5
0x1659a0bc234c  2d6c  4a040064       eor w4, w3, w4
0x1659a0bc2350  2d70  4a020062       eor w2, w3, w2
0x1659a0bc2354  2d74  0a020082       and w2, w4, w2
0x1659a0bc2358  2d78  53037c42       lsr w2, w2, #3
0x1659a0bc235c  2d7c  12040042       and w2, w2, #0x10000000
0x1659a0bc2360  2d80  aa0200a2       orr x2, x5, x2
0x1659a0bc2364  2d84  14000017       b #+0x5c (addr 0x1659a0bc23c0)
0x1659a0bc2368  2d88  8b040043       add x3, x2, x4
0x1659a0bc236c  2d8c  530a2ac5       ubfx w5, w22, #10, #1
0x1659a0bc2370  2d90  8b050065       add x5, x3, x5
0x1659a0bc2374  2d94  d360fca6       lsr x6, x5, #32
0x1659a0bc2378  2d98  926100c6       and x6, x6, #0x80000000
0x1659a0bc237c  2d9c  d2a80007       movz x7, #0x40000000
0x1659a0bc2380  2da0  f10000bf       cmp x5, #0x0 (0)
0x1659a0bc2384  2da4  9a9f00e7       csel x7, x7, xzr, eq
0x1659a0bc2388  2da8  aa0700c6       orr x6, x6, x7
0x1659a0bc238c  2dac  d2a40007       movz x7, #0x20000000
0x1659a0bc2390  2db0  eb0300bf       cmp x5, x3
0x1659a0bc2394  2db4  9a9f30e8       csel x8, x7, xzr, lo
0x1659a0bc2398  2db8  eb02007f       cmp x3, x2
0x1659a0bc239c  2dbc  9a8830e3       csel x3, x7, x8, lo
0x1659a0bc23a0  2dc0  aa0300c3       orr x3, x6, x3
0x1659a0bc23a4  2dc4  ca0400a4       eor x4, x5, x4
0x1659a0bc23a8  2dc8  ca0200a2       eor x2, x5, x2
0x1659a0bc23ac  2dcc  8a020082       and x2, x4, x2
0x1659a0bc23b0  2dd0  d363fc42       lsr x2, x2, #35
0x1659a0bc23b4  2dd4  92640042       and x2, x2, #0x10000000
0x1659a0bc23b8  2dd8  aa020062       orr x2, x3, x2
0x1659a0bc23bc  2ddc  aa0503e3       mov x3, x5
0x1659a0bc23c0  2de0  37480096       tbnz w22, #9, #+0x10 (addr 0x1659a0bc23d0)
0x1659a0bc23c4  2de4  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc23c8  2de8  54000120       b.eq #+0x24 (addr 0x1659a0bc23ec)
0x1659a0bc23cc  2dec  14000006       b #+0x18 (addr 0x1659a0bc23e4)
0x1659a0bc23d0  2df0  2a0003e4       mov w4, w0
0x1659a0bc23d4  2df4  8b040024       add x4, x1, x4
0x1659a0bc23d8  2df8  f9008482       str x2, [x4, #264]
0x1659a0bc23dc  2dfc  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc23e0  2e00  54000060       b.eq #+0xc (addr 0x1659a0bc23ec)
0x1659a0bc23e4  2e04  0b190c02       add w2, w0, w25, lsl #3
0x1659a0bc23e8  2e08  f8226823       str x3, [x1, x2]
0x1659a0bc23ec  2e0c  36580956       tbz w22, #11, #+0x128 (addr 0x1659a0bc2514)
0x1659a0bc23f0  2e10  110021e2       add w2, w15, #0x8 (8)
0x1659a0bc23f4  2e14  6b0e005f       cmp w2, w14
0x1659a0bc23f8  2e18  540008e0       b.eq #+0x11c (addr 0x1659a0bc2514)
0x1659a0bc23fc  2e1c  140000a7       b #+0x29c (addr 0x1659a0bc2698)
0x1659a0bc2400  2e20  39401ae2       ldrb w2, [x23, #6]
0x1659a0bc2404  2e24  53010443       ubfx w3, w2, #1, #1
0x1659a0bc2408  2e28  0b180c04       add w4, w0, w24, lsl #3
0x1659a0bc240c  2e2c  f8646824       ldr x4, [x1, x4]
0x1659a0bc2410  2e30  370002a2       tbnz w2, #0, #+0x54 (addr 0x1659a0bc2464)
0x1659a0bc2414  2e34  0b0402c5       add w5, w22, w4
0x1659a0bc2418  2e38  0b0300a3       add w3, w5, w3
0x1659a0bc241c  2e3c  d2a80006       movz x6, #0x40000000
0x1659a0bc2420  2e40  6a03007f       tst w3, w3
0x1659a0bc2424  2e44  9a8613e6       csel x6, xzr, x6, ne
0x1659a0bc2428  2e48  12010067       and w7, w3, #0x80000000
0x1659a0bc242c  2e4c  aa0700c6       orr x6, x6, x7
0x1659a0bc2430  2e50  d2a40007       movz x7, #0x20000000
0x1659a0bc2434  2e54  6b05007f       cmp w3, w5
0x1659a0bc2438  2e58  9a9430e8       csel x8, x7, x20, lo
0x1659a0bc243c  2e5c  6b1600bf       cmp w5, w22
0x1659a0bc2440  2e60  9a8830e5       csel x5, x7, x8, lo
0x1659a0bc2444  2e64  aa0500c5       orr x5, x6, x5
0x1659a0bc2448  2e68  4a040064       eor w4, w3, w4
0x1659a0bc244c  2e6c  4a160066       eor w6, w3, w22
0x1659a0bc2450  2e70  0a060084       and w4, w4, w6
0x1659a0bc2454  2e74  53037c84       lsr w4, w4, #3
0x1659a0bc2458  2e78  12040084       and w4, w4, #0x10000000
0x1659a0bc245c  2e7c  aa0400a4       orr x4, x5, x4
0x1659a0bc2460  2e80  14000016       b #+0x58 (addr 0x1659a0bc24b8)
0x1659a0bc2464  2e84  93407ec5       sxtw x5, w22
0x1659a0bc2468  2e88  8b050086       add x6, x4, x5
0x1659a0bc246c  2e8c  8b0300c3       add x3, x6, x3
0x1659a0bc2470  2e90  d360fc67       lsr x7, x3, #32
0x1659a0bc2474  2e94  926100e7       and x7, x7, #0x80000000
0x1659a0bc2478  2e98  d2a80008       movz x8, #0x40000000
0x1659a0bc247c  2e9c  f100007f       cmp x3, #0x0 (0)
0x1659a0bc2480  2ea0  9a9f0108       csel x8, x8, xzr, eq
0x1659a0bc2484  2ea4  aa0800e7       orr x7, x7, x8
0x1659a0bc2488  2ea8  d2a40008       movz x8, #0x20000000
0x1659a0bc248c  2eac  eb06007f       cmp x3, x6
0x1659a0bc2490  2eb0  9a9f3116       csel x22, x8, xzr, lo
0x1659a0bc2494  2eb4  eb0400df       cmp x6, x4
0x1659a0bc2498  2eb8  9a963106       csel x6, x8, x22, lo
0x1659a0bc249c  2ebc  aa0600e6       orr x6, x7, x6
0x1659a0bc24a0  2ec0  ca040064       eor x4, x3, x4
0x1659a0bc24a4  2ec4  ca050065       eor x5, x3, x5
0x1659a0bc24a8  2ec8  8a050084       and x4, x4, x5
0x1659a0bc24ac  2ecc  d363fc84       lsr x4, x4, #35
0x1659a0bc24b0  2ed0  92640084       and x4, x4, #0x10000000
0x1659a0bc24b4  2ed4  aa0400c4       orr x4, x6, x4
0x1659a0bc24b8  2ed8  2a0003e5       mov w5, w0
0x1659a0bc24bc  2edc  8b050025       add x5, x1, x5
0x1659a0bc24c0  2ee0  f90084a4       str x4, [x5, #264]
0x1659a0bc24c4  2ee4  71007f3f       cmp w25, #0x1f (31)
0x1659a0bc24c8  2ee8  54000060       b.eq #+0xc (addr 0x1659a0bc24d4)
0x1659a0bc24cc  2eec  0b190c05       add w5, w0, w25, lsl #3
0x1659a0bc24d0  2ef0  f8256823       str x3, [x1, x5]
0x1659a0bc24d4  2ef4  36100202       tbz w2, #2, #+0x40 (addr 0x1659a0bc2514)
0x1659a0bc24d8  2ef8  110021e2       add w2, w15, #0x8 (8)
0x1659a0bc24dc  2efc  6b0e005f       cmp w2, w14
0x1659a0bc24e0  2f00  540001a0       b.eq #+0x34 (addr 0x1659a0bc2514)
0x1659a0bc24e4  2f04  1400007b       b #+0x1ec (addr 0x1659a0bc26d0)
0x1659a0bc24e8  2f08  0b190c02       add w2, w0, w25, lsl #3
0x1659a0bc24ec  2f0c  0b180c03       add w3, w0, w24, lsl #3
0x1659a0bc24f0  2f10  b8636823       ldr w3, [x1, x3]
0x1659a0bc24f4  2f14  0b0302c3       add w3, w22, w3
0x1659a0bc24f8  2f18  f8226823       str x3, [x1, x2]
0x1659a0bc24fc  2f1c  14000006       b #+0x18 (addr 0x1659a0bc2514)
0x1659a0bc2500  2f20  0b190c02       add w2, w0, w25, lsl #3
0x1659a0bc2504  2f24  0b180c03       add w3, w0, w24, lsl #3
0x1659a0bc2508  2f28  f8636823       ldr x3, [x1, x3]
0x1659a0bc250c  2f2c  8b36c063       add x3, x3, w22, sxtw
0x1659a0bc2510  2f30  f8226823       str x3, [x1, x2]
0x1659a0bc2514  2f34  910011ad       add x13, x13, #0x4 (4)
0x1659a0bc2518  2f38  110021ef       add w15, w15, #0x8 (8)
0x1659a0bc251c  2f3c  6b0e01ff       cmp w15, w14
0x1659a0bc2520  2f40  54000ec0       b.eq #+0x1d8 (addr 0x1659a0bc26f8)
0x1659a0bc2524  2f44  17fff46c       b #-0x2e50 (addr 0x1659a0bbf6d4)
0x1659a0bc2528  2f48  0b180c02       add w2, w0, w24, lsl #3
0x1659a0bc252c  2f4c  f8626822       ldr x2, [x1, x2]
0x1659a0bc2530  2f50  910011a3       add x3, x13, #0x4 (4)
0x1659a0bc2534  2f54  2a0003e4       mov w4, w0
0x1659a0bc2538  2f58  8b040024       add x4, x1, x4
0x1659a0bc253c  2f5c  f9007883       str x3, [x4, #240]
0x1659a0bc2540  2f60  aa0203ed       mov x13, x2
0x1659a0bc2544  2f64  1400006d       b #+0x1b4 (addr 0x1659a0bc26f8)
0x1659a0bc2548  2f68  0b180c02       add w2, w0, w24, lsl #3
0x1659a0bc254c  2f6c  f862682d       ldr x13, [x1, x2]
0x1659a0bc2550  2f70  1400006a       b #+0x1a8 (addr 0x1659a0bc26f8)
0x1659a0bc2554  2f74  7100031f       cmp w24, #0x0 (0)
0x1659a0bc2558  2f78  9a9f17e2       cset x2, eq
0x1659a0bc255c  2f7c  0b190c03       add w3, w0, w25, lsl #3
0x1659a0bc2560  2f80  f8636823       ldr x3, [x1, x3]
0x1659a0bc2564  2f84  39401ae4       ldrb w4, [x23, #6]
0x1659a0bc2568  2f88  12001484       and w4, w4, #0x3f
0x1659a0bc256c  2f8c  9ac42463       lsr x3, x3, x4
0x1659a0bc2570  2f90  4a030042       eor w2, w2, w3
0x1659a0bc2574  2f94  37000062       tbnz w2, #0, #+0xc (addr 0x1659a0bc2580)
0x1659a0bc2578  2f98  d2800083       movz x3, #0x4
0x1659a0bc257c  2f9c  14000002       b #+0x8 (addr 0x1659a0bc2584)
0x1659a0bc2580  2fa0  93407ec3       sxtw x3, w22
0x1659a0bc2584  2fa4  8b0d006d       add x13, x3, x13
0x1659a0bc2588  2fa8  1400005c       b #+0x170 (addr 0x1659a0bc26f8)
0x1659a0bc258c  2fac  39401ae2       ldrb w2, [x23, #6]
0x1659a0bc2590  2fb0  721f005f       tst w2, #0x2
0x1659a0bc2594  2fb4  9a9f17e3       cset x3, eq
0x1659a0bc2598  2fb8  0b190c04       add w4, w0, w25, lsl #3
0x1659a0bc259c  2fbc  f8646824       ldr x4, [x1, x4]
0x1659a0bc25a0  2fc0  92407c85       and x5, x4, #0xffffffff
0x1659a0bc25a4  2fc4  7200005f       tst w2, #0x1
0x1659a0bc25a8  2fc8  9a851082       csel x2, x4, x5, ne
0x1659a0bc25ac  2fcc  ea02005f       tst x2, x2
0x1659a0bc25b0  2fd0  9a9f17e2       cset x2, eq
0x1659a0bc25b4  2fd4  6a02005f       tst w2, w2
0x1659a0bc25b8  2fd8  9a9f17e2       cset x2, eq
0x1659a0bc25bc  2fdc  4a020062       eor w2, w3, w2
0x1659a0bc25c0  2fe0  35000062       cbnz w2, #+0xc (addr 0x1659a0bc25cc)
0x1659a0bc25c4  2fe4  d2800083       movz x3, #0x4
0x1659a0bc25c8  2fe8  14000002       b #+0x8 (addr 0x1659a0bc25d0)
0x1659a0bc25cc  2fec  93407ec3       sxtw x3, w22
0x1659a0bc25d0  2ff0  8b0d006d       add x13, x3, x13
0x1659a0bc25d4  2ff4  14000049       b #+0x124 (addr 0x1659a0bc26f8)
0x1659a0bc25d8  2ff8  39401ae2       ldrb w2, [x23, #6]
0x1659a0bc25dc  2ffc  2a022302       orr w2, w24, w2, lsl #8
0x1659a0bc25e0  3000  2a0003e3       mov w3, w0
0x1659a0bc25e4  3004  8b030023       add x3, x1, x3
0x1659a0bc25e8  3008  b9410863       ldr w3, [x3, #264]
0x1659a0bc25ec  300c  531c7c63       lsr w3, w3, #28
0x1659a0bc25f0  3010  1ac32442       lsr w2, w2, w3
0x1659a0bc25f4  3014  37000062       tbnz w2, #0, #+0xc (addr 0x1659a0bc2600)
0x1659a0bc25f8  3018  910011ad       add x13, x13, #0x4 (4)
0x1659a0bc25fc  301c  1400003f       b #+0xfc (addr 0x1659a0bc26f8)
0x1659a0bc2600  3020  8b36c1ad       add x13, x13, w22, sxtw
0x1659a0bc2604  3024  1400003d       b #+0xf4 (addr 0x1659a0bc26f8)
0x1659a0bc2608  3028  910011a2       add x2, x13, #0x4 (4)
0x1659a0bc260c  302c  2a0003e3       mov w3, w0
0x1659a0bc2610  3030  8b030023       add x3, x1, x3
0x1659a0bc2614  3034  f9007862       str x2, [x3, #240]
0x1659a0bc2618  3038  8b36c1ad       add x13, x13, w22, sxtw
0x1659a0bc261c  303c  14000037       b #+0xdc (addr 0x1659a0bc26f8)
0x1659a0bc2620  3040  8b36c1ad       add x13, x13, w22, sxtw
0x1659a0bc2624  3044  14000035       b #+0xd4 (addr 0x1659a0bc26f8)
0x1659a0bc2628  3048  910011a3       add x3, x13, #0x4 (4)
0x1659a0bc262c  304c  7840d2e4       ldurh w4, [x23, #13]
0x1659a0bc2630  3050  2a0003e5       mov w5, w0
0x1659a0bc2634  3054  8b050025       add x5, x1, x5
0x1659a0bc2638  3058  b94108a5       ldr w5, [x5, #264]
0x1659a0bc263c  305c  531c7ca5       lsr w5, w5, #28
0x1659a0bc2640  3060  1ac52484       lsr w4, w4, w5
0x1659a0bc2644  3064  37000064       tbnz w4, #0, #+0xc (addr 0x1659a0bc2650)
0x1659a0bc2648  3068  d2800082       movz x2, #0x4
0x1659a0bc264c  306c  14000003       b #+0xc (addr 0x1659a0bc2658)
0x1659a0bc2650  3070  b8626824       ldr w4, [x1, x2]
0x1659a0bc2654  3074  b8a26822       ldrsw x2, [x1, x2]
0x1659a0bc2658  3078  8b02006d       add x13, x3, x2
0x1659a0bc265c  307c  14000027       b #+0x9c (addr 0x1659a0bc26f8)
0x1659a0bc2660  3080  910011a3       add x3, x13, #0x4 (4)
0x1659a0bc2664  3084  7840d2e4       ldurh w4, [x23, #13]
0x1659a0bc2668  3088  2a0003e5       mov w5, w0
0x1659a0bc266c  308c  8b050025       add x5, x1, x5
0x1659a0bc2670  3090  b94108a5       ldr w5, [x5, #264]
0x1659a0bc2674  3094  531c7ca5       lsr w5, w5, #28
0x1659a0bc2678  3098  1ac52484       lsr w4, w4, w5
0x1659a0bc267c  309c  37000064       tbnz w4, #0, #+0xc (addr 0x1659a0bc2688)
0x1659a0bc2680  30a0  d2800082       movz x2, #0x4
0x1659a0bc2684  30a4  14000003       b #+0xc (addr 0x1659a0bc2690)
0x1659a0bc2688  30a8  b8626824       ldr w4, [x1, x2]
0x1659a0bc268c  30ac  b8a26822       ldrsw x2, [x1, x2]
0x1659a0bc2690  30b0  8b02006d       add x13, x3, x2
0x1659a0bc2694  30b4  14000019       b #+0x64 (addr 0x1659a0bc26f8)
0x1659a0bc2698  30b8  910011a3       add x3, x13, #0x4 (4)
0x1659a0bc269c  30bc  7840d2e4       ldurh w4, [x23, #13]
0x1659a0bc26a0  30c0  2a0003e5       mov w5, w0
0x1659a0bc26a4  30c4  8b050025       add x5, x1, x5
0x1659a0bc26a8  30c8  b94108a5       ldr w5, [x5, #264]
0x1659a0bc26ac  30cc  531c7ca5       lsr w5, w5, #28
0x1659a0bc26b0  30d0  1ac52484       lsr w4, w4, w5
0x1659a0bc26b4  30d4  37000064       tbnz w4, #0, #+0xc (addr 0x1659a0bc26c0)
0x1659a0bc26b8  30d8  d2800082       movz x2, #0x4
0x1659a0bc26bc  30dc  14000003       b #+0xc (addr 0x1659a0bc26c8)
0x1659a0bc26c0  30e0  b8626824       ldr w4, [x1, x2]
0x1659a0bc26c4  30e4  b8a26822       ldrsw x2, [x1, x2]
0x1659a0bc26c8  30e8  8b02006d       add x13, x3, x2
0x1659a0bc26cc  30ec  1400000b       b #+0x2c (addr 0x1659a0bc26f8)
0x1659a0bc26d0  30f0  910011a3       add x3, x13, #0x4 (4)
0x1659a0bc26d4  30f4  7840d2e5       ldurh w5, [x23, #13]
0x1659a0bc26d8  30f8  531c7c84       lsr w4, w4, #28
0x1659a0bc26dc  30fc  1ac424a4       lsr w4, w5, w4
0x1659a0bc26e0  3100  37000064       tbnz w4, #0, #+0xc (addr 0x1659a0bc26ec)
0x1659a0bc26e4  3104  d2800082       movz x2, #0x4
0x1659a0bc26e8  3108  14000003       b #+0xc (addr 0x1659a0bc26f4)
0x1659a0bc26ec  310c  b8626824       ldr w4, [x1, x2]
0x1659a0bc26f0  3110  b8a26822       ldrsw x2, [x1, x2]
0x1659a0bc26f4  3114  8b02006d       add x13, x3, x2
0x1659a0bc26f8  3118  b4000ac9       cbz x9, #+0x158 (addr 0x1659a0bc2850)
0x1659a0bc26fc  311c  924005a2       and x2, x13, #0x3
0x1659a0bc2700  3120  ca0a01a3       eor x3, x13, x10
0x1659a0bc2704  3124  f13ffc7f       cmp x3, #0xfff (4095)
0x1659a0bc2708  3128  54000108       b.hi #+0x20 (addr 0x1659a0bc2728)
0x1659a0bc270c  312c  b50000e2       cbnz x2, #+0x1c (addr 0x1659a0bc2728)
0x1659a0bc2710  3130  927e25a2       and x2, x13, #0xffc
0x1659a0bc2714  3134  9274d583       and x3, x12, #0xfffffffffffff003
0x1659a0bc2718  3138  aa030042       orr x2, x2, x3
0x1659a0bc271c  313c  f9402be3       ldr x3, [sp, #80]
0x1659a0bc2720  3140  f9402fe5       ldr x5, [sp, #88]
0x1659a0bc2724  3144  14000022       b #+0x88 (addr 0x1659a0bc27ac)
0x1659a0bc2728  3148  b5000882       cbnz x2, #+0x110 (addr 0x1659a0bc2838)
0x1659a0bc272c  314c  2a0003e2       mov w2, w0
0x1659a0bc2730  3150  8b020022       add x2, x1, x2
0x1659a0bc2734  3154  394de043       ldrb w3, [x2, #888]
0x1659a0bc2738  3158  36000843       tbz w3, #0, #+0x108 (addr 0x1659a0bc2840)
0x1659a0bc273c  315c  f9402be3       ldr x3, [sp, #80]
0x1659a0bc2740  3160  34000803       cbz w3, #+0x100 (addr 0x1659a0bc2840)
0x1659a0bc2744  3164  53057da4       lsr w4, w13, #5
0x1659a0bc2748  3168  12193484       and w4, w4, #0x1fff80
0x1659a0bc274c  316c  0b040064       add w4, w3, w4
0x1659a0bc2750  3170  f941a042       ldr x2, [x2, #832]
0x1659a0bc2754  3174  d3420842       ubfx x2, x2, #2, #1
0x1659a0bc2758  3178  d2800605       movz x5, #0x30
0x1659a0bc275c  317c  1b051044       madd w4, w2, w5, w4
0x1659a0bc2760  3180  8b040024       add x4, x1, x4
0x1659a0bc2764  3184  f9405085       ldr x5, [x4, #160]
0x1659a0bc2768  3188  b2402da6       orr x6, x13, #0xfff
0x1659a0bc276c  318c  eb0600bf       cmp x5, x6
0x1659a0bc2770  3190  54000681       b.ne #+0xd0 (addr 0x1659a0bc2840)
0x1659a0bc2774  3194  f9405484       ldr x4, [x4, #168]
0x1659a0bc2778  3198  8b0d0084       add x4, x4, x13
0x1659a0bc277c  319c  92ffe005       movn x5, #0xff00000000000000
0x1659a0bc2780  31a0  eb0400bf       cmp x5, x4
0x1659a0bc2784  31a4  540005e3       b.lo #+0xbc (addr 0x1659a0bc2840)
0x1659a0bc2788  31a8  f9402fe5       ldr x5, [sp, #88]
0x1659a0bc278c  31ac  2a0503e6       mov w6, w5
0x1659a0bc2790  31b0  8b060026       add x6, x1, x6
0x1659a0bc2794  31b4  f94018c7       ldr x7, [x6, #48]
0x1659a0bc2798  31b8  b94058c6       ldr w6, [x6, #88]
0x1659a0bc279c  31bc  4b060084       sub w4, w4, w6
0x1659a0bc27a0  31c0  8b0400e4       add x4, x7, x4
0x1659a0bc27a4  31c4  aa040042       orr x2, x2, x4
0x1659a0bc27a8  31c8  b27f0042       orr x2, x2, #0x2
0x1659a0bc27ac  31cc  531e7444       lsl w4, w2, #2
0x1659a0bc27b0  31d0  121c3c84       and w4, w4, #0xffff0
0x1659a0bc27b4  31d4  f94033e6       ldr x6, [sp, #96]
0x1659a0bc27b8  31d8  0b0400c4       add w4, w6, w4
0x1659a0bc27bc  31dc  f8646824       ldr x4, [x1, x4]
0x1659a0bc27c0  31e0  eb02009f       cmp x4, x2
0x1659a0bc27c4  31e4  54000460       b.eq #+0x8c (addr 0x1659a0bc2850)
0x1659a0bc27c8  31e8  53024c44       ubfx w4, w2, #2, #18
0x1659a0bc27cc  31ec  f94037e7       ldr x7, [sp, #104]
0x1659a0bc27d0  31f0  0b0410e4       add w4, w7, w4, lsl #4
0x1659a0bc27d4  31f4  f8646828       ldr x8, [x1, x4]
0x1659a0bc27d8  31f8  eb02011f       cmp x8, x2
0x1659a0bc27dc  31fc  54000361       b.ne #+0x6c (addr 0x1659a0bc2848)
0x1659a0bc27e0  3200  8b040024       add x4, x1, x4
0x1659a0bc27e4  3204  79401888       ldrh w8, [x4, #12]
0x1659a0bc27e8  3208  39403c8f       ldrb w15, [x4, #15]
0x1659a0bc27ec  320c  6b0801ff       cmp w15, w8
0x1659a0bc27f0  3210  54fe7528       b.hi #-0x315c (addr 0x1659a0bbf694)
0x1659a0bc27f4  3214  14000017       b #+0x5c (addr 0x1659a0bc2850)
0x1659a0bc27f8  3218  aa0203ef       mov x15, x2
0x1659a0bc27fc  321c  f9405fe8       ldr x8, [sp, #184]
0x1659a0bc2800  3220  b9002d0e       str w14, [x8, #44]
0x1659a0bc2804  3224  b900290f       str w15, [x8, #40]
0x1659a0bc2808  3228  f900090a       str x10, [x8, #16]
0x1659a0bc280c  322c  f900050c       str x12, [x8, #8]
0x1659a0bc2810  3230  f9404fe7       ldr x7, [sp, #152]
0x1659a0bc2814  3234  f827682d       str x13, [x1, x7]
0x1659a0bc2818  3238  f9401101       ldr x1, [x8, #32]
0x1659a0bc281c  323c  cb090021       sub x1, x1, x9
0x1659a0bc2820  3240  f9000d01       str x1, [x8, #24]
0x1659a0bc2824  3244  d2800020       movz x0, #0x1
0x1659a0bc2828  3248  910003bf       mov sp, fp
0x1659a0bc282c  324c  a8c17bfd       ldp fp, lr, [sp], #16
0x1659a0bc2830  3250  910043ff       add sp, sp, #0x10 (16)
0x1659a0bc2834  3254  d65f03c0       ret
0x1659a0bc2838  3258  d280004b       movz x11, #0x2
0x1659a0bc283c  325c  14000006       b #+0x18 (addr 0x1659a0bc2854)
0x1659a0bc2840  3260  d280004b       movz x11, #0x2
0x1659a0bc2844  3264  14000004       b #+0x10 (addr 0x1659a0bc2854)
0x1659a0bc2848  3268  d280004b       movz x11, #0x2
0x1659a0bc284c  326c  14000002       b #+0x8 (addr 0x1659a0bc2854)
0x1659a0bc2850  3270  d280000b       movz x11, #0x0
0x1659a0bc2854  3274  f9405fe2       ldr x2, [sp, #184]
0x1659a0bc2858  3278  b9002c4e       str w14, [x2, #44]
0x1659a0bc285c  327c  b900284e       str w14, [x2, #40]
0x1659a0bc2860  3280  f900084a       str x10, [x2, #16]
0x1659a0bc2864  3284  f900044c       str x12, [x2, #8]
0x1659a0bc2868  3288  f9404fe3       ldr x3, [sp, #152]
0x1659a0bc286c  328c  f823682d       str x13, [x1, x3]
0x1659a0bc2870  3290  2a0003e3       mov w3, w0
0x1659a0bc2874  3294  8b030021       add x1, x1, x3
0x1659a0bc2878  3298  f900802d       str x13, [x1, #256]
0x1659a0bc287c  329c  f9401041       ldr x1, [x2, #32]
0x1659a0bc2880  32a0  cb090021       sub x1, x1, x9
0x1659a0bc2884  32a4  f9000c41       str x1, [x2, #24]
0x1659a0bc2888  32a8  aa0b03e0       mov x0, x11
0x1659a0bc288c  32ac  17ffffe7       b #-0x64 (addr 0x1659a0bc2828)
0x1659a0bc2890  32b0  f9005be9       str x9, [sp, #176]
0x1659a0bc2894  32b4  f90057e1       str x1, [sp, #168]
0x1659a0bc2898  32b8  f90053e0       str x0, [sp, #160]
0x1659a0bc289c  32bc  f9004bec       str x12, [sp, #144]
0x1659a0bc28a0  32c0  f90047ea       str x10, [sp, #136]
0x1659a0bc28a4  32c4  f90043ee       str x14, [sp, #128]
0x1659a0bc28a8  32c8  f9003fed       str x13, [sp, #120]
0x1659a0bc28ac  32cc  f90013eb       str x11, [sp, #32]
0x1659a0bc28b0  32d0  f9000ff3       str x19, [sp, #24]
0x1659a0bc28b4  32d4  f90023ef       str x15, [sp, #64]
0x1659a0bc28b8  32d8  97fcfad6       bl #-0xc14a8 (addr 0x1659a0b01410)
0x1659a0bc28bc  32dc  f9405be9       ldr x9, [sp, #176]
0x1659a0bc28c0  32e0  f94057e1       ldr x1, [sp, #168]
0x1659a0bc28c4  32e4  f94053e0       ldr x0, [sp, #160]
0x1659a0bc28c8  32e8  f9404bec       ldr x12, [sp, #144]
0x1659a0bc28cc  32ec  f94047ea       ldr x10, [sp, #136]
0x1659a0bc28d0  32f0  f94043ee       ldr x14, [sp, #128]
0x1659a0bc28d4  32f4  f9403fed       ldr x13, [sp, #120]
0x1659a0bc28d8  32f8  d2800014       movz x20, #0x0
0x1659a0bc28dc  32fc  d28003f5       movz x21, #0x1f
0x1659a0bc28e0  3300  f94013eb       ldr x11, [sp, #32]
0x1659a0bc28e4  3304  f9400ff3       ldr x19, [sp, #24]
0x1659a0bc28e8  3308  f94023ef       ldr x15, [sp, #64]
0x1659a0bc28ec  330c  17fff378       b #-0x3220 (addr 0x1659a0bbf6cc)
0x1659a0bc28f0  3310  f9005be9       str x9, [sp, #176]
0x1659a0bc28f4  3314  f90057e1       str x1, [sp, #168]
0x1659a0bc28f8  3318  f90053e0       str x0, [sp, #160]
0x1659a0bc28fc  331c  f9004bec       str x12, [sp, #144]
0x1659a0bc2900  3320  f90047ea       str x10, [sp, #136]
0x1659a0bc2904  3324  f90043ee       str x14, [sp, #128]
0x1659a0bc2908  3328  f90023ef       str x15, [sp, #64]
0x1659a0bc290c  332c  f9003fed       str x13, [sp, #120]
0x1659a0bc2910  3330  f90013eb       str x11, [sp, #32]
0x1659a0bc2914  3334  f9000ff3       str x19, [sp, #24]
0x1659a0bc2918  3338  97fcfabe       bl #-0xc1508 (addr 0x1659a0b01410)
0x1659a0bc291c  333c  f9405be9       ldr x9, [sp, #176]
0x1659a0bc2920  3340  f94057e1       ldr x1, [sp, #168]
0x1659a0bc2924  3344  f94053e0       ldr x0, [sp, #160]
0x1659a0bc2928  3348  f9404bec       ldr x12, [sp, #144]
0x1659a0bc292c  334c  f94047ea       ldr x10, [sp, #136]
0x1659a0bc2930  3350  f94043ee       ldr x14, [sp, #128]
0x1659a0bc2934  3354  f94023ef       ldr x15, [sp, #64]
0x1659a0bc2938  3358  f9403fed       ldr x13, [sp, #120]
0x1659a0bc293c  335c  d2800014       movz x20, #0x0
0x1659a0bc2940  3360  d28003f5       movz x21, #0x1f
0x1659a0bc2944  3364  f94013eb       ldr x11, [sp, #32]
0x1659a0bc2948  3368  f9400ff3       ldr x19, [sp, #24]
0x1659a0bc294c  336c  17fff364       b #-0x3270 (addr 0x1659a0bbf6dc)
0x1659a0bc2950  3370  f9005be9       str x9, [sp, #176]
0x1659a0bc2954  3374  f90057e1       str x1, [sp, #168]
0x1659a0bc2958  3378  f90053e0       str x0, [sp, #160]
0x1659a0bc295c  337c  f9004bec       str x12, [sp, #144]
0x1659a0bc2960  3380  f90047ea       str x10, [sp, #136]
0x1659a0bc2964  3384  f90043ee       str x14, [sp, #128]
0x1659a0bc2968  3388  f90023ef       str x15, [sp, #64]
0x1659a0bc296c  338c  f9003fed       str x13, [sp, #120]
0x1659a0bc2970  3390  f90027f9       str x25, [sp, #72]
0x1659a0bc2974  3394  f90013eb       str x11, [sp, #32]
0x1659a0bc2978  3398  f9000ff3       str x19, [sp, #24]
0x1659a0bc297c  339c  f9001ff7       str x23, [sp, #56]
0x1659a0bc2980  33a0  f9000be2       str x2, [sp, #16]
0x1659a0bc2984  33a4  f90007e4       str x4, [sp, #8]
0x1659a0bc2988  33a8  f90017e6       str x6, [sp, #40]
0x1659a0bc298c  33ac  f90003e7       str x7, [sp]
0x1659a0bc2990  33b0  f9001be5       str x5, [sp, #48]
0x1659a0bc2994  33b4  97fcfa9f       bl #-0xc1584 (addr 0x1659a0b01410)
0x1659a0bc2998  33b8  f9405be9       ldr x9, [sp, #176]
0x1659a0bc299c  33bc  f94057e1       ldr x1, [sp, #168]
0x1659a0bc29a0  33c0  f94053e0       ldr x0, [sp, #160]
0x1659a0bc29a4  33c4  f9404bec       ldr x12, [sp, #144]
0x1659a0bc29a8  33c8  f94047ea       ldr x10, [sp, #136]
0x1659a0bc29ac  33cc  f94043ee       ldr x14, [sp, #128]
0x1659a0bc29b0  33d0  f94023ef       ldr x15, [sp, #64]
0x1659a0bc29b4  33d4  f9403fed       ldr x13, [sp, #120]
0x1659a0bc29b8  33d8  f94027f9       ldr x25, [sp, #72]
0x1659a0bc29bc  33dc  d2800014       movz x20, #0x0
0x1659a0bc29c0  33e0  d28003f5       movz x21, #0x1f
0x1659a0bc29c4  33e4  f94013eb       ldr x11, [sp, #32]
0x1659a0bc29c8  33e8  f9400ff3       ldr x19, [sp, #24]
0x1659a0bc29cc  33ec  f9401ff7       ldr x23, [sp, #56]
0x1659a0bc29d0  33f0  f9400be2       ldr x2, [sp, #16]
0x1659a0bc29d4  33f4  f94007e4       ldr x4, [sp, #8]
0x1659a0bc29d8  33f8  f94017e6       ldr x6, [sp, #40]
0x1659a0bc29dc  33fc  f94003e7       ldr x7, [sp]
0x1659a0bc29e0  3400  f9401be5       ldr x5, [sp, #48]
0x1659a0bc29e4  3404  17fff676       b #-0x2628 (addr 0x1659a0bc03bc)
0x1659a0bc29e8  3408  f9005be9       str x9, [sp, #176]
0x1659a0bc29ec  340c  f90057e1       str x1, [sp, #168]
0x1659a0bc29f0  3410  f90053e0       str x0, [sp, #160]
0x1659a0bc29f4  3414  f9004bec       str x12, [sp, #144]
0x1659a0bc29f8  3418  f90047ea       str x10, [sp, #136]
0x1659a0bc29fc  341c  f90043ee       str x14, [sp, #128]
0x1659a0bc2a00  3420  f90023ef       str x15, [sp, #64]
0x1659a0bc2a04  3424  f9003fed       str x13, [sp, #120]
0x1659a0bc2a08  3428  f90027f9       str x25, [sp, #72]
0x1659a0bc2a0c  342c  f90013eb       str x11, [sp, #32]
0x1659a0bc2a10  3430  f9000ff3       str x19, [sp, #24]
0x1659a0bc2a14  3434  f9001fe4       str x4, [sp, #56]
0x1659a0bc2a18  3438  f9001bf6       str x22, [sp, #48]
0x1659a0bc2a1c  343c  f90017e2       str x2, [sp, #40]
0x1659a0bc2a20  3440  f9000be6       str x6, [sp, #16]
0x1659a0bc2a24  3444  f90007e5       str x5, [sp, #8]
0x1659a0bc2a28  3448  97fcfa7a       bl #-0xc1618 (addr 0x1659a0b01410)
0x1659a0bc2a2c  344c  f9405be9       ldr x9, [sp, #176]
0x1659a0bc2a30  3450  f94057e1       ldr x1, [sp, #168]
0x1659a0bc2a34  3454  f94053e0       ldr x0, [sp, #160]
0x1659a0bc2a38  3458  f9404bec       ldr x12, [sp, #144]
0x1659a0bc2a3c  345c  f94047ea       ldr x10, [sp, #136]
0x1659a0bc2a40  3460  f94043ee       ldr x14, [sp, #128]
0x1659a0bc2a44  3464  f94023ef       ldr x15, [sp, #64]
0x1659a0bc2a48  3468  f9403fed       ldr x13, [sp, #120]
0x1659a0bc2a4c  346c  f94027f9       ldr x25, [sp, #72]
0x1659a0bc2a50  3470  d2800014       movz x20, #0x0
0x1659a0bc2a54  3474  d28003f5       movz x21, #0x1f
0x1659a0bc2a58  3478  f94013eb       ldr x11, [sp, #32]
0x1659a0bc2a5c  347c  f9400ff3       ldr x19, [sp, #24]
0x1659a0bc2a60  3480  f9401fe4       ldr x4, [sp, #56]
0x1659a0bc2a64  3484  f9401bf6       ldr x22, [sp, #48]
0x1659a0bc2a68  3488  f94017e2       ldr x2, [sp, #40]
0x1659a0bc2a6c  348c  f9400be6       ldr x6, [sp, #16]
0x1659a0bc2a70  3490  f94007e5       ldr x5, [sp, #8]
0x1659a0bc2a74  3494  17fff734       b #-0x2330 (addr 0x1659a0bc0744)
0x1659a0bc2a78  3498  f9005be9       str x9, [sp, #176]
0x1659a0bc2a7c  349c  f90057e1       str x1, [sp, #168]
0x1659a0bc2a80  34a0  f90053e0       str x0, [sp, #160]
0x1659a0bc2a84  34a4  f9004bec       str x12, [sp, #144]
0x1659a0bc2a88  34a8  f90047ea       str x10, [sp, #136]
0x1659a0bc2a8c  34ac  f90043ee       str x14, [sp, #128]
0x1659a0bc2a90  34b0  f90023ef       str x15, [sp, #64]
0x1659a0bc2a94  34b4  f9003fed       str x13, [sp, #120]
0x1659a0bc2a98  34b8  f90027e4       str x4, [sp, #72]
0x1659a0bc2a9c  34bc  f9001fe5       str x5, [sp, #56]
0x1659a0bc2aa0  34c0  f9001be2       str x2, [sp, #48]
0x1659a0bc2aa4  34c4  f90017e6       str x6, [sp, #40]
0x1659a0bc2aa8  34c8  f90013eb       str x11, [sp, #32]
0x1659a0bc2aac  34cc  f9000ff3       str x19, [sp, #24]
0x1659a0bc2ab0  34d0  97fcfa58       bl #-0xc16a0 (addr 0x1659a0b01410)
0x1659a0bc2ab4  34d4  f9405be9       ldr x9, [sp, #176]
0x1659a0bc2ab8  34d8  f94057e1       ldr x1, [sp, #168]
0x1659a0bc2abc  34dc  f94053e0       ldr x0, [sp, #160]
0x1659a0bc2ac0  34e0  f9404bec       ldr x12, [sp, #144]
0x1659a0bc2ac4  34e4  f94047ea       ldr x10, [sp, #136]
0x1659a0bc2ac8  34e8  f94043ee       ldr x14, [sp, #128]
0x1659a0bc2acc  34ec  f94023ef       ldr x15, [sp, #64]
0x1659a0bc2ad0  34f0  f9403fed       ldr x13, [sp, #120]
0x1659a0bc2ad4  34f4  d2800014       movz x20, #0x0
0x1659a0bc2ad8  34f8  f94027e4       ldr x4, [sp, #72]
0x1659a0bc2adc  34fc  f9401fe5       ldr x5, [sp, #56]
0x1659a0bc2ae0  3500  f9401be2       ldr x2, [sp, #48]
0x1659a0bc2ae4  3504  92800003       movn x3, #0x0
0x1659a0bc2ae8  3508  f94017e6       ldr x6, [sp, #40]
0x1659a0bc2aec  350c  d28003f5       movz x21, #0x1f
0x1659a0bc2af0  3510  f94013eb       ldr x11, [sp, #32]
0x1659a0bc2af4  3514  f9400ff3       ldr x19, [sp, #24]
0x1659a0bc2af8  3518  17fffd6a       b #-0xa58 (addr 0x1659a0bc20a0)
0x1659a0bc2afc  351c  97fcf989       bl #-0xc19dc (addr 0x1659a0b01120)
0x1659a0bc2b00  3520  97fcf988       bl #-0xc19e0 (addr 0x1659a0b01120)
0x1659a0bc2b04  3524  97fcf987       bl #-0xc19e4 (addr 0x1659a0b01120)
0x1659a0bc2b08  3528  97fcf986       bl #-0xc19e8 (addr 0x1659a0b01120)
0x1659a0bc2b0c  352c  97fcf985       bl #-0xc19ec (addr 0x1659a0b01120)
0x1659a0bc2b10  3530  97fcf984       bl #-0xc19f0 (addr 0x1659a0b01120)
0x1659a0bc2b14  3534  97fcf983       bl #-0xc19f4 (addr 0x1659a0b01120)
0x1659a0bc2b18  3538  97fcf982       bl #-0xc19f8 (addr 0x1659a0b01120)
0x1659a0bc2b1c  353c  97fcf981       bl #-0xc19fc (addr 0x1659a0b01120)
0x1659a0bc2b20  3540  97fcf980       bl #-0xc1a00 (addr 0x1659a0b01120)
0x1659a0bc2b24  3544  97fcf97f       bl #-0xc1a04 (addr 0x1659a0b01120)
0x1659a0bc2b28  3548  97fcf97e       bl #-0xc1a08 (addr 0x1659a0b01120)
0x1659a0bc2b2c  354c  97fcf97d       bl #-0xc1a0c (addr 0x1659a0b01120)
0x1659a0bc2b30  3550  97fcf97c       bl #-0xc1a10 (addr 0x1659a0b01120)
0x1659a0bc2b34  3554  97fcf97b       bl #-0xc1a14 (addr 0x1659a0b01120)
0x1659a0bc2b38  3558  97fcf97a       bl #-0xc1a18 (addr 0x1659a0b01120)
0x1659a0bc2b3c  355c  97fcf979       bl #-0xc1a1c (addr 0x1659a0b01120)
0x1659a0bc2b40  3560  97fcf978       bl #-0xc1a20 (addr 0x1659a0b01120)
0x1659a0bc2b44  3564  97fcf977       bl #-0xc1a24 (addr 0x1659a0b01120)
0x1659a0bc2b48  3568  97fcf976       bl #-0xc1a28 (addr 0x1659a0b01120)
0x1659a0bc2b4c  356c  97fcf975       bl #-0xc1a2c (addr 0x1659a0b01120)
0x1659a0bc2b50  3570  97fcf974       bl #-0xc1a30 (addr 0x1659a0b01120)
0x1659a0bc2b54  3574  97fcf973       bl #-0xc1a34 (addr 0x1659a0b01120)
0x1659a0bc2b58  3578  97fcf972       bl #-0xc1a38 (addr 0x1659a0b01120)
0x1659a0bc2b5c  357c  97fcf971       bl #-0xc1a3c (addr 0x1659a0b01120)
0x1659a0bc2b60  3580  97fcf970       bl #-0xc1a40 (addr 0x1659a0b01120)
0x1659a0bc2b64  3584  97fcf96f       bl #-0xc1a44 (addr 0x1659a0b01120)
0x1659a0bc2b68  3588  97fcf96e       bl #-0xc1a48 (addr 0x1659a0b01120)
0x1659a0bc2b6c  358c  97fcf96d       bl #-0xc1a4c (addr 0x1659a0b01120)
0x1659a0bc2b70  3590  97fcf96c       bl #-0xc1a50 (addr 0x1659a0b01120)
0x1659a0bc2b74  3594  97fcf96b       bl #-0xc1a54 (addr 0x1659a0b01120)
0x1659a0bc2b78  3598  97fcf96a       bl #-0xc1a58 (addr 0x1659a0b01120)
0x1659a0bc2b7c  359c  97fcf969       bl #-0xc1a5c (addr 0x1659a0b01120)
0x1659a0bc2b80  35a0  97fcf968       bl #-0xc1a60 (addr 0x1659a0b01120)
0x1659a0bc2b84  35a4  97fcf967       bl #-0xc1a64 (addr 0x1659a0b01120)
0x1659a0bc2b88  35a8  97fcf966       bl #-0xc1a68 (addr 0x1659a0b01120)
0x1659a0bc2b8c  35ac  97fcf965       bl #-0xc1a6c (addr 0x1659a0b01120)
0x1659a0bc2b90  35b0  97fcf964       bl #-0xc1a70 (addr 0x1659a0b01120)
0x1659a0bc2b94  35b4  97fcf963       bl #-0xc1a74 (addr 0x1659a0b01120)
0x1659a0bc2b98  35b8  97fcf962       bl #-0xc1a78 (addr 0x1659a0b01120)
0x1659a0bc2b9c  35bc  97fcf961       bl #-0xc1a7c (addr 0x1659a0b01120)
0x1659a0bc2ba0  35c0  97fcf960       bl #-0xc1a80 (addr 0x1659a0b01120)
0x1659a0bc2ba4  35c4  97fcf95f       bl #-0xc1a84 (addr 0x1659a0b01120)
0x1659a0bc2ba8  35c8  97fcf95e       bl #-0xc1a88 (addr 0x1659a0b01120)
0x1659a0bc2bac  35cc  97fcf95d       bl #-0xc1a8c (addr 0x1659a0b01120)
0x1659a0bc2bb0  35d0  97fcf95c       bl #-0xc1a90 (addr 0x1659a0b01120)
0x1659a0bc2bb4  35d4  97fcf95b       bl #-0xc1a94 (addr 0x1659a0b01120)
0x1659a0bc2bb8  35d8  97fcf95a       bl #-0xc1a98 (addr 0x1659a0b01120)
0x1659a0bc2bbc  35dc  97fcf959       bl #-0xc1a9c (addr 0x1659a0b01120)
0x1659a0bc2bc0  35e0  97fcf958       bl #-0xc1aa0 (addr 0x1659a0b01120)
0x1659a0bc2bc4  35e4  97fcf957       bl #-0xc1aa4 (addr 0x1659a0b01120)
0x1659a0bc2bc8  35e8  97fcf956       bl #-0xc1aa8 (addr 0x1659a0b01120)
0x1659a0bc2bcc  35ec  97fcf955       bl #-0xc1aac (addr 0x1659a0b01120)
0x1659a0bc2bd0  35f0  97fcf954       bl #-0xc1ab0 (addr 0x1659a0b01120)
0x1659a0bc2bd4  35f4  97fcf953       bl #-0xc1ab4 (addr 0x1659a0b01120)
0x1659a0bc2bd8  35f8  97fcf952       bl #-0xc1ab8 (addr 0x1659a0b01120)
0x1659a0bc2bdc  35fc  97fcf951       bl #-0xc1abc (addr 0x1659a0b01120)
0x1659a0bc2be0  3600  97fcf950       bl #-0xc1ac0 (addr 0x1659a0b01120)
0x1659a0bc2be4  3604  97fcf94f       bl #-0xc1ac4 (addr 0x1659a0b01120)
0x1659a0bc2be8  3608  97fcf94e       bl #-0xc1ac8 (addr 0x1659a0b01120)
0x1659a0bc2bec  360c  97fcf94d       bl #-0xc1acc (addr 0x1659a0b01120)
0x1659a0bc2bf0  3610  97fcf94c       bl #-0xc1ad0 (addr 0x1659a0b01120)
0x1659a0bc2bf4  3614  97fcf94b       bl #-0xc1ad4 (addr 0x1659a0b01120)
0x1659a0bc2bf8  3618  97fcf94a       bl #-0xc1ad8 (addr 0x1659a0b01120)
0x1659a0bc2bfc  361c  97fcf949       bl #-0xc1adc (addr 0x1659a0b01120)
0x1659a0bc2c00  3620  97fcf948       bl #-0xc1ae0 (addr 0x1659a0b01120)
0x1659a0bc2c04  3624  97fcf947       bl #-0xc1ae4 (addr 0x1659a0b01120)
0x1659a0bc2c08  3628  97fcf946       bl #-0xc1ae8 (addr 0x1659a0b01120)
0x1659a0bc2c0c  362c  97fcf945       bl #-0xc1aec (addr 0x1659a0b01120)
0x1659a0bc2c10  3630  97fcf944       bl #-0xc1af0 (addr 0x1659a0b01120)
0x1659a0bc2c14  3634  97fcf943       bl #-0xc1af4 (addr 0x1659a0b01120)
0x1659a0bc2c18  3638  97fcf942       bl #-0xc1af8 (addr 0x1659a0b01120)
0x1659a0bc2c1c  363c  97fcf941       bl #-0xc1afc (addr 0x1659a0b01120)
0x1659a0bc2c20  3640  97fcf940       bl #-0xc1b00 (addr 0x1659a0b01120)
0x1659a0bc2c24  3644  97fcf93f       bl #-0xc1b04 (addr 0x1659a0b01120)
0x1659a0bc2c28  3648  97fcf93e       bl #-0xc1b08 (addr 0x1659a0b01120)
0x1659a0bc2c2c  364c  97fcf93d       bl #-0xc1b0c (addr 0x1659a0b01120)
0x1659a0bc2c30  3650  97fcf93c       bl #-0xc1b10 (addr 0x1659a0b01120)
0x1659a0bc2c34  3654  97fcf943       bl #-0xc1af4 (addr 0x1659a0b01140)
0x1659a0bc2c38  3658  97fcf942       bl #-0xc1af8 (addr 0x1659a0b01140)
0x1659a0bc2c3c  365c  d503201f       nop
0x1659a0bc2c40  3660  jump table entry 00002b84
0x1659a0bc2c44  3664  jump table entry 00002b7c
0x1659a0bc2c48  3668  jump table entry 00002b74
0x1659a0bc2c4c  366c  jump table entry 00002b88
0x1659a0bc2c50  3670  jump table entry 00002b6c
0x1659a0bc2c54  3674  jump table entry 00002b64
0x1659a0bc2c58  3678  jump table entry 00002b5c
0x1659a0bc2c5c  367c  jump table entry 000020f0
0x1659a0bc2c60  3680  jump table entry 000020e8
0x1659a0bc2c64  3684  jump table entry 000020e0
0x1659a0bc2c68  3688  jump table entry 000020f4
0x1659a0bc2c6c  368c  jump table entry 000020d8
0x1659a0bc2c70  3690  jump table entry 000020d0
0x1659a0bc2c74  3694  jump table entry 000020c8
0x1659a0bc2c78  3698  jump table entry 000011d8
0x1659a0bc2c7c  369c  jump table entry 000011d0
0x1659a0bc2c80  36a0  jump table entry 000011c8
0x1659a0bc2c84  36a4  jump table entry 000011c0
0x1659a0bc2c88  36a8  jump table entry 000011b4
0x1659a0bc2c8c  36ac  jump table entry 000011a8
0x1659a0bc2c90  36b0  jump table entry 0000119c
0x1659a0bc2c94  36b4  jump table entry 00001190
0x1659a0bc2c98  36b8  jump table entry 00001144
0x1659a0bc2c9c  36bc  jump table entry 0000113c
0x1659a0bc2ca0  36c0  jump table entry 00001134
0x1659a0bc2ca4  36c4  jump table entry 0000112c
0x1659a0bc2ca8  36c8  jump table entry 00001120
0x1659a0bc2cac  36cc  jump table entry 00001114
0x1659a0bc2cb0  36d0  jump table entry 00001108
0x1659a0bc2cb4  36d4  jump table entry 000010fc
0x1659a0bc2cb8  36d8  jump table entry 000010b8
0x1659a0bc2cbc  36dc  jump table entry 000010b0
0x1659a0bc2cc0  36e0  jump table entry 000010a8
0x1659a0bc2cc4  36e4  jump table entry 000010a0
0x1659a0bc2cc8  36e8  jump table entry 00001094
0x1659a0bc2ccc  36ec  jump table entry 00001088
0x1659a0bc2cd0  36f0  jump table entry 0000107c
0x1659a0bc2cd4  36f4  jump table entry 00001070
0x1659a0bc2cd8  36f8  jump table entry 0000102c
0x1659a0bc2cdc  36fc  jump table entry 00001024
0x1659a0bc2ce0  3700  jump table entry 0000101c
0x1659a0bc2ce4  3704  jump table entry 00001014
0x1659a0bc2ce8  3708  jump table entry 00001008
0x1659a0bc2cec  370c  jump table entry 00000ffc
0x1659a0bc2cf0  3710  jump table entry 00000ff0
0x1659a0bc2cf4  3714  jump table entry 00000fe4
0x1659a0bc2cf8  3718  jump table entry 00001264
0x1659a0bc2cfc  371c  jump table entry 00001240
0x1659a0bc2d00  3720  jump table entry 00001224
0x1659a0bc2d04  3724  jump table entry 00001208
0x1659a0bc2d08  3728  jump table entry 00000f94
0x1659a0bc2d0c  372c  jump table entry 00000f94
0x1659a0bc2d10  3730  jump table entry 00000f94
0x1659a0bc2d14  3734  jump table entry 00000f94
0x1659a0bc2d18  3738  jump table entry 00000f78
0x1659a0bc2d1c  373c  jump table entry 00000e5c
0x1659a0bc2d20  3740  jump table entry 00000e54
0x1659a0bc2d24  3744  jump table entry 00000e4c
0x1659a0bc2d28  3748  jump table entry 00000e44
0x1659a0bc2d2c  374c  jump table entry 00000e34
0x1659a0bc2d30  3750  jump table entry 00000e24
0x1659a0bc2d34  3754  jump table entry 00000e18
0x1659a0bc2d38  3758  jump table entry 00000e0c
0x1659a0bc2d3c  375c  jump table entry 00000dbc
0x1659a0bc2d40  3760  jump table entry 00000db4
0x1659a0bc2d44  3764  jump table entry 00000dac
0x1659a0bc2d48  3768  jump table entry 00000da4
0x1659a0bc2d4c  376c  jump table entry 00000d94
0x1659a0bc2d50  3770  jump table entry 00000d84
0x1659a0bc2d54  3774  jump table entry 00000d78
0x1659a0bc2d58  3778  jump table entry 00000d6c
0x1659a0bc2d5c  377c  jump table entry 00000d24
0x1659a0bc2d60  3780  jump table entry 00000d1c
0x1659a0bc2d64  3784  jump table entry 00000d14
0x1659a0bc2d68  3788  jump table entry 00000d0c
0x1659a0bc2d6c  378c  jump table entry 00000cfc
0x1659a0bc2d70  3790  jump table entry 00000cec
0x1659a0bc2d74  3794  jump table entry 00000ce0
0x1659a0bc2d78  3798  jump table entry 00000cd4
0x1659a0bc2d7c  379c  jump table entry 00000eec
0x1659a0bc2d80  37a0  jump table entry 00000ec4
0x1659a0bc2d84  37a4  jump table entry 00000ea4
0x1659a0bc2d88  37a8  jump table entry 00000e84
0x1659a0bc2d8c  37ac  jump table entry 00000c78
0x1659a0bc2d90  37b0  jump table entry 00000c78
0x1659a0bc2d94  37b4  jump table entry 00000c78
0x1659a0bc2d98  37b8  jump table entry 00000c78
0x1659a0bc2d9c  37bc  jump table entry 00000c58
0x1659a0bc2da0  37c0  jump table entry 00000284
0x1659a0bc2da4  37c4  jump table entry 000002a4
0x1659a0bc2da8  37c8  jump table entry 00000270
0x1659a0bc2dac  37cc  jump table entry 00000260
0x1659a0bc2db0  37d0  jump table entry 00000240
0x1659a0bc2db4  37d4  jump table entry 0000321c
0x1659a0bc2db8  37d8  jump table entry 00002f34
0x1659a0bc2dbc  37dc  jump table entry 00002f20
0x1659a0bc2dc0  37e0  jump table entry 00002f08
0x1659a0bc2dc4  37e4  jump table entry 00002e20
0x1659a0bc2dc8  37e8  jump table entry 00002c84
0x1659a0bc2dcc  37ec  jump table entry 00002b24
0x1659a0bc2dd0  37f0  jump table entry 000029b4
0x1659a0bc2dd4  37f4  jump table entry 00002974
0x1659a0bc2dd8  37f8  jump table entry 00002950
0x1659a0bc2ddc  37fc  jump table entry 000028a0
0x1659a0bc2de0  3800  jump table entry 00002744
0x1659a0bc2de4  3804  jump table entry 000026ec
0x1659a0bc2de8  3808  jump table entry 0000265c
0x1659a0bc2dec  380c  jump table entry 00002594
0x1659a0bc2df0  3810  jump table entry 000024fc
0x1659a0bc2df4  3814  jump table entry 000023f4
0x1659a0bc2df8  3818  jump table entry 00002390
0x1659a0bc2dfc  381c  jump table entry 00002378
0x1659a0bc2e00  3820  jump table entry 00002358
0x1659a0bc2e04  3824  jump table entry 00003040
0x1659a0bc2e08  3828  jump table entry 00003028
0x1659a0bc2e0c  382c  jump table entry 00002ff8
0x1659a0bc2e10  3830  jump table entry 00002fac
0x1659a0bc2e14  3834  jump table entry 00002f74
0x1659a0bc2e18  3838  jump table entry 00002f68
0x1659a0bc2e1c  383c  jump table entry 00002f48
0x1659a0bc2e20  3840  jump table entry 00002044
0x1659a0bc2e24  3844  jump table entry 00002044
0x1659a0bc2e28  3848  jump table entry 00001da0
0x1659a0bc2e2c  384c  jump table entry 00001da0
0x1659a0bc2e30  3850  jump table entry 00001a88
0x1659a0bc2e34  3854  jump table entry 00001a88
0x1659a0bc2e38  3858  jump table entry 00001a24
0x1659a0bc2e3c  385c  jump table entry 000019bc
0x1659a0bc2e40  3860  jump table entry 000017c0
0x1659a0bc2e44  3864  jump table entry 00001290
0x1659a0bc2e48  3868  jump table entry 00000bd0
0x1659a0bc2e4c  386c  jump table entry 00000aa8
0x1659a0bc2e50  3870  jump table entry 00000874
0x1659a0bc2e54  3874  jump table entry 0000086c
0x1659a0bc2e58  3878  jump table entry 0000074c
0x1659a0bc2e5c  387c  jump table entry 000005ec
0x1659a0bc2e60  3880  jump table entry 000004f4
0x1659a0bc2e64  3884  jump table entry 0000041c
0x1659a0bc2e68  3888  jump table entry 0000037c
0x1659a0bc2e6c  388c  jump table entry 000002b8
0x1659a0bc2e70  3890  jump table entry 0000321c
0x1659a0bc2e74  3894  jump table entry 000001f4
0x1659a0bc2e78  3898  jump table entry 00000134

Protected instructions:
 pc offset
        24         
        28         
        5c         
        74         
        90         
        94         
        98         
        9c         
        a0         
        b8         
        bc         
        c8         
        fc         
       104         
       108         
       10c         
       134         
       14c         
       180         
       188         
       198         
       1b0         
       1c0         
       1c8         
       1ec         
       218         
       248         
       258         
       268         
       278         
       2a0         
       2b0         
       2c0         
       30c         
       310         
       354         
       374         
       380         
       3a4         
       3ac         
       414         
       420         
       424         
       42c         
       4ec         
       4f4         
       4fc         
       514         
       51c         
       5d4         
       5e4         
       5f0         
       630         
       648         
       670         
       680         
       69c         
       6ec         
       708         
       724         
       734         
       744         
       754         
       760         
       770         
       784         
       794         
       7bc         
       7d4         
       7ec         
       804         
       81c         
       834         
       84c         
       864         
       878         
       8ac         
       8b0         
       8c8         
       8d4         
       8d8         
       8ec         
       908         
       920         
       934         
       980         
       9a8         
       9d0         
       9ec         
       9f8         
       9fc         
       a10         
       a58         
       a74         
       a90         
       aa0         
       aac         
       ae8         
       b04         
       b54         
       b70         
       b8c         
       b9c         
       bac         
       bb0         
       bb4         
       bb8         
       bc8         
       bd4         
       c00         
       c14         
       c24         
       c2c         
       c6c         
       c98         
       d30         
       dc8         
       e68         
       e98         
       eb8         
       ee0         
       f00         
       f20         
       f34         
       f44         
       f4c         
       f8c         
       fac         
      1038         
      10c4         
      1150         
      11e4         
      121c         
      1238         
      125c         
      1278         
      1288         
      1298         
      12bc         
      12d0         
      12ec         
      1324         
      1374         
      138c         
      139c         
      13f4         
      1410         
      142c         
      143c         
      1454         
      1468         
      1488         
      1494         
      14e8         
      1500         
      1518         
      1524         
      153c         
      1550         
      156c         
      15c8         
      15e4         
      1600         
      1610         
      1670         
      1688         
      16a0         
      16ac         
      16e8         
      1710         
      1728         
      172c         
      174c         
      1774         
      1794         
      179c         
      17a4         
      17ac         
      17b8         
      17c4         
      19b4         
      19c4         
      19c8         
      19d0         
      1a1c         
      1a28         
      1a40         
      1a4c         
      1a50         
      1a80         
      1a8c         
      1ad0         
      1af8         
      1b08         
      1b1c         
      1b24         
      1b68         
      1b84         
      1ba0         
      1bb0         
      1bf8         
      1c10         
      1c28         
      1c34         
      1c7c         
      1c98         
      1cb4         
      1cc4         
      1d0c         
      1d24         
      1d3c         
      1d48         
      1d64         
      1d7c         
      1d90         
      1d98         
      1da4         
      1de4         
      1e04         
      1e2c         
      1e48         
      1e58         
      1e74         
      1e90         
      1ea4         
      1ec0         
      1edc         
      1ef4         
      1efc         
      1f00         
      1f14         
      1f34         
      1f40         
      1f60         
      1f88         
      1fa4         
      1fb4         
      1fcc         
      1fe8         
      1ffc         
      2018         
      2038         
      2048         
      2094         
      209c         
      2154         
      2174         
      21c4         
      21e0         
      21fc         
      220c         
      2270         
      228c         
      22a8         
      22bc         
      2300         
      231c         
      2338         
      2348         
      2350         
      2370         
      2388         
      23a0         
      23b8         
      23c0         
      23c8         
      23ec         
      2400         
      2418         
      2420         
      242c         
      2444         
      2498         
      24f4         
      2508         
      2518         
      2520         
      2570         
      258c         
      2598         
      25a8         
      25b0         
      2654         
      2660         
      2668         
      26e4         
      26f0         
      26f8         
      2708         
      273c         
      2744         
      274c         
      27ec         
      2878         
      2888         
      28a4         
      28ac         
      28b0         
      2928         
      2938         
      2954         
      295c         
      296c         
      2980         
      2984         
      29ac         
      29b4         
      29c8         
      29ec         
      2a14         
      2a18         
      2a20         
      2a4c         
      2a54         
      2a68         
      2a6c         
      2a74         
      2aa0         
      2aa8         
      2ac4         
      2ac8         
      2ad0         
      2afc         
      2b04         
      2b28         
      2b30         
      2ba4         
      2c5c         
      2c6c         
      2c7c         
      2c84         
      2c8c         
      2d30         
      2df8         
      2e08         
      2e20         
      2e2c         
      2ee0         
      2ef0         
      2f10         
      2f18         
      2f28         
      2f30         
      2f4c         
      2f5c         
      2f6c         
      2f80         
      2f84         
      2fac         
      2fbc         
      2ff8         
      3008         
      3034         
      304c         
      3058         
      3070         
      3084         
      3090         
      30a8         
      30bc         
      30c8         
      30e0         
      30f4         
      310c         
      3154         
      3170         
      3184         
      3194         
      31b4         
      31b8         
      31dc         
      31f4         
      3204         
      3208         
      3220         
      3224         
      3228         
      322c         
      3234         
      3238         
      3240         
      3278         
      327c         
      3280         
      3284         
      328c         
      3298         
      329c         
      32a4         

Source positions:
 pc offset  position
        24        23
        28        30
        5c        48
        74        64
        90        94
        94       101
        98       108
        9c       115
        a0       122
        b8     11443
        bc     11450
        c8     11461
        fc       150
       104       157
       108       164
       10c       455
       134      8393
       14c      8427
       180      8464
       188      8472
       198      8526
       1b0      8556
       1c0      8498
       1c8      8512
       1ec      8490
       218      4216
       248      8305
       258      8318
       268      8361
       278      8347
       2a0      8337
       2b0      8385
       2c0      8068
       30c      8167
       310      8174
       354      8243
       374      8268
       380      4025
       3a4      4056
       3ac      4063
       414      4182
       420      3859
       424      3868
       42c      3875
       4ec     10050
       4f4      3547
       4fc      3554
       514      3571
       51c      3592
       5d4      3816
       5e4      3838
       5f0      3344
       630      3416
       648      3438
       670      3477
       680      3495
       69c      3521
       6e8      8029
       704      7984
       720      8014
       730      7999
       744      8053
       754      7965
       760      8604
       770      8631
       784      8649
       794      8663
       7b8      8688
       7d0      8696
       7e8      8704
       800      8712
       818      8720
       830      8728
       848      8736
       860      8744
       878      3244
       8ac      3306
       8b0      3314
       8c8      7658
       8d4     10060
       8d8     10066
       8e8     10086
       908      7690
       920      7712
       934      7732
       978      7913
       9a0      7838
       9c8      7886
       9e4      7860
       9f8      7927
       9fc      7933
       a10      7957
       a54      7802
       a70      7769
       a8c      7791
       a9c      7780
       aac      3118
       ae8      3190
       b04      3214
       b50      7577
       b6c      7544
       b88      7566
       b98      7555
       bac      7600
       bb0      7608
       bb4      7616
       bb8      7624
       bc8      7646
       bd4      2980
       c00      3037
       c14      3054
       c24      3072
       c2c      3079
       c68      7058
       c94      7161
       d28      7321
       e94      7044
       eb4      7030
       ed8      7016
       efc      6999
       f20      6925
       f34      6942
       f44      6960
       f4c      6967
       f88      7127
       fa8      7354
      1030      7506
      1218      7114
      1234      7101
      1254      7088
      1274      7072
      1288      7536
      1298      2942
      12bc      6049
      12d0      6072
      12ec      6113
      1324      6176
      1374      6234
      138c      6262
      139c      6481
      13f0      6608
      140c      6575
      1428      6597
      1438      6586
      1454      6515
      1464      6518
      1484      6534
      1494      6628
      14e4      6753
      14fc      6720
      1514      6742
      1520      6731
      153c      6660
      154c      6663
      1568      6679
      15c4      6420
      15e0      6431
      15fc      6409
      160c      6398
      166c      6844
      1684      6811
      169c      6833
      16a8      6822
      16e4      6319
      170c      6342
      1728      8763
      172c      8770
      1748      6779
      1770      6800
      1794      6868
      179c      6875
      17a4      6890
      17ac      6897
      17b8      8783
      17c4      2467
      19b4     10256
      19c4      6010
      19c8      6019
      19d0      6026
      1a1c      8835
      1a28      5876
      1a40      5911
      1a4c      5919
      1a50      5926
      1a80      5989
      1a8c      1954
      1ad0      2034
      1af8      2070
      1b08      2084
      1b1c      2117
      1b24      2130
      1b64      2195
      1b80      2162
      1b9c      2184
      1bac      2173
      1bf4      2252
      1c0c      2434
      1c24      2241
      1c30      2230
      1c78      2317
      1c94      2284
      1cb0      2306
      1cc0      2295
      1d08      2393
      1d20      2360
      1d38      2382
      1d44      2371
      1d64      2424
      1d7c      8574
      1d90     10285
      1d98     10302
      1da4      1686
      1de4      1854
      1e04      1880
      1e28      1914
      1e44      1903
      1e58      1938
      1e74      1765
      1e90      1791
      1ea4      1811
      1ebc      5489
      1ed8      1825
      1ef4      5527
      1efc      5536
      1f00      5543
      1f14      5578
      1f34      5625
      1f40      5663
      1f60      5777
      1f84      5819
      1fa0      5808
      1fb4      5852
      1fcc      5635
      1fe8      5698
      1ffc      5726
      2014      5757
      2034      5742
      2048      1630
      2094      5333
      209c      5340
      2154      8987
      2174      9015
      21c0      9116
      21dc      9083
      21f8      9105
      2208      9094
      2270      9211
      228c      8902
      22a8      8930
      22bc      8950
      22fc      9074
      2318      9041
      2334      9063
      2344      9052
      2350      9278
      2370      1494
      2388      1458
      23a0      5097
      23b8      5126
      23c0      5133
      23c8      5144
      23ec      5178
      2400      4778
      2418      9299
      2420      4794
      242c      4818
      2444      4859
      2498      4967
      24f4      5064
      2508      4741
      2518      9310
      2520      9317
      2570      4763
      258c      9405
      2598      1307
      25a8      1335
      25b0      1342
      2654     10359
      2660      4587
      2668      4607
      26e4      4728
      26f0      4545
      26f8      9416
      2708      4562
      273c      9461
      2744      1172
      274c      1179
      27ec     10421
      2878     10562
      2888     10594
      28a4      1129
      28ac      1142
      28b0      1149
      2928      4439
      2938      4461
      2954      1087
      295c      1094
      296c      1114
      2980      1025
      2984      1034
      29ac      1068
      29b4      4303
      29c8      4321
      29ec      9501
      2a14      9550
      2a18      9557
      2a20      9571
      2a4c      9615
      2a54      9631
      2a68      9550
      2a6c      9557
      2a74      9571
      2aa0      9615
      2aa8      9631
      2ac4      9550
      2ac8      9557
      2ad0      9571
      2afc      9615
      2b04      9631
      2b28       977
      2b30       984
      2ba4      9716
      2c5c      9937
      2c6c      9947
      2c7c      9968
      2c84       823
      2c8c       830
      2d30     10741
      2df8     10970
      2e08     10992
      2e20       577
      2e2c       598
      2ee0       804
      2ef0      4234
      2f10       563
      2f18       568
      2f28       531
      2f30       538
      2f4c      1597
      2f5c      1609
      2f6c      1581
      2f80      5284
      2f84      5289
      2fac      5205
      2fbc      5222
      2ff8      1538
      3008      1549
      3034      1520
      304c     10634
      3058     10639
      3070     10655
      3084      4500
      3090      4505
      30a8      4521
      30bc     11032
      30c8     11037
      30e0     11053
      30f4     11104
      310c     11122
      3154     11218
      3170     11250
      3184     11269
      3194     11284
      31b4     11310
      31b8     11318
      31dc     11367
      31f4     11402
      3204     11423
      3208     11430
      321c      9221
      3224      9228
      3228      9235
      322c      9242
      3230      9249
      3238      9256
      3240      9262
      3274     11506
      327c     11513
      3280     11520
      3284     11527
      3288     11534
      3298     11541
      329c     11549
      32a4     11555
      32b0       135
      3310       146
      3370      7167
      3408      7360
      3498      9543
      351c      9063
      3520      9041
      3524      9074
      3528      9105
      352c      9083
      3530      9116
      3534      5742
      3538      5757
      353c      5808
      3540      5819
      3544      1825
      3548      5489
      354c      1903
      3550      1914
      3554      2382
      3558      2360
      355c      2393
      3560      2306
      3564      2284
      3568      2317
      356c      2241
      3570      2434
      3574      2252
      3578      2184
      357c      2162
      3580      2195
      3584      6800
      3588      6779
      358c      6342
      3590      6319
      3594      6833
      3598      6811
      359c      6844
      35a0      6409
      35a4      6431
      35a8      6420
      35ac      6679
      35b0      6663
      35b4      6742
      35b8      6720
      35bc      6753
      35c0      6534
      35c4      6518
      35c8      6597
      35cc      6575
      35d0      6608
      35d4      7072
      35d8      7088
      35dc      7101
      35e0      7114
      35e4      7354
      35e8      7127
      35ec      6999
      35f0      7016
      35f4      7030
      35f8      7044
      35fc      7161
      3600      7058
      3604      7566
      3608      7544
      360c      7577
      3610      7791
      3614      7769
      3618      7802
      361c      7886
      3620      7838
      3624      7913
      3628      8744
      362c      8736
      3630      8728
      3634      8720
      3638      8712
      363c      8704
      3640      8696
      3644      8688
      3648      8014
      364c      7984
      3650      8029
      3654      4011
      3658     10028

Safepoints (stack slots = 28, entries = 1, byte size = 18)
0x1659a0bc28bc   32dc  slots (sp->fp): 0000000000000000000000000000

RelocInfo (size = 98)
0x1659a0bc28b8  wasm stub call  (0x1659a0b01410)
0x1659a0bc2918  wasm stub call  (0x1659a0b01410)
0x1659a0bc2994  wasm stub call  (0x1659a0b01410)
0x1659a0bc2a28  wasm stub call  (0x1659a0b01410)
0x1659a0bc2ab0  wasm stub call  (0x1659a0b01410)
0x1659a0bc2afc  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b00  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b04  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b08  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b0c  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b10  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b14  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b18  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b1c  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b20  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b24  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b28  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b2c  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b30  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b34  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b38  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b3c  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b40  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b44  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b48  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b4c  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b50  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b54  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b58  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b5c  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b60  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b64  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b68  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b6c  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b70  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b74  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b78  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b7c  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b80  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b84  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b88  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b8c  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b90  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b94  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b98  wasm stub call  (0x1659a0b01120)
0x1659a0bc2b9c  wasm stub call  (0x1659a0b01120)
0x1659a0bc2ba0  wasm stub call  (0x1659a0b01120)
0x1659a0bc2ba4  wasm stub call  (0x1659a0b01120)
0x1659a0bc2ba8  wasm stub call  (0x1659a0b01120)
0x1659a0bc2bac  wasm stub call  (0x1659a0b01120)
0x1659a0bc2bb0  wasm stub call  (0x1659a0b01120)
0x1659a0bc2bb4  wasm stub call  (0x1659a0b01120)
0x1659a0bc2bb8  wasm stub call  (0x1659a0b01120)
0x1659a0bc2bbc  wasm stub call  (0x1659a0b01120)
0x1659a0bc2bc0  wasm stub call  (0x1659a0b01120)
0x1659a0bc2bc4  wasm stub call  (0x1659a0b01120)
0x1659a0bc2bc8  wasm stub call  (0x1659a0b01120)
0x1659a0bc2bcc  wasm stub call  (0x1659a0b01120)
0x1659a0bc2bd0  wasm stub call  (0x1659a0b01120)
0x1659a0bc2bd4  wasm stub call  (0x1659a0b01120)
0x1659a0bc2bd8  wasm stub call  (0x1659a0b01120)
0x1659a0bc2bdc  wasm stub call  (0x1659a0b01120)
0x1659a0bc2be0  wasm stub call  (0x1659a0b01120)
0x1659a0bc2be4  wasm stub call  (0x1659a0b01120)
0x1659a0bc2be8  wasm stub call  (0x1659a0b01120)
0x1659a0bc2bec  wasm stub call  (0x1659a0b01120)
0x1659a0bc2bf0  wasm stub call  (0x1659a0b01120)
0x1659a0bc2bf4  wasm stub call  (0x1659a0b01120)
0x1659a0bc2bf8  wasm stub call  (0x1659a0b01120)
0x1659a0bc2bfc  wasm stub call  (0x1659a0b01120)
0x1659a0bc2c00  wasm stub call  (0x1659a0b01120)
0x1659a0bc2c04  wasm stub call  (0x1659a0b01120)
0x1659a0bc2c08  wasm stub call  (0x1659a0b01120)
0x1659a0bc2c0c  wasm stub call  (0x1659a0b01120)
0x1659a0bc2c10  wasm stub call  (0x1659a0b01120)
0x1659a0bc2c14  wasm stub call  (0x1659a0b01120)
0x1659a0bc2c18  wasm stub call  (0x1659a0b01120)
0x1659a0bc2c1c  wasm stub call  (0x1659a0b01120)
0x1659a0bc2c20  wasm stub call  (0x1659a0b01120)
0x1659a0bc2c24  wasm stub call  (0x1659a0b01120)
0x1659a0bc2c28  wasm stub call  (0x1659a0b01120)
0x1659a0bc2c2c  wasm stub call  (0x1659a0b01120)
0x1659a0bc2c30  wasm stub call  (0x1659a0b01120)
0x1659a0bc2c34  wasm stub call  (0x1659a0b01140)
0x1659a0bc2c38  wasm stub call  (0x1659a0b01140)

